// ─────────────────────────────────────────────────────────────────────────────
// prospecting-campaigns.routes.js
// ─────────────────────────────────────────────────────────────────────────────
// A "campaign" is a project that runs while you prospect for a particular
// solution. It groups prospects, points at a target prospecting playbook, and
// carries an optional default sequence used by "enroll all".
//
// Endpoints:
//   GET    /api/prospecting-campaigns                  list (with live counts)
//   POST   /api/prospecting-campaigns                  create
//   GET    /api/prospecting-campaigns/:id              one campaign + funnel
//   PUT    /api/prospecting-campaigns/:id              update
//   DELETE /api/prospecting-campaigns/:id              archive (soft) / delete
//   POST   /api/prospecting-campaigns/:id/prospects    assign prospects to it
//   DELETE /api/prospecting-campaigns/:id/prospects    un-assign prospects
//   POST   /api/prospecting-campaigns/:id/enroll-all   enroll members in seq
//
// All queries are org-scoped via req.orgId (set by orgContext). Never trust
// org_id from the request body.
// ─────────────────────────────────────────────────────────────────────────────

const express = require('express');
const router  = express.Router();
const { pool } = require('../config/database');
const authenticateToken = require('../middleware/auth.middleware');
const { orgContext, requireRole } = require('../middleware/orgContext.middleware');
const requireModule     = require('../middleware/requireModule.middleware');
const {
  sanitizeCampaignConfig,
  sanitizeOrgConfig,
  emptyCampaignConfig,
  emptyOrgConfig,
  cleanTargeting,
} = require('../config/prospectingConfigSchema');
// Signal-Based Campaigns (P3): start-from-profile seed for new campaigns.
const TargetProfileService = require('../services/TargetProfileService');
// Signal-Based Campaigns (P5): re-evaluate a campaign's pool → queue.
const SignalActionSurfacer = require('../services/SignalActionSurfacer');
// Slice 3: per-prospect personalisation now goes through the dispatcher,
// which walks all sequence steps and calls the right per-channel skill
// (outreach-email / outreach-linkedin) with the right step_intent. Replaces
// Slice 2's inline mapping of the retired outreach-personalization skill.
const PersonalizationDispatcher = require('../services/PersonalizationDispatcher');
const EnrollmentStepResolver = require('../services/EnrollmentStepResolver'); // identity-cursor stamp on enroll
const ExperimentAssigner     = require('../services/ExperimentAssigner');     // A/B arm assignment (2026_47)

// Phase 3 — campaign-scoped sequence reporting: ?depth and ?userIds filters
// on /:id/sequence-health go through the scope service for auth.
const ReportingScopeService = require('../services/ReportingScopeService');
// Single definition of "a reply" (email + LinkedIn, channel-tagged), shared
// with routes/reporting.routes.js. /:id/sequence-health used to count
// sequence_step_logs.status = 'replied' — a value nothing writes — so its
// REPLIED column read 0 while the campaign row above it showed the real
// number. See services/ReplyEventsQuery.js.
const { replyEventsCte, repliedRate: _healthRepliedRate } = require('../services/ReplyEventsQuery');
// Delivery failures. Same builder reporting.routes.js uses, so the drill-down's
// Delivered % is the same arithmetic as the campaign row that opened it.
const {
  bounceEventsCte, BOUNCE_COUNTERS,
  delivered: _healthDelivered, deliveredRate: _healthDeliveredRate,
  deliveryTelemetry: _healthDeliveryTelemetry,
} = require('../services/BounceEventsQuery');

// Slice 1 of sending-schedule feature: resolves daily cap + send window
// (org default, optionally overridden per-campaign) and computes per-
// enrollment next_step_due timestamps spread across days.
const SendingSchedule = require('../services/SendingScheduleResolver');

// Owner-based access control for campaigns. The list endpoint scopes by
// owner_id (with manager rollup); each /:id endpoint gates on
// requireCanAccess (read) or requireCanMutate (write). See
// services/CampaignAccess.js for the rules.
const CampaignAccess = require('../services/CampaignAccess');
// Per-org campaign settings (campaign_settings JSONB on org_action_config).
// Source of truth for the org-wide "owners may delete their own campaigns"
// switch used by the delete-permission model.
const CampaignSettings = require('../services/campaignSettings.service');

router.use(authenticateToken);
router.use(orgContext);
router.use(requireModule('prospecting'));

const VALID_STATUS = ['active', 'paused', 'completed', 'archived'];
const VALID_ACTIVITY_TYPES = ['outreach', 'field_event', 'digital', 'discovery'];

// Stage order used for funnel display. Kept in sync with prospects.routes.js
// VALID_STAGES; terminal stages (disqualified/nurture) are reported separately.
const FUNNEL_STAGES = ['target', 'research', 'outreach', 'engaged', 'discovery_call', 'qualified_sal'];

// ─────────────────────────────────────────────────────────────────────────────
// Helper: load one campaign scoped to the org, or null.
// ─────────────────────────────────────────────────────────────────────────────
async function loadCampaign(orgId, id) {
  const { rows } = await pool.query(
    `SELECT c.*,
            pb.name AS playbook_name,
            sq.name AS default_sequence_name,
            u.first_name AS owner_first_name,
            u.last_name  AS owner_last_name,
            cl.name AS client_name
       FROM prospecting_campaigns c
       LEFT JOIN playbooks  pb ON pb.id = c.playbook_id
       LEFT JOIN sequences  sq ON sq.id = c.default_sequence_id
       LEFT JOIN users      u  ON u.id  = c.owner_id
       LEFT JOIN clients    cl ON cl.id = c.client_id
      WHERE c.id = $1 AND c.org_id = $2`,
    [id, orgId]
  );
  return rows[0] || null;
}

// ─────────────────────────────────────────────────────────────────────────────
// Helper: validate sending-schedule override fields from req.body. Returns
// { values: {daily_activation_cap, send_window_start_hour, ...}, errors: [] }.
// Each output field is null if the caller didn't provide a value (meaning
// "inherit from org default"). Numeric fields are coerced to int; days to
// a sorted int array; timezone is IANA-validated.
// ─────────────────────────────────────────────────────────────────────────────
function validateAndCoerceSchedule(body) {
  const errors = [];
  const out = {
    daily_activation_cap:    null,
    send_window_start_hour:  null,
    send_window_start_minute: null,
    send_window_end_hour:    null,
    send_window_days:        null,
    send_window_timezone:    null,
    start_mode:              null,
    pacing_mode:             null,
    cadence_minutes:         null,
  };

  // Accept both camelCase (frontend) and snake_case (idiomatic API) names.
  const raw = {
    daily_activation_cap:    body.daily_activation_cap    ?? body.dailyActivationCap ?? body.linkedinReleaseCap,
    send_window_start_hour:  body.send_window_start_hour  ?? body.sendWindowStartHour,
    send_window_start_minute: body.send_window_start_minute ?? body.sendWindowStartMinute,
    send_window_end_hour:    body.send_window_end_hour    ?? body.sendWindowEndHour,
    send_window_days:        body.send_window_days        ?? body.sendWindowDays,
    send_window_timezone:    body.send_window_timezone    ?? body.sendWindowTimezone,
    start_mode:              body.start_mode              ?? body.startMode,
    pacing_mode:             body.pacing_mode             ?? body.pacingMode,
    cadence_minutes:         body.cadence_minutes         ?? body.cadenceMinutes,
  };

  if (raw.daily_activation_cap !== undefined && raw.daily_activation_cap !== null && raw.daily_activation_cap !== '') {
    const n = parseInt(raw.daily_activation_cap, 10);
    if (!Number.isFinite(n) || n < 1 || n > 500) {
      errors.push('daily_activation_cap must be an integer 1-500');
    } else out.daily_activation_cap = n;
  }
  if (raw.send_window_start_hour !== undefined && raw.send_window_start_hour !== null && raw.send_window_start_hour !== '') {
    const n = parseInt(raw.send_window_start_hour, 10);
    if (!Number.isFinite(n) || n < 0 || n > 23) {
      errors.push('send_window_start_hour must be 0-23');
    } else out.send_window_start_hour = n;
  }
  if (raw.send_window_start_minute !== undefined && raw.send_window_start_minute !== null && raw.send_window_start_minute !== '') {
    const n = parseInt(raw.send_window_start_minute, 10);
    if (!Number.isFinite(n) || n < 0 || n > 59) {
      errors.push('send_window_start_minute must be 0-59');
    } else out.send_window_start_minute = n;
  }
  if (raw.start_mode !== undefined && raw.start_mode !== null && raw.start_mode !== '') {
    if (!['on_activate', 'fixed', 'fixed_or_now'].includes(raw.start_mode)) {
      errors.push('start_mode must be on_activate, fixed, or fixed_or_now');
    } else out.start_mode = raw.start_mode;
  }
  if (raw.pacing_mode !== undefined && raw.pacing_mode !== null && raw.pacing_mode !== '') {
    if (!['cadence', 'spread'].includes(raw.pacing_mode)) {
      errors.push('pacing_mode must be cadence or spread');
    } else out.pacing_mode = raw.pacing_mode;
  }
  if (raw.cadence_minutes !== undefined && raw.cadence_minutes !== null && raw.cadence_minutes !== '') {
    const n = parseInt(raw.cadence_minutes, 10);
    if (!Number.isFinite(n) || n < 1 || n > 240) {
      errors.push('cadence_minutes must be 1-240');
    } else out.cadence_minutes = n;
  }
  if (raw.send_window_end_hour !== undefined && raw.send_window_end_hour !== null && raw.send_window_end_hour !== '') {
    const n = parseInt(raw.send_window_end_hour, 10);
    if (!Number.isFinite(n) || n < 1 || n > 24) {
      errors.push('send_window_end_hour must be 1-24');
    } else out.send_window_end_hour = n;
  }
  if (out.send_window_start_hour !== null && out.send_window_end_hour !== null
      && out.send_window_end_hour <= out.send_window_start_hour) {
    errors.push(
      `send_window_end_hour (${out.send_window_end_hour}:00) must be after ` +
      `send_window_start_hour (${out.send_window_start_hour}:00)`
    );
  }
  if (raw.send_window_days !== undefined && raw.send_window_days !== null) {
    if (!Array.isArray(raw.send_window_days)) {
      errors.push('send_window_days must be an array');
    } else if (raw.send_window_days.length === 0) {
      // Empty array → treat as "no override" rather than error
      out.send_window_days = null;
    } else {
      const dedup = [...new Set(raw.send_window_days.map(d => parseInt(d, 10)))];
      if (dedup.some(d => isNaN(d) || d < 0 || d > 6)) {
        errors.push('send_window_days entries must be 0..6 (0=Sun..6=Sat)');
      } else {
        out.send_window_days = dedup.sort();
      }
    }
  }
  if (raw.send_window_timezone !== undefined && raw.send_window_timezone !== null && raw.send_window_timezone !== '') {
    if (typeof raw.send_window_timezone !== 'string') {
      errors.push('send_window_timezone must be a string');
    } else {
      try {
        new Intl.DateTimeFormat('en-US', { timeZone: raw.send_window_timezone });
        out.send_window_timezone = raw.send_window_timezone.trim();
      } catch (_) {
        errors.push(`send_window_timezone "${raw.send_window_timezone}" is not a valid IANA timezone`);
      }
    }
  }

  // Cross-field guard for the end-after-start rule lives above (the `!== null`
  // check), which correctly skips when only one bound is provided in this
  // payload — the other is inherited and the resolver clamps that cross-layer
  // case. (A prior duplicate guard here used `!== undefined`, which let the
  // null-initialized fields through and mis-fired "end (null:00) must be after
  // start" on any payload that set only the start hour.)

  return { values: out, errors };
}

// Coerce + validate a campaign's selected sender accounts (Phase 2).
// Accepts body.sender_account_ids / senderAccountIds as an array of ids (or a
// comma-separated string). Returns { provided, ids, error }:
//   provided=false → the field wasn't in the body (leave existing untouched)
//   ids=null       → explicit "all senders" (empty/cleared)
//   ids=[...]      → validated subset (each must be one of ownerId's own active,
//                    non-client senders in this org — prevents borrowing another
//                    user's mailbox or a deactivated one).
async function coerceSenderIds(body, orgId, ownerId) {
  const has = Object.prototype.hasOwnProperty.call(body, 'sender_account_ids')
           || Object.prototype.hasOwnProperty.call(body, 'senderAccountIds');
  if (!has) return { provided: false, ids: null, error: null };

  let raw = body.sender_account_ids ?? body.senderAccountIds;
  if (typeof raw === 'string') raw = raw.split(',').map(s => s.trim()).filter(Boolean);
  if (raw == null || (Array.isArray(raw) && raw.length === 0)) {
    return { provided: true, ids: null, error: null }; // explicit "all senders"
  }
  if (!Array.isArray(raw)) return { provided: true, ids: null, error: 'sender_account_ids must be an array of ids' };

  const ids = [...new Set(raw.map(n => parseInt(n, 10)))];
  if (ids.some(n => !Number.isInteger(n))) {
    return { provided: true, ids: null, error: 'sender_account_ids must be integers' };
  }
  // Every id must be one of this owner's own active senders.
  const { rows } = await pool.query(
    `SELECT id FROM prospecting_sender_accounts
      WHERE org_id = $1 AND user_id = $2 AND client_id IS NULL AND is_active = true
        AND id = ANY($3)`,
    [orgId, ownerId, ids]
  );
  const valid = new Set(rows.map(r => r.id));
  const bad = ids.filter(id => !valid.has(id));
  if (bad.length) {
    return { provided: true, ids: null, error: `Not your active sender account(s): ${bad.join(', ')}` };
  }
  return { provided: true, ids, error: null };
}

// Resolve a campaign's leading (first-step) channel from its default sequence.
async function leadingChannelOf(defaultSequenceId) {
  if (!defaultSequenceId) return 'email';
  const r = await pool.query(
    `SELECT channel FROM sequence_steps
      WHERE sequence_id = $1 ORDER BY step_order LIMIT 1`,
    [defaultSequenceId]
  );
  return r.rows[0]?.channel || 'email';
}

// ─────────────────────────────────────────────────────────────────────────────
// Helper: how many OTHER active campaigns of this user can draw on the same
// mailbox(es) as `campaignId`? A campaign with sender_account_ids = NULL uses
// ALL of the rep's active senders, so it contends with everything.
//
// Purely informational — used to label the capacity box honestly. Nothing is
// reserved: contending campaigns race, and the firer's fair-share ordering
// arbitrates per (campaign, sender) at send time.
// ─────────────────────────────────────────────────────────────────────────────
async function countContendingCampaigns(orgId, userId, campaignId, senderIds) {
  const mine = (Array.isArray(senderIds) && senderIds.length) ? new Set(senderIds) : null;
  const { rows } = await pool.query(
    `SELECT c.id, c.name, c.sender_account_ids
       FROM prospecting_campaigns c
      WHERE c.org_id   = $1
        AND c.owner_id = $2
        AND c.status   = 'active'
        AND c.id      <> $3
        AND c.default_sequence_id IS NOT NULL`,
    [orgId, userId, campaignId]
  );

  const contenders = [];
  for (const r of rows) {
    const theirs = (Array.isArray(r.sender_account_ids) && r.sender_account_ids.length)
      ? new Set(r.sender_account_ids)
      : null;
    // NULL on either side means "all the rep's senders" → guaranteed overlap.
    const overlaps = (mine === null || theirs === null)
      ? true
      : [...theirs].some(id => mine.has(id));
    if (overlaps) contenders.push({ id: r.id, name: r.name });
  }
  return { count: contenders.length, campaigns: contenders };
}

// ─────────────────────────────────────────────────────────────────────────────
// Helper: resolve the effective sending schedule for a campaign plus the
// per-channel daily capacity for a given user (the one who would activate).
// Returns { settings, firstChannel, channelCap, emailCapacity, contention }.
//   - emailCapacity is null unless firstChannel === 'email'.
//   - channelCap.todayRemaining is Infinity for call/task (uncapped).
//   - contention (email only) reports how many OTHER active campaigns can draw
//     on the same mailbox(es). Informational: capacity is enforced at fire
//     time, not reserved here.
//
// NOTE: firstChannel governs the ACTIVATION batch's pacing only. Follow-up
// steps get next_step_due from SendingSchedule.nextStepDue() — pure delay
// math — so a LinkedIn-led sequence's email follow-ups and an email-led
// sequence's LinkedIn requests are both budgeted at fire time, by the channel
// they actually use. There is no cross-channel allocation to compute.
// Used by GET /:id, schedule-preview, and bulk-activate so all three agree.
// ─────────────────────────────────────────────────────────────────────────────
async function resolveCampaignCapacity(orgId, campaignId, userId, defaultSequenceId) {
  const settings = await SendingSchedule.resolveSettings({ orgId, campaignId });
  const firstChannel = await leadingChannelOf(defaultSequenceId);

  // The campaign's OWN per-campaign daily cap (raw daily_activation_cap), read
  // directly so it can act as a hard per-campaign ceiling in BOTH modes:
  //   release/day = min(computed allocation, campaignCap).
  // (resolveSettings collapses campaign override + org default into one value,
  // so we read the raw campaign column here to distinguish them.)
  let campaignCap = null;
  if (campaignId && firstChannel === 'linkedin') {
    const cr = await pool.query(
      `SELECT daily_activation_cap FROM prospecting_campaigns WHERE id=$1 AND org_id=$2`,
      [campaignId, orgId]
    );
    const raw = cr.rows[0]?.daily_activation_cap;
    if (raw != null && raw > 0) campaignCap = raw;
  }

  // Per-campaign sender selection (Phase 2): when set, email capacity is the sum
  // of ONLY the chosen senders' limits. NULL/empty = all of the user's senders
  // (preserves prior behaviour). Read once and pass through.
  let senderIds = null;
  if (campaignId && firstChannel === 'email') {
    const sr = await pool.query(
      `SELECT sender_account_ids FROM prospecting_campaigns WHERE id=$1 AND org_id=$2`,
      [campaignId, orgId]
    );
    const raw = sr.rows[0]?.sender_account_ids;
    if (Array.isArray(raw) && raw.length) senderIds = raw;
  }

  const emailCapacity = firstChannel === 'email'
    ? await SendingSchedule.resolveEmailCapacity({ orgId, userId, settings, senderIds })
    : null;
  let channelCap = SendingSchedule.resolveChannelDailyCap(firstChannel, { emailCapacity, settings });

  // ── Contention (informational only) ─────────────────────────────────────
  // Capacity is NOT pre-allocated. Email volume is bounded at fire time by the
  // mailbox's daily limit + min-delay cooldown; LinkedIn connection requests by
  // the rep's personal connection cap. When two active campaigns can draw on
  // the same mailbox they simply race, and the firer's fair-share ordering
  // decides who wins each tick. We surface the contention so the UI can be
  // honest ("shared with 1 other campaign") instead of promising a split the
  // system does not enforce.
  //
  // Replaces the old weighted-split model, which divided an ALREADY
  // sender-scoped capacity a second time by a channel-wide pool share — so two
  // campaigns pinned to different mailboxes each lost half their throughput to
  // a contention that did not exist. An unset share_weight also meant
  // "excluded: 0/day", which silently produced enrollments that could never
  // fire.
  let contention = null;
  if (firstChannel === 'email' && campaignId) {
    contention = await countContendingCampaigns(orgId, userId, campaignId, senderIds);
  }

  if (campaignCap != null && Number.isFinite(channelCap.perDayFull)) {

    // The per-campaign cap (daily_activation_cap) is
    // still a hard ceiling. resolveSettings already lets a campaign override win
    // for linkedinReleaseCap, so channelCap is usually == campaignCap here, but
    // clamp explicitly so the guarantee holds regardless of how it was resolved.
    const cap = campaignCap;
    channelCap = {
      ...channelCap,
      perDayFull:     Math.min(channelCap.perDayFull, cap),
      todayRemaining: Number.isFinite(channelCap.todayRemaining)
        ? Math.min(channelCap.todayRemaining, cap)
        : channelCap.todayRemaining,
    };
  }

  return { settings, firstChannel, channelCap, emailCapacity, contention };
}

// Build a UI-friendly capacity descriptor (e.g. "2 × 50 = 100/day").
function describeCapacity(firstChannel, channelCap, emailCapacity, settings, contention = null) {
  if (firstChannel === 'email' && emailCapacity) {
    const perAccount = emailCapacity.perAccount.map(a => a.limit);
    const n = emailCapacity.activeSenders;
    const shared = contention && contention.count > 0;

    let label;
    if (n === 0) {
      label = 'No active email senders connected';
    } else if (shared) {
      // Honest about the race. We do NOT project a split — nothing reserves it.
      label = `Up to ${emailCapacity.perDayFull}/day from ${n} sender${n === 1 ? '' : 's'}, ` +
              `shared with ${contention.count} other campaign${contention.count === 1 ? '' : 's'} ` +
              `using the same mailbox${n === 1 ? '' : 'es'}`;
    } else {
      label = `${n} sender${n === 1 ? '' : 's'} → ${emailCapacity.perDayFull}/day`;
    }

    return {
      kind: 'email',
      perDayFull:     emailCapacity.perDayFull,
      todayRemaining: emailCapacity.todayRemaining,
      activeSenders:  n,
      perAccountLimits: perAccount,
      shared:         !!shared,
      sharedWith:     shared ? contention.campaigns : [],
      label,
    };
  }
  if (firstChannel === 'linkedin') {
    // The cap governs CONNECTION REQUESTS only — LinkedIn messages, tasks and
    // calls are uncapped. A leading LinkedIn step is inferred as a connection
    // request by resolveEffectiveLinkedinIntent() unless step_intent says
    // otherwise, so this label holds for the overwhelmingly common case.
    return {
      kind: 'linkedin',
      perDayFull:     channelCap.perDayFull,
      todayRemaining: channelCap.todayRemaining,
      label: `${channelCap.perDayFull} LinkedIn connection requests/day (sent manually)`,
    };
  }
  return { kind: 'uncapped', perDayFull: null, todayRemaining: null, label: 'No daily cap (window-limited)' };
}

// ── Realistic email send projection ──────────────────────────────────────────
// The real per-day email ceiling is the SHARED sender pool (Σ the selected/active
// senders' daily limits), consumed by EVERY email send across all of this user's
// campaigns — including follow-up email steps inside LinkedIn-led sequences. The
// pool is consumed by every email send across the rep's campaigns, so a single
// campaign's advertised ceiling overstates what it actually gets when it shares
// a mailbox with another active campaign. This returns a realistic min–max
// for THIS campaign for today (firm) and the next 7 days (an estimate: it's based
// on each active enrollment's currently-scheduled NEXT send only, so future days
// undercount follow-ups not yet laid down — labelled as such in the UI).
//   poolPerDay → already reflects the campaign's selected senders (Phase 2),
//   since it's passed straight from resolveEmailCapacity(perDayFull).
//   campaignCeiling → this campaign's OWN per-day email ceiling (= the pool,
//   clamped by daily_activation_cap if set). It's what we advertise as
//   "this campaign can send up to N/day" — the answer to "how many per day",
//   independent of whether anything is enrolled yet.
async function computeEmailProjection(orgId, userId, campaignId, settings, poolPerDay, campaignCeiling) {
  const tz  = settings.sendWindowTimezone || 'America/New_York';
  const now = new Date();
  // The per-day rate this campaign can actually achieve: its own ceiling, but
  // never more than the shared pool.
  const ratePerDay = Math.max(0, Math.min(
    Number.isFinite(campaignCeiling) ? campaignCeiling : poolPerDay,
    poolPerDay
  ));
  // Wide UTC window (−1d … +9d); we bucket precisely by local calendar day below.
  const from = new Date(now.getTime() -  1 * 24 * 60 * 60 * 1000);
  const to   = new Date(now.getTime() +  9 * 24 * 60 * 60 * 1000);

  // Owner-wide email demand: every active enrollment whose CURRENT due step is an
  // email step, across ALL campaigns (no campaign filter — that's the point).
  const { rows } = await pool.query(
    `SELECT se.next_step_due, p.campaign_id
       FROM sequence_enrollments se
       JOIN sequence_steps ss
         ON ss.sequence_id = se.sequence_id
        AND ss.id             = se.current_step_id
       JOIN prospects p ON p.id = se.prospect_id
      WHERE se.org_id        = $1
        AND se.enrolled_by   = $2
        AND se.status        = 'active'
        AND ss.channel       = 'email'
        AND se.next_step_due >= $3
        AND se.next_step_due <  $4`,
    [orgId, userId, from, to]
  );

  const mine = {}, others = {};
  const competingIds = new Set();
  for (const r of rows) {
    const { dayKey } = SendingSchedule._internal.getLocalCalendarDate(new Date(r.next_step_due), tz);
    if (Number(r.campaign_id) === Number(campaignId)) {
      mine[dayKey] = (mine[dayKey] || 0) + 1;
    } else {
      others[dayKey] = (others[dayKey] || 0) + 1;
      if (r.campaign_id != null) competingIds.add(Number(r.campaign_id));
    }
  }

  // Build today + next 7 local-day buckets and the realistic slice per day.
  // The campaign can never exceed its own daily ceiling (ratePerDay), nor its
  // proportional share of the shared pool under contention:
  //   max = min(my demand, ratePerDay)
  //   min = total ≤ pool ? min(my demand, ratePerDay)
  //       : min(ratePerDay, floor(pool × my / total))
  const dayKeys = [];
  let cur = new Date(now);
  for (let i = 0; i < 8; i++) {
    dayKeys.push(SendingSchedule._internal.getLocalCalendarDate(cur, tz).dayKey);
    cur = new Date(cur.getTime() + 24 * 60 * 60 * 1000);
  }
  const perDay = dayKeys.map(dk => {
    const my    = mine[dk] || 0;
    const total = my + (others[dk] || 0);
    const max   = Math.min(my, ratePerDay);
    const min   = (total <= poolPerDay)
      ? Math.min(my, ratePerDay)
      : Math.min(ratePerDay, Math.floor(poolPerDay * (my / total)));
    return { day: dk, myDemand: my, totalDemand: total, min, max };
  });

  const today    = perDay[0];
  const weekDays = perDay.slice(1);            // next 7 days
  const sum = (arr, k) => arr.reduce((a, d) => a + d[k], 0);
  const scheduledTotal = today.myDemand + sum(weekDays, 'myDemand');
  return {
    poolPerDay,
    ratePerDay,                                 // this campaign's per-day ceiling
    hasDemand: scheduledTotal > 0,              // false → nothing enrolled/scheduled yet
    competingCampaigns: competingIds.size,
    today: { min: today.min, max: today.max, demand: today.myDemand },
    week:  { totalMin: sum(weekDays, 'min'), totalMax: sum(weekDays, 'max'), demand: sum(weekDays, 'myDemand') },
    perDay,
  };
}

// ── GET / — list campaigns with live prospect counts ─────────────────────────
router.get('/', async (req, res) => {
  try {
    const { status } = req.query;

    // ── Scope: mine | team | org ──────────────────────────────────────────
    // mine (default) → owner_id = current user. Same default as
    //   prospects.routes.js — reps see their own work by default.
    // team           → owner_id in (current user + subordinates). Manager
    //   rollup via req.subordinateIds (populated by orgContext middleware).
    //   If the caller has no subordinates this collapses to "mine".
    // org            → no owner filter. Admin-only — non-admins get 403.
    const rawScope = (req.query.scope || 'mine').toLowerCase();
    const scope    = ['mine', 'team', 'org'].includes(rawScope) ? rawScope : 'mine';

    if (scope === 'org') {
      const callerIsAdmin = await CampaignAccess.isAdmin(req);
      if (!callerIsAdmin) {
        return res.status(403).json({ error: {
          message: "You don't have permission to view all campaigns. Only admins can use scope=org.",
        } });
      }
    }

    const params = [req.orgId];
    let statusFilter = `AND c.status <> 'archived'`;   // hide archived by default
    if (status) {
      params.push(status);
      statusFilter = `AND c.status = $${params.length}`;
    }

    // Owner filter — applied AFTER the org filter so the (org_id, owner_id)
    // index introduced in 2026_13_campaign_owner_scoping.sql can be used.
    let ownerFilter = '';
    if (scope === 'mine') {
      params.push(req.userId);
      ownerFilter = `AND c.owner_id = $${params.length}`;
    } else if (scope === 'team') {
      // teamUserIds = [self, ...subordinates] — populated by orgContext.
      // Falls back to [self] if the hierarchy table isn't set up.
      const teamIds = req.teamUserIds && req.teamUserIds.length > 0
        ? req.teamUserIds
        : [req.userId];
      params.push(teamIds);
      ownerFilter = `AND c.owner_id = ANY($${params.length}::int[])`;
    }
    // scope === 'org' → no ownerFilter (admin already verified above)

    const { rows } = await pool.query(
      `SELECT c.*,
              pb.name AS playbook_name,
              sq.name AS default_sequence_name,
              u.first_name AS owner_first_name,
              u.last_name  AS owner_last_name,
              cl.name AS client_name,
              COUNT(p.id) FILTER (WHERE p.deleted_at IS NULL)                                    AS prospect_count,
              COUNT(p.id) FILTER (WHERE p.deleted_at IS NULL AND p.stage = 'qualified_sal')       AS qualified_count,
              COUNT(p.id) FILTER (WHERE p.deleted_at IS NULL AND p.stage NOT IN
                    ('qualified_sal','disqualified','nurture'))                                  AS active_count,
              -- LinkedIn connection funnel (all-time, from channel_data.linkedin
              -- state — kept accurate by the extension's "Check & update"
              -- sync). sent ⊇ accepted by construction: an accepted
              -- connection always counts as a sent request even when the
              -- request itself predates GoWarm tracking.
              COUNT(p.id) FILTER (WHERE p.deleted_at IS NULL AND (
                       (p.channel_data->'linkedin'->>'request_sent_at')    IS NOT NULL
                    OR (p.channel_data->'linkedin'->>'connected_at')       IS NOT NULL
                    OR (p.channel_data->'linkedin'->>'connection_status') IN
                       ('connection_request_sent','connection_accepted')
              ))                                                                                 AS li_sent_count,
              COUNT(p.id) FILTER (WHERE p.deleted_at IS NULL AND (
                       (p.channel_data->'linkedin'->>'connected_at')       IS NOT NULL
                    OR (p.channel_data->'linkedin'->>'connection_status') = 'connection_accepted'
              ))                                                                                 AS li_accepted_count
         FROM prospecting_campaigns c
         LEFT JOIN playbooks pb ON pb.id = c.playbook_id
         LEFT JOIN sequences sq ON sq.id = c.default_sequence_id
         LEFT JOIN users     u  ON u.id  = c.owner_id
         LEFT JOIN clients   cl ON cl.id = c.client_id
         LEFT JOIN prospects p  ON p.campaign_id = c.id AND p.org_id = c.org_id
        WHERE c.org_id = $1 ${statusFilter} ${ownerFilter}
     GROUP BY c.id, pb.name, sq.name, u.first_name, u.last_name, cl.name
     ORDER BY c.created_at DESC`,
      params
    );

    res.json({ campaigns: rows, scope });
  } catch (err) {
    console.error('campaigns GET /', err);
    res.status(500).json({ error: { message: 'Failed to load campaigns' } });
  }
});

// ── GET /me/context — current user's role + capability flags ─────────────────
//
// Lightweight endpoint the frontend calls once on mount to know which scope
// options to expose (only admins see "All"; only managers see "Team") and
// whether to render the Edit button on campaigns the user doesn't own.
//
// Server-side authoritative — frontend MUST NOT rely on sessionStorage role
// for permission decisions, since that can be stale across sessions.
//
// Returns:
//   {
//     userId:           number,
//     role:             'member' | 'admin' | 'owner',
//     isAdmin:          boolean,           // role ∈ {admin, owner}
//     hasSubordinates:  boolean,           // can use scope=team
//     subordinateCount: number
//   }
router.get('/me/context', async (req, res) => {
  try {
    const role = await CampaignAccess.loadUserRole(req);
    if (!role) {
      return res.status(403).json({ error: { message: 'Not a member of this org' } });
    }
    const callerIsAdmin = await CampaignAccess.isAdmin(req);
    const subs = req.subordinateIds || [];
    // Org-wide capability: whether campaign owners may delete their own
    // campaigns. Surfaced here so the frontend can explain a blocked delete
    // without inferring policy client-side.
    const { owner_delete_enabled } = await CampaignSettings.getForOrg(req.orgId);
    res.json({
      userId:           req.userId,
      role,
      isAdmin:          callerIsAdmin,
      hasSubordinates:  subs.length > 0,
      subordinateCount: subs.length,
      campaign_owner_delete_enabled: owner_delete_enabled,
    });
  } catch (err) {
    console.error('campaigns GET /me/context', err);
    res.status(500).json({ error: { message: 'Failed to load user context' } });
  }
});

// ── POST / — create a campaign ───────────────────────────────────────────────
router.post('/', async (req, res) => {
  const {
    name, description, solution,
    playbook_id, default_sequence_id,
    goal_qualified, start_date, end_date,
    status = 'active',
    activity_type = 'outreach',
    owner_id: bodyOwnerId,
    share_weight: bodyShareWeight,
    // Signal-Based Campaigns (P3): optional targeting seed. A campaign may
    // start from a Target Profile (target_profile_id) and/or supply an inline
    // targeting block; both are copied into prospecting_config_override.targeting
    // (template semantics — no live link to the profile).
    target_profile_id: bodyProfileId,
    targeting: bodyTargeting,
    // Agency Phase 1 (2026_52): a campaign may run for one agency client.
    // Accept both naming styles, same as the schedule fields below.
    client_id: bodyClientIdSnake,
    clientId:  bodyClientIdCamel,
  } = req.body;

  if (!name || !name.trim()) {
    return res.status(400).json({ error: { message: 'name is required' } });
  }
  if (!VALID_STATUS.includes(status)) {
    return res.status(400).json({ error: { message: `status must be one of: ${VALID_STATUS.join(', ')}` } });
  }
  if (!VALID_ACTIVITY_TYPES.includes(activity_type)) {
    return res.status(400).json({ error: { message: `activity_type must be one of: ${VALID_ACTIVITY_TYPES.join(', ')}` } });
  }

  // ── owner_id resolution ──────────────────────────────────────────────────
  // Default: the creator owns. Admins can pass an explicit owner_id to
  // create a campaign on behalf of another rep (e.g. onboarding a new hire,
  // pre-loading their pipeline). Non-admins may not.
  let resolvedOwnerId = req.user.userId;
  if (bodyOwnerId !== undefined && bodyOwnerId !== null && parseInt(bodyOwnerId, 10) !== req.user.userId) {
    const callerIsAdmin = await CampaignAccess.isAdmin(req);
    if (!callerIsAdmin) {
      return res.status(403).json({ error: {
        message: "You don't have permission to create a campaign owned by another user. Only admins can set owner_id.",
      } });
    }
    // Validate the supplied owner is an active member of this org.
    const ownerCheck = await pool.query(
      `SELECT 1 FROM org_users WHERE user_id = $1 AND org_id = $2 AND is_active = TRUE`,
      [parseInt(bodyOwnerId, 10), req.orgId]
    );
    if (!ownerCheck.rows.length) {
      return res.status(400).json({ error: {
        message: `owner_id ${bodyOwnerId} is not an active member of this org.`,
      } });
    }
    resolvedOwnerId = parseInt(bodyOwnerId, 10);
  }

  // Sending-schedule overrides (all nullable — NULL means "inherit org default")
  const sched = validateAndCoerceSchedule(req.body);
  if (sched.errors.length) {
    return res.status(400).json({ error: { message: sched.errors.join('; ') } });
  }

  try {
    // Validate playbook belongs to this org and is a prospecting playbook.
    if (playbook_id) {
      const pb = await pool.query(
        `SELECT id, type FROM playbooks WHERE id = $1 AND org_id = $2`,
        [playbook_id, req.orgId]
      );
      if (!pb.rows.length) {
        return res.status(400).json({ error: { message: 'Playbook not found in this org' } });
      }
      if (pb.rows[0].type !== 'prospecting') {
        return res.status(400).json({ error: { message: 'Campaign playbook must be a prospecting playbook' } });
      }
    }

    // Validate sequence belongs to this org.
    if (default_sequence_id) {
      const sq = await pool.query(
        `SELECT id FROM sequences WHERE id = $1 AND org_id = $2`,
        [default_sequence_id, req.orgId]
      );
      if (!sq.rows.length) {
        return res.status(400).json({ error: { message: 'Sequence not found in this org' } });
      }
    }

    // Agency Phase 1 (2026_52): validate client belongs to this org and is
    // not archived. NULL/absent → ordinary (non-client) campaign, unchanged.
    let resolvedClientId = null;
    {
      const rawClientId = bodyClientIdSnake ?? bodyClientIdCamel;
      if (rawClientId !== undefined && rawClientId !== null && rawClientId !== '') {
        const cid = parseInt(rawClientId, 10);
        if (!Number.isFinite(cid)) {
          return res.status(400).json({ error: { message: 'client_id must be a valid client id' } });
        }
        const cl = await pool.query(
          `SELECT id FROM clients WHERE id = $1 AND org_id = $2 AND archived_at IS NULL`,
          [cid, req.orgId]
        );
        if (!cl.rows.length) {
          return res.status(400).json({ error: { message: 'Client not found in this org (or archived)' } });
        }
        resolvedClientId = cid;
      }
    }

    // Validate share_weight (0..100) if provided.
    let shareWeightVal = null;
    if (bodyShareWeight !== undefined && bodyShareWeight !== null && bodyShareWeight !== '') {
      const w = parseInt(bodyShareWeight, 10);
      if (!Number.isFinite(w) || w < 0 || w > 100) {
        return res.status(400).json({ error: { message: 'share_weight must be 0..100' } });
      }
      shareWeightVal = w;
    }

    // Per-campaign sender selection (Phase 2) — validate against the owner's
    // own active senders; NULL = all senders.
    const senderSel = await coerceSenderIds(req.body, req.orgId, resolvedOwnerId);
    if (senderSel.error) {
      return res.status(400).json({ error: { message: senderSel.error } });
    }

    // ── Targeting seed (P3, D4) ──────────────────────────────────────────────
    // Start from a Target Profile if given, merge any inline targeting on top,
    // then copy the result into prospecting_config_override.targeting. This is
    // a COPY — no live link to the profile (template semantics), so later
    // profile edits never mutate this campaign. Absent both ⇒ no override (the
    // campaign starts with empty targeting; every qualifier becomes a Work-time
    // confirmation, per the "blank source allowed" rule).
    let configOverride = null;
    if (bodyProfileId != null || bodyTargeting != null) {
      let targeting;
      if (bodyProfileId != null) {
        const profile = await TargetProfileService.getProfile({ orgId: req.orgId, id: parseInt(bodyProfileId, 10) });
        if (!profile) {
          return res.status(400).json({ error: { message: `Target profile ${bodyProfileId} not found in this org` } });
        }
        targeting = await TargetProfileService.applyToCampaign({
          orgId: req.orgId, profileId: profile.id, overrides: bodyTargeting || null,
        });
      } else {
        targeting = cleanTargeting(bodyTargeting);
      }
      // Persist as a config override that carries ONLY the targeting section;
      // the resolver treats absent sections as "inherit", so this doesn't
      // clobber any org-level personalization config.
      const base = sanitizeCampaignConfig(null);
      configOverride = { ...base, targeting };
    }

    const { rows } = await pool.query(
      `INSERT INTO prospecting_campaigns
             (org_id, name, description, solution, playbook_id, default_sequence_id,
              goal_qualified, start_date, end_date, status, activity_type, owner_id, created_by,
              daily_activation_cap, send_window_start_hour, send_window_end_hour,
              send_window_days, send_window_timezone,
              send_window_start_minute, start_mode, pacing_mode, cadence_minutes,
              share_weight, sender_account_ids, prospecting_config_override, client_id)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26)
       RETURNING *`,
      [
        req.orgId, name.trim(), description || null, solution || null,
        playbook_id || null, default_sequence_id || null,
        goal_qualified || null, start_date || null, end_date || null,
        status,
        activity_type,      // D16 — metadata; drives which Execution fields show
        resolvedOwnerId,    // owner_id — may differ from creator when admin assigns
        req.user.userId,    // created_by — always the actual creator (audit)
        sched.values.daily_activation_cap,
        sched.values.send_window_start_hour,
        sched.values.send_window_end_hour,
        sched.values.send_window_days,
        sched.values.send_window_timezone,
        sched.values.send_window_start_minute,
        sched.values.start_mode,
        sched.values.pacing_mode,
        sched.values.cadence_minutes,
        shareWeightVal,
        senderSel.ids,      // sender_account_ids — NULL = all senders
        configOverride ? JSON.stringify(configOverride) : null,
        resolvedClientId,   // client_id — Agency Phase 1; NULL = ordinary campaign
      ]
    );

    const campaign = await loadCampaign(req.orgId, rows[0].id);
    res.status(201).json({ campaign });
  } catch (err) {
    console.error('campaigns POST /', err);
    res.status(500).json({ error: { message: 'Failed to create campaign' } });
  }
});


// ── Org-wide campaign-delete switch ──────────────────────────────────────────
// GET  /org/delete-policy → { enabled }  — current org switch value.
// PUT  /org/delete-policy { enabled }    — set it. Admin/owner only.
//
// Registered here (a two-segment static path) ABOVE the parameterised /:id
// routes. Stored in org_action_config.campaign_settings.owner_delete_enabled
// via CampaignSettingsService.
router.get('/org/delete-policy', async (req, res) => {
  try {
    if (!(await CampaignAccess.isAdmin(req))) {
      return res.status(403).json({ error: {
        message: "You don't have permission to view the campaign-delete policy. Admins only.",
      } });
    }
    const { owner_delete_enabled } = await CampaignSettings.getForOrg(req.orgId);
    res.json({ enabled: owner_delete_enabled });
  } catch (err) {
    console.error('campaigns GET /org/delete-policy', err);
    res.status(500).json({ error: { message: 'Failed to load campaign-delete policy' } });
  }
});

router.put('/org/delete-policy', async (req, res) => {
  try {
    if (!(await CampaignAccess.isAdmin(req))) {
      return res.status(403).json({ error: {
        message: "You don't have permission to change the campaign-delete policy. Admins only.",
      } });
    }
    const { enabled } = req.body || {};
    if (typeof enabled !== 'boolean') {
      return res.status(400).json({ error: { message: 'enabled must be a boolean' } });
    }
    const saved = await CampaignSettings.setForOrg(
      req.orgId, { owner_delete_enabled: enabled }, req.user.userId
    );
    res.json({ enabled: saved.owner_delete_enabled });
  } catch (err) {
    if (err.status === 400) {
      return res.status(400).json({ error: { message: err.message } });
    }
    console.error('campaigns PUT /org/delete-policy', err);
    res.status(500).json({ error: { message: 'Failed to update campaign-delete policy' } });
  }
});

// GET  /org/manager-edit-policy → { enabled }  — org-wide "managers may edit
//   subordinates' prospecting items" switch (manager_can_edit). Admin/owner
//   only. Stored in org_action_config.campaign_settings.manager_can_edit via
//   CampaignSettingsService. Read by services/AccessPolicy.js. Default OFF —
//   managers are view-only unless this is on or the item opts in per-row.
router.get('/org/manager-edit-policy', async (req, res) => {
  try {
    if (!(await CampaignAccess.isAdmin(req))) {
      return res.status(403).json({ error: {
        message: "You don't have permission to view the manager-edit policy. Admins only.",
      } });
    }
    const { manager_can_edit } = await CampaignSettings.getForOrg(req.orgId);
    res.json({ enabled: manager_can_edit === true });
  } catch (err) {
    console.error('campaigns GET /org/manager-edit-policy', err);
    res.status(500).json({ error: { message: 'Failed to load manager-edit policy' } });
  }
});
router.put('/org/manager-edit-policy', async (req, res) => {
  try {
    if (!(await CampaignAccess.isAdmin(req))) {
      return res.status(403).json({ error: {
        message: "You don't have permission to change the manager-edit policy. Admins only.",
      } });
    }
    const { enabled } = req.body || {};
    if (typeof enabled !== 'boolean') {
      return res.status(400).json({ error: { message: 'enabled must be a boolean' } });
    }
    const saved = await CampaignSettings.setForOrg(
      req.orgId, { manager_can_edit: enabled }, req.user.userId
    );
    res.json({ enabled: saved.manager_can_edit === true });
  } catch (err) {
    if (err.status === 400) {
      return res.status(400).json({ error: { message: err.message } });
    }
    console.error('campaigns PUT /org/manager-edit-policy', err);
    res.status(500).json({ error: { message: 'Failed to update manager-edit policy' } });
  }
});

// GET  /org/prospect-visibility-policy → { enabled }  — org-wide "restrict
//   prospect detail to the viewer's reporting scope" switch
//   (restrict_prospect_view_to_scope). Admin/owner only. Stored in
//   org_action_config.campaign_settings via CampaignSettingsService and read by
//   GET /prospects/:id. Default OFF — anyone in the org may open any prospect's
//   detail; the owner is highlighted in the UI either way. When ON, a viewer
//   sees full detail only for prospects whose owner is in their scope (self /
//   their team / all for an admin); others show an "owned by another rep"
//   placeholder.
router.get('/org/prospect-visibility-policy', async (req, res) => {
  try {
    if (!(await CampaignAccess.isAdmin(req))) {
      return res.status(403).json({ error: {
        message: "You don't have permission to view the prospect-visibility policy. Admins only.",
      } });
    }
    const { restrict_prospect_view_to_scope } = await CampaignSettings.getForOrg(req.orgId);
    res.json({ enabled: restrict_prospect_view_to_scope === true });
  } catch (err) {
    console.error('campaigns GET /org/prospect-visibility-policy', err);
    res.status(500).json({ error: { message: 'Failed to load prospect-visibility policy' } });
  }
});
router.put('/org/prospect-visibility-policy', async (req, res) => {
  try {
    if (!(await CampaignAccess.isAdmin(req))) {
      return res.status(403).json({ error: {
        message: "You don't have permission to change the prospect-visibility policy. Admins only.",
      } });
    }
    const { enabled } = req.body || {};
    if (typeof enabled !== 'boolean') {
      return res.status(400).json({ error: { message: 'enabled must be a boolean' } });
    }
    const saved = await CampaignSettings.setForOrg(
      req.orgId, { restrict_prospect_view_to_scope: enabled }, req.user.userId
    );
    res.json({ enabled: saved.restrict_prospect_view_to_scope === true });
  } catch (err) {
    if (err.status === 400) {
      return res.status(400).json({ error: { message: err.message } });
    }
    console.error('campaigns PUT /org/prospect-visibility-policy', err);
    res.status(500).json({ error: { message: 'Failed to update prospect-visibility policy' } });
  }
});

// ── GET /:id — one campaign + funnel + multi-channel outreach metrics ────────
//
// Outreach metrics now span three channels:
//   - email     (emails table, direction sent vs received/inbound)
//   - linkedin  (prospecting_activities, activity_type='linkedin_event',
//                direction derived from metadata->>'event')
//   - call      (calls table, direction outbound vs inbound — supports both
//                rep voicemails left AND prospect callback voicemails)
//
// All three roll up into byChannel + totals. The `?channel=` query param
// filters byChannel to only the requested slice (still returns funnel +
// totals unfiltered — see SPRINT_PROGRESS.md design note: funnel-by-channel
// is semantically odd because a prospect is in stage X regardless of which
// channel touched them).
//
// Also returns bySource: counts of prospects in this campaign grouped by
// where they were added from (manual / csv_import / extension / linkedin /
// referral / event / inbound). This powers the Sources mini-card on the UI.
router.get('/:id', async (req, res) => {
  try {
    const campaign = await loadCampaign(req.orgId, req.params.id);
    if (!campaign) return res.status(404).json({ error: { message: 'Campaign not found' } });
    if (!(await CampaignAccess.requireCanAccess(req, res, campaign))) return;

    const channelFilter = req.query.channel;  // 'email' | 'linkedin' | 'call' | undefined
    const VALID_CHANNEL_FILTERS = new Set(['email', 'linkedin', 'call']);
    if (channelFilter && !VALID_CHANNEL_FILTERS.has(channelFilter)) {
      return res.status(400).json({
        error: { message: `channel must be one of: ${[...VALID_CHANNEL_FILTERS].join(', ')}` },
      });
    }

    // Funnel: prospect count per stage within this campaign.
    const stageRes = await pool.query(
      `SELECT stage, COUNT(*)::int AS count
         FROM prospects
        WHERE org_id = $1 AND campaign_id = $2 AND deleted_at IS NULL
     GROUP BY stage`,
      [req.orgId, req.params.id]
    );
    const stageMap = {};
    stageRes.rows.forEach(r => { stageMap[r.stage] = r.count; });

    const funnel = FUNNEL_STAGES.map(s => ({ stage: s, count: stageMap[s] || 0 }));
    const terminal = {
      disqualified: stageMap['disqualified'] || 0,
      nurture:      stageMap['nurture']      || 0,
    };
    const totalProspects = Object.values(stageMap).reduce((a, b) => a + b, 0);
    const qualified      = stageMap['qualified_sal'] || 0;

    // ── LinkedIn connection funnel (all-time prospect state) ────────────────
    // Source of truth is channel_data.linkedin, kept accurate by the
    // extension's "Check & update sent / accepted" sync (and the manual
    // linkedin-event endpoint). Unlike the weekly byChannel cards below
    // (event-based, windowed), these are CURRENT-STATE counts:
    //   requestsSent — request_sent_at set, or status at/past
    //                  connection_request_sent. Includes accepted rows by
    //                  construction (accepted implies a request existed,
    //                  even if it predates GoWarm tracking).
    //   accepted     — connected_at set, or status = connection_accepted.
    //   pending      — sent minus accepted. NOTE: LinkedIn exposes no
    //                  decline/ignore signal, so withdrawn and ignored
    //                  requests are indistinguishable from pending.
    let linkedinConnections = { requestsSent: 0, accepted: 0, pending: 0, acceptanceRate: null };
    try {
      const liRes = await pool.query(
        `SELECT
           COUNT(*) FILTER (WHERE
                    (channel_data->'linkedin'->>'request_sent_at')    IS NOT NULL
                 OR (channel_data->'linkedin'->>'connected_at')       IS NOT NULL
                 OR (channel_data->'linkedin'->>'connection_status') IN
                    ('connection_request_sent','connection_accepted')
           )::int AS requests_sent,
           COUNT(*) FILTER (WHERE
                    (channel_data->'linkedin'->>'connected_at')       IS NOT NULL
                 OR (channel_data->'linkedin'->>'connection_status') = 'connection_accepted'
           )::int AS accepted
         FROM prospects
        WHERE org_id = $1 AND campaign_id = $2 AND deleted_at IS NULL`,
        [req.orgId, req.params.id]
      );
      const liSent     = liRes.rows[0]?.requests_sent || 0;
      const liAccepted = liRes.rows[0]?.accepted      || 0;
      linkedinConnections = {
        requestsSent:   liSent,
        accepted:       liAccepted,
        pending:        Math.max(0, liSent - liAccepted),
        acceptanceRate: liSent > 0 ? Math.round((liAccepted / liSent) * 100) : null,
      };
    } catch (liErr) {
      // Non-fatal — the drawer simply omits the section.
      console.warn('campaigns GET /:id linkedin-connections compute failed:', liErr.message);
    }

    // Outreach + responses, unioned across channels, over the requested
    // range. range=week (default, back-compat) starts on the most recent
    // Sunday in server time; range=all starts at epoch so the same query
    // returns lifetime counts — keeping the two modes structurally
    // identical means a number in either mode always reconciles with the
    // /:id/outreach-events drill-down for the same range.
    const range = req.query.range === 'all' ? 'all' : 'week';
    const weekStart = new Date();
    weekStart.setDate(weekStart.getDate() - weekStart.getDay());
    weekStart.setHours(0, 0, 0, 0);
    const rangeStart = range === 'all' ? new Date(0) : weekStart;

    // The CTE produces one row per touch with (channel, direction). We then
    // aggregate by channel.
    //
    // LinkedIn direction derivation: metadata->>'event' tells us what kind
    // of LinkedIn action it was. Outbound events count as outreach; the
    // single inbound event 'reply_received' counts as a response. Events
    // that are neither (e.g. 'connection_accepted', 'profile_viewed',
    // 'meeting_booked') are excluded — they're status milestones, not
    // outreach/response. We also count 'sequence_step_sent' as an outbound
    // touch on whatever channel the sequence step was for (almost always
    // email; linkedin sequence steps are also valid).
    //
    // Calls: direction column on the table already distinguishes outbound
    // (rep dialing, including voicemails left) from inbound (prospect
    // calling back, including voicemails left for the rep).
    const outreachRes = await pool.query(
      `WITH outreach AS (
         -- Email touches. Inbound counts as "response" only when a
         -- preceding outbound to the same prospect exists — otherwise
         -- cold inbound from a prospect would inflate the response count.
         SELECT 'email'::text  AS channel,
                CASE
                  WHEN e.direction = 'sent'                     THEN 'outreach'
                  WHEN e.direction IN ('received','inbound')
                       AND EXISTS (
                         SELECT 1 FROM emails out_e
                         WHERE out_e.org_id      = e.org_id
                           AND out_e.prospect_id = e.prospect_id
                           AND out_e.direction   = 'sent'
                           AND out_e.sent_at     < e.sent_at
                       )                                        THEN 'response'
                  ELSE NULL
                END AS kind
           FROM emails e
           JOIN prospects p ON p.id = e.prospect_id
          WHERE e.org_id     = $1
            AND p.campaign_id = $2
            AND e.sent_at    >= $3

         UNION ALL

         -- LinkedIn RESPONSES from prospecting_activities (extension or rep).
         -- Outreach is counted authoritatively from sequence_step_logs below, so
         -- this source contributes responses only.
         SELECT 'linkedin'::text AS channel,
                CASE
                  WHEN pa.metadata->>'event' = 'reply_received' THEN 'response'
                  ELSE NULL
                END AS kind
           FROM prospecting_activities pa
           JOIN prospects p ON p.id = pa.prospect_id
          WHERE pa.org_id      = $1
            AND p.campaign_id  = $2
            AND pa.activity_type = 'linkedin_event'
            AND pa.created_at  >= $3

         UNION ALL

         -- LinkedIn OUTREACH — authoritative from sequence_step_logs. A LinkedIn
         -- step reaching sent/completed is the definitive record that the
         -- connection request / message went out, regardless of which finalize
         -- path ran (auto-send confirm, rep draft-send, manual "mark as done") or
         -- how that path tagged its activity row. Counting from the activity
         -- ledger undercounted here because only the auto-send path writes a
         -- 'linkedin_event'; drafts/manual completions write other activity
         -- types the by-channel roll-up doesn't match.
         SELECT 'linkedin'::text AS channel, 'outreach'::text AS kind
           FROM sequence_step_logs l
           JOIN sequence_steps ss2 ON ss2.id = l.sequence_step_id
                                  AND ss2.channel = 'linkedin'
           JOIN prospects p ON p.id = l.prospect_id
          WHERE l.org_id      = $1
            AND p.campaign_id = $2
            AND l.status      IN ('sent','completed')
            AND l.fired_at   >= $3

         UNION ALL

         -- Sequence step sends — attributed to the step's channel.
         -- DEDUP: email sends through the sequence engine write BOTH an
         -- emails row and this activity (metadata.emailId links them).
         -- Those are already counted by the email branch above, so we
         -- exclude any step activity that references an emails row —
         -- keeping only steps with no first-class record of their own
         -- (LinkedIn/call steps, plus legacy email rows without emailId).
         SELECT
           CASE
             WHEN pa.metadata->>'channel' IN ('email','linkedin','call')
               THEN pa.metadata->>'channel'
             ELSE 'email'  -- default for legacy rows without channel meta
           END::text AS channel,
           'outreach'::text AS kind
           FROM prospecting_activities pa
           JOIN prospects p ON p.id = pa.prospect_id
          WHERE pa.org_id      = $1
            AND p.campaign_id  = $2
            AND pa.activity_type = 'sequence_step_sent'
            AND (pa.metadata->>'emailId') IS NULL
            -- LinkedIn outreach is now counted authoritatively from
            -- sequence_step_logs (above). Exclude any LinkedIn-tagged step
            -- activity here to avoid double-counting. (Manual/draft LinkedIn
            -- completions actually write activity_type='sequence_step_completed',
            -- not 'sequence_step_sent', so they never reached this source anyway
            -- — which is exactly why the old by-channel roll-up undercounted them.
            -- Call + legacy-email step activities are unaffected.)
            AND COALESCE(pa.metadata->>'channel','') <> 'linkedin'
            AND pa.created_at  >= $3

         UNION ALL

         -- Calls (both directions)
         SELECT 'call'::text AS channel,
                CASE
                  WHEN c.direction = 'outbound' THEN 'outreach'
                  WHEN c.direction = 'inbound'  THEN 'response'
                  ELSE NULL
                END AS kind
           FROM calls c
           JOIN prospects p ON p.id = c.prospect_id
          WHERE c.org_id      = $1
            AND p.campaign_id = $2
            AND c.occurred_at >= $3
       )
       SELECT channel,
              COUNT(*) FILTER (WHERE kind = 'outreach')::int AS outreach,
              COUNT(*) FILTER (WHERE kind = 'response')::int AS responses
         FROM outreach
        WHERE kind IS NOT NULL
     GROUP BY channel`,
      [req.orgId, req.params.id, rangeStart]
    );

    // Build byChannel with explicit zeros for any missing channel so the
    // UI doesn't have to defensively handle absent keys.
    const byChannel = {
      email:    { outreach: 0, responses: 0 },
      linkedin: { outreach: 0, responses: 0 },
      call:     { outreach: 0, responses: 0 },
    };
    for (const row of outreachRes.rows) {
      if (byChannel[row.channel]) {
        byChannel[row.channel] = {
          outreach:  row.outreach  || 0,
          responses: row.responses || 0,
        };
      }
    }

    // Totals across all channels — kept on the response for the cards that
    // show "Outreach this week" without a channel split (and for the
    // backward-compat fields we still emit below).
    const outreachThisWeek  = byChannel.email.outreach  + byChannel.linkedin.outreach  + byChannel.call.outreach;
    const responsesThisWeek = byChannel.email.responses + byChannel.linkedin.responses + byChannel.call.responses;

    // Apply channel filter to byChannel if requested. We keep the totals
    // computed over ALL channels, since totals are an unconditional rollup
    // for the campaign — filtering totals would just confuse the UI.
    const byChannelOut = channelFilter
      ? { [channelFilter]: byChannel[channelFilter] }
      : byChannel;

    // Prospects by source — counts of how each prospect in this campaign
    // was added. Source is set at create time and never changes.
    const sourceRes = await pool.query(
      `SELECT COALESCE(source, 'unknown') AS source,
              COUNT(*)::int AS count
         FROM prospects
        WHERE org_id = $1
          AND campaign_id = $2
          AND deleted_at IS NULL
     GROUP BY COALESCE(source, 'unknown')`,
      [req.orgId, req.params.id]
    );
    const bySource = {};
    sourceRes.rows.forEach(r => { bySource[r.source] = r.count; });

    // Active enrollments for this campaign's prospects.
    const enrollRes = await pool.query(
      `SELECT COUNT(*)::int AS active_enrollments
         FROM sequence_enrollments se
         JOIN prospects p ON p.id = se.prospect_id
        WHERE se.org_id = $1 AND p.campaign_id = $2 AND se.status = 'active'`,
      [req.orgId, req.params.id]
    );

    // Effective sending schedule + computed per-channel capacity for the
    // viewing user (the likely activator). Powers the "2 × 50 = 100/day" hint
    // and the unified schedule panel's read-only capacity line.
    let scheduleBlock = null;
    try {
      const cap = await resolveCampaignCapacity(
        req.orgId, parseInt(req.params.id, 10), req.user.userId, campaign.default_sequence_id
      );
      scheduleBlock = {
        settings:     cap.settings,
        firstChannel: cap.firstChannel,
        capacity:     describeCapacity(cap.firstChannel, cap.channelCap, cap.emailCapacity, cap.settings, cap.contention),
        contention:   cap.contention,
      };
      // Realistic today + next-7-day projection for email-led campaigns. Pool
      // comes from the (already sender-selection-aware) email capacity.
      if (cap.firstChannel === 'email' && scheduleBlock.capacity && scheduleBlock.capacity.kind === 'email') {
        const pool = cap.emailCapacity ? cap.emailCapacity.perDayFull : 0;
        if (pool > 0) {
          try {
            scheduleBlock.capacity.projection = await computeEmailProjection(
              req.orgId, req.user.userId, parseInt(req.params.id, 10), cap.settings, pool,
              (cap.channelCap && Number.isFinite(cap.channelCap.perDayFull)) ? cap.channelCap.perDayFull : pool
            );
          } catch (pErr) {
            console.warn('campaigns GET /:id email projection failed:', pErr.message);
          }
        }
      }
    } catch (capErr) {
      console.warn('campaigns GET /:id capacity compute failed:', capErr.message);
    }

    // ── Delete-permission flags for the drawer ───────────────────────────────
    // Server-authoritative so the frontend never infers role/policy itself.
    //   delete_locked        — already present on `campaign` via SELECT c.*
    //   can_delete           — may the CURRENT user cascade-delete this campaign
    //   delete_blocked_reason— why not (null when can_delete is true)
    //   can_set_lock         — may the current user lock/unlock this campaign
    try {
      const { owner_delete_enabled } = await CampaignSettings.getForOrg(req.orgId);
      const del  = await CampaignAccess.canDeleteCampaign(
        req, campaign, { ownerDeleteEnabled: owner_delete_enabled }
      );
      const lock = await CampaignAccess.canSetCampaignLock(req, campaign);
      campaign.delete_locked         = campaign.delete_locked === true; // normalise NULL→false
      campaign.can_delete            = del.allowed;
      campaign.delete_blocked_reason = del.allowed ? null : del.reason;
      campaign.can_set_lock          = lock.allowed;
    } catch (permErr) {
      console.warn('campaigns GET /:id delete-flags compute failed:', permErr.message);
      // Fail safe: hide the destructive affordances rather than expose them.
      campaign.can_delete            = false;
      campaign.delete_blocked_reason = null;
      campaign.can_set_lock          = false;
    }

    // ── Campaign-level config overrides (provenance view) ────────────────
    // Two independent override systems exist; surface BOTH so a rep can see
    // exactly what this campaign changes vs. what it inherits:
    //   1. Sending schedule — nullable columns on prospecting_campaigns that
    //      win over org_integrations.config which wins over resolver DEFAULTS.
    //   2. Personalization/skill config — prospecting_config_override jsonb
    //      (full blob behind GET /:id/config with its own stricter guard;
    //      here we expose only WHICH keys are overridden, not their values).
    let overridesBlock = null;
    try {
      const { DEFAULTS: SCHED_DEFAULTS } = require('../services/SendingScheduleResolver');
      const ovRes = await pool.query(
        `SELECT daily_activation_cap, send_window_start_hour, send_window_start_minute,
                send_window_end_hour, send_window_days, send_window_timezone,
                start_mode, pacing_mode, cadence_minutes,
                prospecting_config_override
           FROM prospecting_campaigns
          WHERE id = $1 AND org_id = $2`,
        [req.params.id, req.orgId]
      );
      const orgCfgRes = await pool.query(
        `SELECT config FROM org_integrations
          WHERE org_id = $1 AND integration_type = 'prospecting_email'`,
        [req.orgId]
      );
      const raw    = ovRes.rows[0] || {};
      const orgCfg = orgCfgRes.rows[0]?.config || {};

      // column → { label, orgKey, defaultKey } — orgKey is the camelCase
      // name in org_integrations.config; defaults come from the resolver so
      // the "inherited would be" value matches what actually fires.
      const FIELDS = [
        ['start_mode',               'Start mode',               'startMode',             'startMode'],
        ['pacing_mode',              'Pacing mode',              'pacingMode',            'pacingMode'],
        ['cadence_minutes',          'Cadence (minutes)',        'cadenceMinutes',        'cadenceMinutes'],
        ['send_window_start_hour',   'Send window start (hour)', 'sendWindowStartHour',   'sendWindowStartHour'],
        ['send_window_start_minute', 'Send window start (min)',  'sendWindowStartMinute', 'sendWindowStartMinute'],
        ['send_window_end_hour',     'Send window end (hour)',   'sendWindowEndHour',     'sendWindowEndHour'],
        ['send_window_days',         'Send days',                'sendWindowDays',        'sendWindowDays'],
        ['send_window_timezone',     'Timezone',                 'sendWindowTimezone',    'sendWindowTimezone'],
        ['daily_activation_cap',     'Daily activation cap',     'dailyActivationCap',    'linkedinReleaseCap'],
      ];
      const schedule = [];
      for (const [col, label, orgKey, defKey] of FIELDS) {
        if (raw[col] == null) continue;   // not overridden by this campaign
        const inheritedFromOrg = orgCfg[orgKey] != null;
        schedule.push({
          key:            col,
          label,
          campaignValue:  raw[col],
          inheritedValue: inheritedFromOrg ? orgCfg[orgKey] : SCHED_DEFAULTS[defKey],
          inheritedFrom:  inheritedFromOrg ? 'org' : 'default',
        });
      }

      const cfgOv = raw.prospecting_config_override || null;
      // Only count keys that actually override something. The panel's
      // semantics: empty string / empty array / empty object = "inherit
      // from org" — those keys may exist in the saved blob but are NOT
      // overrides, and counting them inflates the badge.
      const isOverriding = (v) => {
        if (v == null) return false;
        if (typeof v === 'string') return v.trim() !== '';
        if (Array.isArray(v)) return v.some(isOverriding);
        // Objects override only if SOMETHING nested does — e.g.
        // guardrails: { banned: [], required: [] } is inert, not an
        // override, despite being a non-empty object.
        if (typeof v === 'object') return Object.values(v).some(isOverriding);
        return true;
      };
      const activeKeys = cfgOv
        ? Object.entries(cfgOv).filter(([, v]) => isOverriding(v))
        : [];
      overridesBlock = {
        schedule,
        config: {
          hasOverride: activeKeys.length > 0,
          // Key names + sizes only — values live behind GET /:id/config,
          // which enforces the owner/manager/admin read guard.
          overriddenKeys: activeKeys.map(([k, v]) => ({
            key: k,
            size: Array.isArray(v) ? v.length : (v && typeof v === 'object' ? Object.keys(v).length : 1),
          })),
        },
      };
    } catch (ovErr) {
      console.warn('campaigns GET /:id overrides compute failed:', ovErr.message);
    }

    // ── in_motion: has this campaign committed to an outreach path? ──────
    // True once ANY of these exist (all-time, regardless of the range
    // toggle): an active sequence enrollment, a sent email, a LinkedIn
    // outreach event, or a sequence step send. Drives launch-time-only
    // affordances in the UI — e.g. template-only mass enrollment is a
    // decision you make BEFORE the campaign starts sending, not after
    // personalized outreach is already in flight (mixing verbatim and
    // personalized sends to the same audience).
    const motionRes = await pool.query(
      `SELECT
         EXISTS (
           SELECT 1 FROM sequence_enrollments se
             JOIN prospects p ON p.id = se.prospect_id
            WHERE se.org_id = $1 AND p.campaign_id = $2
              AND p.deleted_at IS NULL AND se.status = 'active'
         ) AS has_active_enrollments,
         EXISTS (
           SELECT 1 FROM emails e
             JOIN prospects p ON p.id = e.prospect_id
            WHERE e.org_id = $1 AND p.campaign_id = $2
              AND e.direction = 'sent'
         ) AS has_email_sends,
         EXISTS (
           SELECT 1 FROM prospecting_activities pa
             JOIN prospects p ON p.id = pa.prospect_id
            WHERE pa.org_id = $1 AND p.campaign_id = $2
              AND (
                (pa.activity_type = 'linkedin_event'
                 AND pa.metadata->>'event' IN (
                   'connection_request_sent','message_sent',
                   'inmail_sent','voice_note_sent'))
                OR pa.activity_type = 'sequence_step_sent'
              )
         ) AS has_other_sends`,
      [req.orgId, req.params.id]
    );
    const motion = motionRes.rows[0] || {};
    const inMotion = !!(motion.has_active_enrollments || motion.has_email_sends || motion.has_other_sends);

    res.json({
      campaign,
      funnel,
      terminal,
      schedule: scheduleBlock,
      overrides: overridesBlock,
      metrics: {
        totalProspects,
        qualified,
        inMotion,
        inMotionReasons: {
          activeEnrollments: !!motion.has_active_enrollments,
          emailSends:        !!motion.has_email_sends,
          otherSends:        !!motion.has_other_sends,
        },
        goalQualified:       campaign.goal_qualified || null,
        // Which window the outreach/response numbers cover: 'week' | 'all'.
        // Echoed so the UI labels match what was actually computed.
        range,
        // Back-compat — older frontend code reads these flat fields. They
        // reflect the REQUESTED range despite the legacy "ThisWeek" names.
        outreachThisWeek,
        responsesThisWeek,
        activeEnrollments:   enrollRes.rows[0]?.active_enrollments || 0,
        // New, channel-aware shape.
        byChannel:           byChannelOut,
        bySource,
        // All-time LinkedIn connection funnel (state-based — see comment
        // above the query). Rendered as the "LinkedIn connections" block.
        linkedinConnections,
      },
    });
  } catch (err) {
    console.error('campaigns GET /:id', err);
    res.status(500).json({ error: { message: 'Failed to load campaign' } });
  }
});

// ── GET /:id/outreach-events — drill-down for the BY CHANNEL numbers ─────────
//
// Returns the INDIVIDUAL touches behind a byChannel count, using the exact
// same union/classification logic as GET /:id (same range semantics, same
// kind derivation) so the list always sums to the number that was clicked.
//
//   Query: channel = email | linkedin | call   (required)
//          kind    = outreach | response       (required)
//          range   = week | all                (default week, same Sunday rule)
//
//   Returns { events: [{ prospect_id, prospect_name, company_name, ts,
//                        channel, kind, detail }], total, range }
//   detail is a short human label: email subject, linkedin event type,
//   sequence step description, or call direction/outcome.
router.get('/:id/outreach-events', async (req, res) => {
  try {
    const campaign = await loadCampaign(req.orgId, req.params.id);
    if (!campaign) return res.status(404).json({ error: { message: 'Campaign not found' } });
    if (!(await CampaignAccess.requireCanAccess(req, res, campaign))) return;

    // channel is optional: omit (or pass 'all') to drill into the
    // cross-channel totals shown on the top metric cards.
    const channel = req.query.channel && req.query.channel !== 'all' ? req.query.channel : null;
    const kind    = req.query.kind;
    if (channel && !['email', 'linkedin', 'call'].includes(channel)) {
      return res.status(400).json({ error: { message: 'channel must be one of: email, linkedin, call (or omitted for all)' } });
    }
    // Funnel kinds are step-log-grain and email-only (they explain the
    // /:id/email-funnel stages); outreach/response are the original
    // touch-grain kinds behind the BY CHANNEL cards.
    const FUNNEL_KINDS = ['sent', 'delivered', 'opened', 'clicked'];
    if (![...FUNNEL_KINDS, 'outreach', 'response'].includes(kind)) {
      return res.status(400).json({ error: { message: 'kind must be one of: outreach, response, sent, delivered, opened, clicked' } });
    }

    const range = req.query.range === 'all' ? 'all' : 'week';
    const weekStart = new Date();
    weekStart.setDate(weekStart.getDate() - weekStart.getDay());
    weekStart.setHours(0, 0, 0, 0);
    const rangeStart = range === 'all' ? new Date(0) : weekStart;

    if (FUNNEL_KINDS.includes(kind)) {
      // ── Funnel drill: one row per email SEND (sequence_step_logs), the
      // exact predicates of /:id/email-funnel so the list total always
      // equals the stage count that was clicked.
      //   sent      → all sends in range
      //   delivered → sends minus hard bounces
      //   opened    → sends with ≥1 human open  (ts = last open)
      //   clicked   → sends with ≥1 human click (ts = last click, detail
      //               carries the clicked URLs)
      const { rows } = await pool.query(
        `WITH sends AS (
           SELECT ssl.id, ssl.subject, ssl.fired_at,
                  p.id AS prospect_id, p.first_name, p.last_name, p.company_name
             FROM sequence_step_logs ssl
             JOIN prospects p ON p.id = ssl.prospect_id
            WHERE ssl.org_id      = $1
              AND p.campaign_id   = $2
              AND ssl.channel     = 'email'
              AND ssl.status      IN ('sent','completed')
              AND ssl.fired_at   >= $3
         ),
         hard_bounced AS (
           SELECT DISTINCT ede.step_log_id
             FROM email_delivery_events ede
             JOIN sends ON sends.id = ede.step_log_id
            WHERE ede.org_id = $1 AND ede.event_type = 'hard_bounce'
         ),
         engaged AS (
           SELECT eee.step_log_id,
                  COUNT(*) FILTER (WHERE eee.event_type = 'open')::int   AS opens,
                  MAX(eee.occurred_at) FILTER (WHERE eee.event_type = 'open')  AS last_open_at,
                  COUNT(*) FILTER (WHERE eee.event_type = 'click')::int  AS clicks,
                  MAX(eee.occurred_at) FILTER (WHERE eee.event_type = 'click') AS last_click_at,
                  ARRAY_REMOVE(ARRAY_AGG(DISTINCT eee.url)
                               FILTER (WHERE eee.event_type = 'click'), NULL)  AS clicked_urls
             FROM email_engagement_events eee
             JOIN sends ON sends.id = eee.step_log_id
            WHERE eee.org_id = $1 AND eee.is_bot = false
            GROUP BY eee.step_log_id
         )
         SELECT s.prospect_id, s.first_name, s.last_name, s.company_name,
                s.subject, s.fired_at,
                g.opens, g.last_open_at, g.clicks, g.last_click_at, g.clicked_urls,
                COUNT(*) OVER ()::int AS total
           FROM sends s
           LEFT JOIN engaged g ON g.step_log_id = s.id
          WHERE CASE $4::text
                  WHEN 'sent'      THEN TRUE
                  WHEN 'delivered' THEN s.id NOT IN (SELECT step_log_id FROM hard_bounced)
                  WHEN 'opened'    THEN COALESCE(g.opens, 0)  > 0
                  WHEN 'clicked'   THEN COALESCE(g.clicks, 0) > 0
                END
       ORDER BY CASE $4::text
                  WHEN 'opened'  THEN g.last_open_at
                  WHEN 'clicked' THEN g.last_click_at
                  ELSE s.fired_at
                END DESC NULLS LAST
          LIMIT 200`,
        [req.orgId, req.params.id, rangeStart, kind]
      );

      // Same profile enrichment as the touch-grain path below.
      const funnelProspectIds = [...new Set(rows.map(r => r.prospect_id).filter(Boolean))];
      let funnelProfileById = {};
      if (funnelProspectIds.length) {
        const prof = await pool.query(
          `SELECT id, linkedin_url, title FROM prospects
            WHERE org_id = $1 AND id = ANY($2::int[])`,
          [req.orgId, funnelProspectIds]
        );
        funnelProfileById = Object.fromEntries(
          prof.rows.map(p => [p.id, { linkedin_url: p.linkedin_url || null, title: p.title || null }])
        );
      }

      const urlHost = (u) => { try { return new URL(u).hostname; } catch (_) { return u; } };
      return res.json({
        range, channel: 'email', kind,
        opensAreDirectional: kind === 'opened',
        total:  rows[0]?.total || 0,
        events: rows.map(r => {
          const subject = r.subject || '(no subject)';
          let detail = subject;
          let ts     = r.fired_at;
          if (kind === 'opened') {
            detail = `${subject} · opened ${r.opens}×`;
            ts     = r.last_open_at || r.fired_at;
          } else if (kind === 'clicked') {
            const hosts = [...new Set((r.clicked_urls || []).map(urlHost))].slice(0, 3).join(', ');
            detail = `${subject}${hosts ? ` · clicked ${hosts}` : ''}`;
            ts     = r.last_click_at || r.fired_at;
          }
          return {
            prospect_id:   r.prospect_id,
            prospect_name: `${r.first_name || ''} ${r.last_name || ''}`.trim(),
            company_name:  r.company_name || null,
            title:         funnelProfileById[r.prospect_id]?.title || null,
            linkedin_url:  funnelProfileById[r.prospect_id]?.linkedin_url || null,
            ts,
            channel: 'email',
            kind,
            detail,
          };
        }),
      });
    }

    const { rows } = await pool.query(
      `WITH touches AS (
         SELECT 'email'::text AS channel,
                CASE
                  WHEN e.direction = 'sent'                     THEN 'outreach'
                  WHEN e.direction IN ('received','inbound')
                       AND EXISTS (
                         SELECT 1 FROM emails out_e
                         WHERE out_e.org_id      = e.org_id
                           AND out_e.prospect_id = e.prospect_id
                           AND out_e.direction   = 'sent'
                           AND out_e.sent_at     < e.sent_at
                       )                                        THEN 'response'
                  ELSE NULL
                END AS kind,
                e.sent_at AS ts,
                p.id AS prospect_id, p.first_name, p.last_name, p.company_name,
                COALESCE(NULLIF(e.subject, ''), '(no subject)') AS detail
           FROM emails e
           JOIN prospects p ON p.id = e.prospect_id
          WHERE e.org_id = $1 AND p.campaign_id = $2 AND e.sent_at >= $3

         UNION ALL

         -- LinkedIn RESPONSES only (outreach comes from sequence_step_logs below).
         SELECT 'linkedin'::text,
                CASE
                  WHEN pa.metadata->>'event' = 'reply_received' THEN 'response'
                  ELSE NULL
                END,
                pa.created_at,
                p.id, p.first_name, p.last_name, p.company_name,
                replace(COALESCE(pa.metadata->>'event', 'linkedin'), '_', ' ')
           FROM prospecting_activities pa
           JOIN prospects p ON p.id = pa.prospect_id
          WHERE pa.org_id = $1 AND p.campaign_id = $2
            AND pa.activity_type = 'linkedin_event'
            AND pa.created_at >= $3

         UNION ALL

         -- LinkedIn OUTREACH — authoritative from sequence_step_logs (matches the
         -- byChannel count in GET /:id). A sent/completed LinkedIn step is the
         -- definitive record, regardless of finalize path; the activity ledger
         -- undercounted because only auto-send writes a 'linkedin_event'.
         SELECT 'linkedin'::text,
                'outreach'::text,
                l.fired_at,
                p.id, p.first_name, p.last_name, p.company_name,
                CASE WHEN ss2.step_intent = 'message_sent'
                       THEN 'message sent'
                     ELSE 'connection request sent' END
           FROM sequence_step_logs l
           JOIN sequence_steps ss2 ON ss2.id = l.sequence_step_id
                                  AND ss2.channel = 'linkedin'
           JOIN prospects p ON p.id = l.prospect_id
          WHERE l.org_id = $1 AND p.campaign_id = $2
            AND l.status IN ('sent','completed')
            AND l.fired_at >= $3

         UNION ALL

         SELECT CASE
                  WHEN pa.metadata->>'channel' IN ('email','linkedin','call')
                    THEN pa.metadata->>'channel'
                  ELSE 'email'
                END::text,
                'outreach'::text,
                pa.created_at,
                p.id, p.first_name, p.last_name, p.company_name,
                COALESCE(NULLIF(pa.description, ''), 'sequence step sent')
           FROM prospecting_activities pa
           JOIN prospects p ON p.id = pa.prospect_id
          WHERE pa.org_id = $1 AND p.campaign_id = $2
            AND pa.activity_type = 'sequence_step_sent'
            AND (pa.metadata->>'emailId') IS NULL
            -- LinkedIn outreach is now sourced from sequence_step_logs (above);
            -- exclude LinkedIn-tagged step activities here to avoid double-count.
            -- Mirrors the byChannel count query in GET /:id.
            AND COALESCE(pa.metadata->>'channel','') <> 'linkedin'
            AND pa.created_at >= $3

         UNION ALL

         SELECT 'call'::text,
                CASE
                  WHEN c.direction = 'outbound' THEN 'outreach'
                  WHEN c.direction = 'inbound'  THEN 'response'
                  ELSE NULL
                END,
                c.occurred_at,
                p.id, p.first_name, p.last_name, p.company_name,
                trim(both ' ·' FROM c.direction || ' · ' || COALESCE(c.outcome, ''))
           FROM calls c
           JOIN prospects p ON p.id = c.prospect_id
          WHERE c.org_id = $1 AND p.campaign_id = $2 AND c.occurred_at >= $3
       )
       SELECT channel, kind, ts, prospect_id, first_name, last_name,
              company_name, detail,
              COUNT(*) OVER ()::int AS total
         FROM touches
        WHERE kind = $4 AND ($5::text IS NULL OR channel = $5)
     ORDER BY ts DESC
        LIMIT 200`,
      [req.orgId, req.params.id, rangeStart, kind, channel]
    );

    // Enrich with LinkedIn profile URL + title so the LinkedIn drill-down can
    // render clickable `in ↗` links like the connections modal. Kept as a small
    // follow-up lookup (rather than threading two more columns through every
    // branch of the UNION above) to avoid column-order fragility.
    const prospectIds = [...new Set(rows.map(r => r.prospect_id).filter(Boolean))];
    let profileById = {};
    if (prospectIds.length) {
      const prof = await pool.query(
        `SELECT id, linkedin_url, title FROM prospects
          WHERE org_id = $1 AND id = ANY($2::int[])`,
        [req.orgId, prospectIds]
      );
      profileById = Object.fromEntries(
        prof.rows.map(p => [p.id, { linkedin_url: p.linkedin_url || null, title: p.title || null }])
      );
    }

    res.json({
      range, channel, kind,
      total:  rows[0]?.total || 0,
      events: rows.map(r => ({
        prospect_id:   r.prospect_id,
        prospect_name: `${r.first_name || ''} ${r.last_name || ''}`.trim(),
        company_name:  r.company_name || null,
        title:         profileById[r.prospect_id]?.title || null,
        linkedin_url:  profileById[r.prospect_id]?.linkedin_url || null,
        ts:            r.ts,
        channel:       r.channel,
        kind:          r.kind,
        detail:        r.detail || null,
      })),
    });
  } catch (err) {
    console.error('campaigns GET /:id/outreach-events', err);
    res.status(500).json({ error: { message: 'Failed to load outreach events' } });
  }
});

// ── GET /:id/email-funnel — Sent → Delivered → Opened → Clicked → Replied ────
//
//   Query: range = week | all   (default week, same Sunday rule as GET /:id)
//
// GRAIN: message-grain over sequence_step_logs for the first four stages —
// email steps FIRED in range, cohort attribution (an open lands on the send
// that produced it, whenever the open occurs). This keeps stage counts
// monotonic: opened ⊆ delivered ⊆ sent, clicked ⊆ opened is NOT guaranteed
// (a click without a pixel load is possible when images are blocked) so
// clicked is bounded by delivered only.
//
//   sent      — email step logs, status IN ('sent','completed'), fired in range
//   delivered — sent minus HARD bounces (same rule as BounceEventsQuery:
//               blocks + soft bounces stay inside delivered, reported by tiles)
//   opened    — sends with ≥1 HUMAN open (is_bot = false). DIRECTIONAL —
//               Apple MPP / Gmail proxies inflate this; UI must label it.
//   clicked   — sends with ≥1 human click
//
//   replied   — DIFFERENT GRAIN, deliberately: email responses received in
//               range, the exact predicate behind byChannel.email.responses
//               in GET /:id, so this stage always reconciles with the
//               response card next to it. A reply is a received message, not
//               a property of one send — pinning it to the send cohort would
//               make the funnel disagree with every other reply count on
//               the page.
//
// Every stage is drillable via GET /:id/outreach-events with the kind of the
// same name (sent/delivered/opened/clicked reuse THIS query's predicates;
// replied drills the existing kind=response&channel=email list).
router.get('/:id/email-funnel', async (req, res) => {
  try {
    const campaign = await loadCampaign(req.orgId, req.params.id);
    if (!campaign) return res.status(404).json({ error: { message: 'Campaign not found' } });
    if (!(await CampaignAccess.requireCanAccess(req, res, campaign))) return;

    const range = req.query.range === 'all' ? 'all' : 'week';
    const weekStart = new Date();
    weekStart.setDate(weekStart.getDate() - weekStart.getDay());
    weekStart.setHours(0, 0, 0, 0);
    const rangeStart = range === 'all' ? new Date(0) : weekStart;

    const { rows } = await pool.query(
      `WITH sends AS (
         SELECT ssl.id
           FROM sequence_step_logs ssl
           JOIN prospects p ON p.id = ssl.prospect_id
          WHERE ssl.org_id      = $1
            AND p.campaign_id   = $2
            AND ssl.channel     = 'email'
            AND ssl.status      IN ('sent','completed')
            AND ssl.fired_at   >= $3
       ),
       hard_bounced AS (
         SELECT DISTINCT ede.step_log_id
           FROM email_delivery_events ede
           JOIN sends ON sends.id = ede.step_log_id
          WHERE ede.org_id = $1 AND ede.event_type = 'hard_bounce'
       ),
       engaged AS (
         SELECT eee.step_log_id,
                BOOL_OR(eee.event_type = 'open')  AS opened,
                BOOL_OR(eee.event_type = 'click') AS clicked
           FROM email_engagement_events eee
           JOIN sends ON sends.id = eee.step_log_id
          WHERE eee.org_id = $1 AND eee.is_bot = false
          GROUP BY eee.step_log_id
       ),
       replies AS (
         -- Verbatim the email-response branch of the byChannel roll-up in
         -- GET /:id, so funnel.replied === byChannel.email.responses always.
         SELECT COUNT(*)::int AS n
           FROM emails e
           JOIN prospects p ON p.id = e.prospect_id
          WHERE e.org_id      = $1
            AND p.campaign_id = $2
            AND e.sent_at    >= $3
            AND e.direction   IN ('received','inbound')
            AND EXISTS (
              SELECT 1 FROM emails out_e
              WHERE out_e.org_id      = e.org_id
                AND out_e.prospect_id = e.prospect_id
                AND out_e.direction   = 'sent'
                AND out_e.sent_at     < e.sent_at
            )
       )
       SELECT (SELECT COUNT(*)::int FROM sends)                              AS sent,
              (SELECT COUNT(*)::int FROM hard_bounced)                       AS bounced,
              (SELECT COUNT(*)::int FROM engaged WHERE opened)               AS opened,
              (SELECT COUNT(*)::int FROM engaged WHERE clicked)              AS clicked,
              (SELECT n FROM replies)                                        AS replied`,
      [req.orgId, req.params.id, rangeStart]
    );

    const r = rows[0] || {};
    const sent      = r.sent    || 0;
    const delivered = Math.max(0, sent - (r.bounced || 0));
    res.json({
      range,
      opensAreDirectional: true,
      funnel: {
        sent,
        delivered,
        opened:  r.opened  || 0,
        clicked: r.clicked || 0,
        replied: r.replied || 0,
      },
    });
  } catch (err) {
    console.error('campaigns GET /:id/email-funnel', err);
    res.status(500).json({ error: { message: 'Failed to load email funnel' } });
  }
});

// ── GET /:id/schedule-config — per-field schedule provenance for the config
// screen: campaign raw value (null = inheriting), org config value, and the
// resolver default, so the UI can render "inherit (org: 8) / override" rows
// that exactly match what the firer resolves.
router.get('/:id/schedule-config', async (req, res) => {
  try {
    const campaign = await loadCampaign(req.orgId, req.params.id);
    if (!campaign) return res.status(404).json({ error: { message: 'Campaign not found' } });
    if (!(await CampaignAccess.requireCanAccess(req, res, campaign))) return;

    const { DEFAULTS: SCHED_DEFAULTS } = require('../services/SendingScheduleResolver');
    const [rawRes, orgRes] = await Promise.all([
      pool.query(
        `SELECT start_mode, pacing_mode, cadence_minutes,
                send_window_start_hour, send_window_start_minute,
                send_window_end_hour, send_window_days, send_window_timezone,
                daily_activation_cap
           FROM prospecting_campaigns
          WHERE id = $1 AND org_id = $2`,
        [req.params.id, req.orgId]
      ),
      pool.query(
        `SELECT config FROM org_integrations
          WHERE org_id = $1 AND integration_type = 'prospecting_email'`,
        [req.orgId]
      ),
    ]);
    const raw    = rawRes.rows[0] || {};
    const orgCfg = orgRes.rows[0]?.config || {};

    // column → [org config key, resolver DEFAULTS key]
    const MAP = {
      start_mode:               ['startMode',             'startMode'],
      pacing_mode:              ['pacingMode',            'pacingMode'],
      cadence_minutes:          ['cadenceMinutes',        'cadenceMinutes'],
      send_window_start_hour:   ['sendWindowStartHour',   'sendWindowStartHour'],
      send_window_start_minute: ['sendWindowStartMinute', 'sendWindowStartMinute'],
      send_window_end_hour:     ['sendWindowEndHour',     'sendWindowEndHour'],
      send_window_days:         ['sendWindowDays',        'sendWindowDays'],
      send_window_timezone:     ['sendWindowTimezone',    'sendWindowTimezone'],
      daily_activation_cap:     ['dailyActivationCap',    'linkedinReleaseCap'],
    };
    const fields = {};
    for (const [col, [orgKey, defKey]] of Object.entries(MAP)) {
      fields[col] = {
        campaignValue:  raw[col] ?? null,
        orgValue:       orgCfg[orgKey] ?? null,
        defaultValue:   SCHED_DEFAULTS[defKey] ?? null,
        inheritedValue: orgCfg[orgKey] ?? SCHED_DEFAULTS[defKey] ?? null,
        inheritedFrom:  orgCfg[orgKey] != null ? 'org' : 'default',
      };
    }
    res.json({ fields });
  } catch (err) {
    console.error('campaigns GET /:id/schedule-config', err);
    res.status(500).json({ error: { message: 'Failed to load schedule config' } });
  }
});

// ── GET /:id/prospect-activity/:prospectId — the activity drawer, campaign-scoped ─
//
// Same payload shape as GET /linkedin-connections/funnel/:prospectId (which
// feeds the reporting view's drawer), but authorized like every other drill
// in this file: CampaignAccess.requireCanAccess (owner / manager / admin)
// plus a membership check that the prospect belongs to THIS campaign. The
// funnel endpoint stays owner-scoped — it is a rep's own book; this one is
// "anyone who may see the campaign may see its prospects' stories".
//
// Consumed by ProspectActivityDrawer via CampaignsView. Message ledger rows
// are direction/counted/timestamps ONLY — message text never reaches the
// server (D12), so there is none to show.
router.get('/:id/prospect-activity/:prospectId', async (req, res) => {
  try {
    const campaign = await loadCampaign(req.orgId, req.params.id);
    if (!campaign) return res.status(404).json({ error: { message: 'Campaign not found' } });
    if (!(await CampaignAccess.requireCanAccess(req, res, campaign))) return;

    const pid = parseInt(req.params.prospectId, 10);
    if (!Number.isFinite(pid)) {
      return res.status(400).json({ error: { message: 'Bad prospect id' } });
    }

    const pr = await pool.query(
      `SELECT id, trim(first_name || ' ' || last_name) AS name,
              company_name AS company, linkedin_url AS "linkedinUrl",
              member_urn IS NOT NULL AS "identityResolved", stage,
              channel_data->'linkedin' AS li
         FROM prospects
        WHERE id = $1 AND org_id = $2 AND campaign_id = $3 AND deleted_at IS NULL`,
      [pid, req.orgId, req.params.id]
    );
    if (!pr.rows.length) {
      return res.status(404).json({ error: { message: 'Prospect not found in this campaign' } });
    }

    const [events, activities] = await Promise.all([
      pool.query(
        `SELECT direction, counted, occurred_at AS "occurredAt", thread_urn AS "threadUrn"
           FROM linkedin_message_events
          WHERE org_id = $1 AND prospect_id = $2
          ORDER BY occurred_at DESC
          LIMIT 100`,
        [req.orgId, pid]
      ),
      pool.query(
        `SELECT description, activity_type AS "activityType",
                metadata->>'event' AS event, metadata->>'source' AS source,
                created_at AS "createdAt"
           FROM prospecting_activities
          WHERE org_id = $1 AND prospect_id = $2
          ORDER BY created_at DESC
          LIMIT 50`,
        [req.orgId, pid]
      ),
    ]);

    const p = pr.rows[0];
    const li = p.li || {};
    res.json({
      ok: true,
      prospect: {
        id: p.id, name: p.name, company: p.company,
        linkedinUrl: p.linkedinUrl, identityResolved: p.identityResolved, stage: p.stage,
        requestSentAt: li.request_sent_at || null,
        connectedAt: li.connected_at || null,
        verifiedAt: li.connection_verified_at || null,
        liStatus: li.connection_status || null,
        messageCount: li.message_count || 0,
        replyCount: li.reply_count || 0,
        lastMessageAt: li.last_message_at || null,
        lastReplyAt: li.last_reply_at || null,
      },
      messages: events.rows,
      activities: activities.rows,
    });
  } catch (err) {
    console.error('campaigns GET /:id/prospect-activity/:prospectId', err);
    res.status(500).json({ error: { message: 'Failed to load prospect activity' } });
  }
});

// ── GET /:id/enrolled-prospects — drill-down for the "In sequences" card ─────
//
// Returns the prospects behind metrics.activeEnrollments: campaign members
// with an ACTIVE sequence enrollment, plus which sequence/step they're on.
router.get('/:id/enrolled-prospects', async (req, res) => {
  try {
    const campaign = await loadCampaign(req.orgId, req.params.id);
    if (!campaign) return res.status(404).json({ error: { message: 'Campaign not found' } });
    if (!(await CampaignAccess.requireCanAccess(req, res, campaign))) return;

    const { rows } = await pool.query(
      `SELECT p.id, p.first_name, p.last_name, p.title, p.company_name, p.stage,
              s.name           AS sequence_name,
              se.current_step,
              se.next_step_due,
              COUNT(*) OVER ()::int AS total
         FROM sequence_enrollments se
         JOIN prospects p ON p.id = se.prospect_id AND p.org_id = se.org_id
         JOIN sequences s ON s.id = se.sequence_id
        WHERE se.org_id = $1
          AND p.campaign_id = $2
          AND p.deleted_at IS NULL
          AND se.status = 'active'
     ORDER BY se.next_step_due ASC NULLS LAST, p.id
        LIMIT 500`,
      [req.orgId, req.params.id]
    );

    res.json({
      total: rows[0]?.total || 0,
      prospects: rows.map(r => ({
        id:            r.id,
        name:          `${r.first_name || ''} ${r.last_name || ''}`.trim(),
        title:         r.title || null,
        company_name:  r.company_name || null,
        stage:         r.stage,
        sequence_name: r.sequence_name,
        current_step:  r.current_step,
        next_step_due: r.next_step_due,
      })),
    });
  } catch (err) {
    console.error('campaigns GET /:id/enrolled-prospects', err);
    res.status(500).json({ error: { message: 'Failed to load enrolled prospects' } });
  }
});

// ── GET /:id/linkedin-connection-prospects — drill-down for the LI tiles ─────
//
// Returns the PEOPLE behind the LINKEDIN CONNECTIONS — ALL TIME tiles, using
// predicates identical to the tile counts in GET /:id (and to the list
// query's li_*_count aggregates), so the list always matches the number.
//
//   Query: bucket = sent | accepted | pending
//
//   Returns { bucket, total, prospects: [{ id, name, title, company_name,
//             linkedin_url, stage, connection_status, request_sent_at,
//             connected_at }] }
router.get('/:id/linkedin-connection-prospects', async (req, res) => {
  try {
    const campaign = await loadCampaign(req.orgId, req.params.id);
    if (!campaign) return res.status(404).json({ error: { message: 'Campaign not found' } });
    if (!(await CampaignAccess.requireCanAccess(req, res, campaign))) return;

    const bucket = req.query.bucket;
    if (!['sent', 'accepted', 'pending'].includes(bucket)) {
      return res.status(400).json({ error: { message: 'bucket must be one of: sent, accepted, pending' } });
    }

    // Keep these predicates in lockstep with GET /:id and GET / aggregates.
    const SENT_PRED = `(
         (channel_data->'linkedin'->>'request_sent_at')    IS NOT NULL
      OR (channel_data->'linkedin'->>'connected_at')       IS NOT NULL
      OR (channel_data->'linkedin'->>'connection_status') IN
         ('connection_request_sent','connection_accepted')
    )`;
    const ACCEPTED_PRED = `(
         (channel_data->'linkedin'->>'connected_at')       IS NOT NULL
      OR (channel_data->'linkedin'->>'connection_status') = 'connection_accepted'
    )`;

    const bucketPred =
      bucket === 'sent'     ? SENT_PRED :
      bucket === 'accepted' ? ACCEPTED_PRED :
                              `${SENT_PRED} AND NOT ${ACCEPTED_PRED}`;

    // accepted sorts by acceptance recency; sent/pending by request recency.
    const orderBy = bucket === 'accepted'
      ? `(channel_data->'linkedin'->>'connected_at')    DESC NULLS LAST`
      : `(channel_data->'linkedin'->>'request_sent_at') DESC NULLS LAST`;

    const { rows } = await pool.query(
      `SELECT id, first_name, last_name, title, company_name, linkedin_url, stage,
              channel_data->'linkedin'->>'connection_status' AS connection_status,
              channel_data->'linkedin'->>'request_sent_at'   AS request_sent_at,
              channel_data->'linkedin'->>'connected_at'      AS connected_at,
              COUNT(*) OVER ()::int AS total
         FROM prospects
        WHERE org_id = $1 AND campaign_id = $2 AND deleted_at IS NULL
          AND ${bucketPred}
     ORDER BY ${orderBy}, id DESC
        LIMIT 500`,
      [req.orgId, req.params.id]
    );

    res.json({
      bucket,
      total: rows[0]?.total || 0,
      prospects: rows.map(r => ({
        id:                r.id,
        name:              `${r.first_name || ''} ${r.last_name || ''}`.trim(),
        title:             r.title || null,
        company_name:      r.company_name || null,
        linkedin_url:      r.linkedin_url || null,
        stage:             r.stage,
        connection_status: r.connection_status || null,
        request_sent_at:   r.request_sent_at || null,
        connected_at:      r.connected_at || null,
      })),
    });
  } catch (err) {
    console.error('campaigns GET /:id/linkedin-connection-prospects', err);
    res.status(500).json({ error: { message: 'Failed to load LinkedIn connection prospects' } });
  }
});

// ── PUT /:id — update a campaign ─────────────────────────────────────────────
router.put('/:id', async (req, res) => {
  try {
    const existing = await loadCampaign(req.orgId, req.params.id);
    if (!existing) return res.status(404).json({ error: { message: 'Campaign not found' } });
    if (!(await CampaignAccess.requireCanMutate(req, res, existing))) return;

    const {
      name, description, solution,
      playbook_id, default_sequence_id,
      goal_qualified, start_date, end_date, status,
      activity_type,
      owner_id: bodyOwnerId,
    } = req.body;

    if (activity_type !== undefined && !VALID_ACTIVITY_TYPES.includes(activity_type)) {
      return res.status(400).json({ error: { message: `activity_type must be one of: ${VALID_ACTIVITY_TYPES.join(', ')}` } });
    }

    // ── owner_id reassignment — admin-only ──────────────────────────────────
    // Non-admins who pass owner_id get a clear 403 rather than a silent strip,
    // matching the project principle that the user always has visibility into
    // what happened. Admins can reassign to any active org member.
    let resolvedOwnerId = existing.owner_id;
    const ownerProvided = Object.prototype.hasOwnProperty.call(req.body, 'owner_id');
    if (ownerProvided) {
      const newOwnerId = parseInt(bodyOwnerId, 10);
      if (!Number.isFinite(newOwnerId)) {
        return res.status(400).json({ error: { message: 'owner_id must be a valid user id' } });
      }
      if (newOwnerId !== existing.owner_id) {
        const callerIsAdmin = await CampaignAccess.isAdmin(req);
        if (!callerIsAdmin) {
          return res.status(403).json({ error: {
            message: "You don't have permission to reassign campaign ownership. Only admins can change owner_id.",
          } });
        }
        const ownerCheck = await pool.query(
          `SELECT 1 FROM org_users WHERE user_id = $1 AND org_id = $2 AND is_active = TRUE`,
          [newOwnerId, req.orgId]
        );
        if (!ownerCheck.rows.length) {
          return res.status(400).json({ error: {
            message: `owner_id ${newOwnerId} is not an active member of this org.`,
          } });
        }
        resolvedOwnerId = newOwnerId;
      }
    }

    if (status !== undefined && !VALID_STATUS.includes(status)) {
      return res.status(400).json({ error: { message: `status must be one of: ${VALID_STATUS.join(', ')}` } });
    }
    if (playbook_id) {
      const pb = await pool.query(
        `SELECT id, type FROM playbooks WHERE id = $1 AND org_id = $2`,
        [playbook_id, req.orgId]
      );
      if (!pb.rows.length || pb.rows[0].type !== 'prospecting') {
        return res.status(400).json({ error: { message: 'Invalid prospecting playbook' } });
      }
    }
    if (default_sequence_id) {
      const sq = await pool.query(
        `SELECT id FROM sequences WHERE id = $1 AND org_id = $2`,
        [default_sequence_id, req.orgId]
      );
      if (!sq.rows.length) {
        return res.status(400).json({ error: { message: 'Invalid sequence' } });
      }
    }

    // Sending-schedule overrides — 3-way semantic per field:
    //   - absent from body         → keep existing column value
    //   - present with null/'' value → clear override (NULL → inherit org)
    //   - present with a value     → validate + set
    const sched = validateAndCoerceSchedule(req.body);
    if (sched.errors.length) {
      return res.status(400).json({ error: { message: sched.errors.join('; ') } });
    }
    const has = (k) => Object.prototype.hasOwnProperty.call(req.body, k);
    const incomingDailyCap = has('daily_activation_cap') || has('dailyActivationCap') || has('linkedinReleaseCap');
    const incomingStart    = has('send_window_start_hour') || has('sendWindowStartHour');
    const incomingStartMin = has('send_window_start_minute') || has('sendWindowStartMinute');
    const incomingEnd      = has('send_window_end_hour')   || has('sendWindowEndHour');
    const incomingDays     = has('send_window_days')       || has('sendWindowDays');
    const incomingTz       = has('send_window_timezone')   || has('sendWindowTimezone');
    const incomingStartMode = has('start_mode')  || has('startMode');
    const incomingPacing    = has('pacing_mode')  || has('pacingMode');
    const incomingCadence   = has('cadence_minutes') || has('cadenceMinutes');

    // share_weight: validate if present in the body.
    const incomingShareWeight = has('share_weight') || has('shareWeight');
    let shareWeightUpd = existing.share_weight;
    if (incomingShareWeight) {
      const raw = req.body.share_weight ?? req.body.shareWeight;
      if (raw === null || raw === '' || raw === undefined) {
        shareWeightUpd = null; // explicit clear → unset (excluded in weighted mode)
      } else {
        const w = parseInt(raw, 10);
        if (!Number.isFinite(w) || w < 0 || w > 100) {
          return res.status(400).json({ error: { message: 'share_weight must be 0..100' } });
        }
        shareWeightUpd = w;
      }
    }

    // Per-campaign sender selection (Phase 2): only changes if present in body.
    const senderSel = await coerceSenderIds(req.body, req.orgId, resolvedOwnerId);
    if (senderSel.error) {
      return res.status(400).json({ error: { message: senderSel.error } });
    }
    const senderIdsUpd = senderSel.provided ? senderSel.ids : existing.sender_account_ids;

    // ── Agency Phase 1 (2026_52): client_id — 3-way semantics like the
    // schedule fields: absent → keep existing; present null/'' → clear;
    // present value → validate (org + not archived) and set.
    const incomingClientId = has('client_id') || has('clientId');
    let clientIdUpd = existing.client_id;
    if (incomingClientId) {
      const rawClientId = req.body.client_id ?? req.body.clientId;
      if (rawClientId === null || rawClientId === '' || rawClientId === undefined) {
        clientIdUpd = null;   // explicit clear → ordinary campaign again
      } else {
        const cid = parseInt(rawClientId, 10);
        if (!Number.isFinite(cid)) {
          return res.status(400).json({ error: { message: 'client_id must be a valid client id' } });
        }
        const cl = await pool.query(
          `SELECT id FROM clients WHERE id = $1 AND org_id = $2 AND archived_at IS NULL`,
          [cid, req.orgId]
        );
        if (!cl.rows.length) {
          return res.status(400).json({ error: { message: 'Client not found in this org (or archived)' } });
        }
        clientIdUpd = cid;
      }
    }

    // Build a COALESCE-style partial update: only provided fields change.
    const { rows } = await pool.query(
      `UPDATE prospecting_campaigns SET
         name                   = COALESCE($3, name),
         description            = $4,
         solution               = $5,
         playbook_id            = $6,
         default_sequence_id    = $7,
         goal_qualified         = $8,
         start_date             = $9,
         end_date               = $10,
         status                 = COALESCE($11, status),
         activity_type          = COALESCE($24, activity_type),
         daily_activation_cap   = $12,
         send_window_start_hour = $13,
         send_window_end_hour   = $14,
         send_window_days       = $15,
         send_window_timezone   = $16,
         owner_id               = $17,
         send_window_start_minute = $18,
         start_mode             = $19,
         pacing_mode            = $20,
         cadence_minutes        = $21,
         share_weight           = $22,
         sender_account_ids     = $23,
         client_id              = $25
       WHERE id = $1 AND org_id = $2
       RETURNING id`,
      [
        req.params.id, req.orgId,
        name !== undefined ? (name && name.trim()) : null,
        description !== undefined ? description : existing.description,
        solution    !== undefined ? solution    : existing.solution,
        playbook_id !== undefined ? (playbook_id || null) : existing.playbook_id,
        default_sequence_id !== undefined ? (default_sequence_id || null) : existing.default_sequence_id,
        goal_qualified !== undefined ? (goal_qualified || null) : existing.goal_qualified,
        start_date !== undefined ? (start_date || null) : existing.start_date,
        end_date   !== undefined ? (end_date   || null) : existing.end_date,
        status !== undefined ? status : null,
        // Schedule fields: use validated value if present in body, else existing
        incomingDailyCap ? sched.values.daily_activation_cap   : existing.daily_activation_cap,
        incomingStart    ? sched.values.send_window_start_hour : existing.send_window_start_hour,
        incomingEnd      ? sched.values.send_window_end_hour   : existing.send_window_end_hour,
        incomingDays     ? sched.values.send_window_days       : existing.send_window_days,
        incomingTz       ? sched.values.send_window_timezone   : existing.send_window_timezone,
        // owner_id: resolvedOwnerId is existing.owner_id unless an admin
        // explicitly reassigned via owner_id in the body (validated above).
        resolvedOwnerId,
        incomingStartMin  ? sched.values.send_window_start_minute : existing.send_window_start_minute,
        incomingStartMode ? sched.values.start_mode              : existing.start_mode,
        incomingPacing    ? sched.values.pacing_mode             : existing.pacing_mode,
        incomingCadence   ? sched.values.cadence_minutes         : existing.cadence_minutes,
        shareWeightUpd,
        senderIdsUpd,       // sender_account_ids — NULL = all senders
        activity_type !== undefined ? activity_type : null,  // $24 — COALESCE keeps existing when null
        clientIdUpd,        // $25 — client_id (Agency Phase 1); NULL = ordinary campaign
      ]
    );
    if (!rows.length) return res.status(404).json({ error: { message: 'Campaign not found' } });

    // ── Agency Phase 1: stamp EXISTING member prospects when this campaign
    // carries a client. The DB trigger (2026_52) only fires on writes that
    // touch prospects.campaign_id, so prospects already sitting in the
    // campaign need this pass. Same rules as the trigger: set-if-null only
    // (never reassigns a prospect that already belongs to a client), and
    // clearing a campaign's client does NOT strip membership from prospects.
    //
    // Deliberately NOT gated on "client changed": the statement is idempotent
    // (client_id IS NULL predicate), so running it on every save that carries
    // a non-null client makes a partially-failed earlier save retryable by
    // simply re-saving, and heals any members that entered the campaign
    // through a path that predates the trigger.
    let prospectsStamped = 0;
    if (incomingClientId && clientIdUpd != null) {
      const stampRes = await pool.query(
        `UPDATE prospects
            SET client_id = $1, updated_at = CURRENT_TIMESTAMP
          WHERE campaign_id = $2 AND org_id = $3
            AND client_id IS NULL AND deleted_at IS NULL`,
        [clientIdUpd, req.params.id, req.orgId]
      );
      prospectsStamped = stampRes.rowCount;
    }

    const campaign = await loadCampaign(req.orgId, req.params.id);
    res.json({ campaign, prospectsStamped });
  } catch (err) {
    console.error('campaigns PUT /:id', err);
    res.status(500).json({ error: { message: 'Failed to update campaign' } });
  }
});

// ── PUT /:id/sending — pause / resume ALL sending for a campaign ──────────────
// Operational brake, distinct from the lifecycle `status` column. Body:
//   { "paused": true }   → stop; { "paused": false } → resume.
//
// Pausing does NOT touch enrollment status. It flips prospecting_campaigns
// .sending_paused, which the firer's due query AND its materializeRows top-up
// both guard on (2026_51), so no new step fires and none is re-materialized.
// Any rows already 'scheduled'/'sending' for this campaign are marked 'skipped'
// in the same txn so the Scheduled tab reflects reality immediately.
//
// Resuming clears the flag. Because enrollments stayed 'active' with their
// (now overdue) next_step_due intact, the next in-window tick re-selects them
// and the top-up rebuilds fresh scheduled rows — no re-stamp, no bulk write.
router.put('/:id/sending', async (req, res) => {
  const paused = req.body?.paused;
  if (typeof paused !== 'boolean') {
    return res.status(400).json({ error: { message: 'Body must include { paused: true | false }' } });
  }

  const client = await pool.connect();
  try {
    const existing = await loadCampaign(req.orgId, req.params.id);
    if (!existing) return res.status(404).json({ error: { message: 'Campaign not found' } });
    if (!(await CampaignAccess.requireCanMutate(req, res, existing))) return;

    await client.query('BEGIN');

    const { rows } = await client.query(
      `UPDATE prospecting_campaigns
          SET sending_paused = $1, updated_at = NOW()
        WHERE id = $2 AND org_id = $3
      RETURNING id, sending_paused`,
      [paused, req.params.id, req.orgId]
    );

    // When pausing, cancel pending auto-send rows for this campaign's prospects
    // so nothing that was already materialized fires, and the queue reflects the
    // pause at once. Mirrors the enrollment pause/stop routes' row-skip step.
    // 'sending' rows mid-flight are best-effort: if the provider call already
    // returned, confirmSent will log NOT_CLAIMABLE and move on.
    let skipped = 0;
    if (paused) {
      const skip = await client.query(
        `UPDATE sequence_step_logs ssl
            SET status = 'skipped'
           FROM sequence_enrollments se, prospects p
          WHERE se.id = ssl.enrollment_id
            AND p.id  = ssl.prospect_id
            AND ssl.org_id = $1
            AND p.campaign_id = $2
            AND ssl.status IN ('scheduled','sending')`,
        [req.orgId, req.params.id]
      );
      skipped = skip.rowCount;
    }

    await client.query('COMMIT');
    res.json({
      campaign_id: rows[0].id,
      sending_paused: rows[0].sending_paused,
      rows_skipped: skipped,
    });
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    console.error('campaigns PUT /:id/sending', err);
    res.status(500).json({ error: { message: 'Failed to update campaign sending state' } });
  } finally {
    client.release();
  }
});

// ── DELETE /:id — archive (default) or hard-delete (?hard=true) ───────────────
// Archive keeps the campaign + un-assigns nothing (members stay linked).
// Hard delete relies on the FK ON DELETE SET NULL to un-assign prospects.
//
// CASCADE (?withProspects=true) — ADMIN ONLY. Tears the campaign down for a
// clean redo: cancels active/paused enrollments for the campaign's prospects
// (so the firer stops sending), soft-deletes those prospects (deleted_at —
// recoverable), then archives or hard-deletes the campaign. Always preview
// first with ?dryRun=true to see the counts before committing.
router.delete('/:id', async (req, res) => {
  try {
    const existing = await loadCampaign(req.orgId, req.params.id);
    if (!existing) return res.status(404).json({ error: { message: 'Campaign not found' } });
    if (!(await CampaignAccess.requireCanMutate(req, res, existing))) return;

    const hard          = req.query.hard === 'true';
    const withProspects = req.query.withProspects === 'true';
    const dryRun        = req.query.dryRun === 'true';

    // ── Cascade path ────────────────────────────────────────────────────────
    if (withProspects) {
      // Layered delete permission (replaces the old admin-only gate):
      //   • admin/owner            → always allowed
      //   • the campaign owner     → allowed iff the org switch is ON and the
      //                              campaign is not delete_locked
      //   • managers / anyone else → denied
      // This single gate sits before BOTH the dryRun branch and the commit
      // branch below, so it covers preview and commit alike.
      const { owner_delete_enabled } = await CampaignSettings.getForOrg(req.orgId);
      const { allowed, reason } = await CampaignAccess.canDeleteCampaign(
        req, existing, { ownerDeleteEnabled: owner_delete_enabled }
      );
      if (!allowed) {
        return res.status(403).json({ error: { message: reason } });
      }

      // Count what would be affected.
      const [pRes, eRes] = await Promise.all([
        pool.query(
          `SELECT COUNT(*)::int AS n FROM prospects
            WHERE org_id = $1 AND campaign_id = $2 AND deleted_at IS NULL`,
          [req.orgId, req.params.id]
        ),
        pool.query(
          `SELECT COUNT(*)::int AS n
             FROM sequence_enrollments se
             JOIN prospects p ON p.id = se.prospect_id
            WHERE p.org_id = $1 AND p.campaign_id = $2
              AND se.status IN ('active', 'paused')`,
          [req.orgId, req.params.id]
        ),
      ]);
      const prospectCount   = pRes.rows[0]?.n || 0;
      const enrollmentCount = eRes.rows[0]?.n || 0;

      if (dryRun) {
        return res.json({
          dryRun: true,
          campaign:  { id: existing.id, name: existing.name },
          wouldDelete: {
            prospects:         prospectCount,   // soft-deleted (recoverable)
            activeEnrollments: enrollmentCount, // cancelled (sending stops)
            campaign:          hard ? 'hard-deleted' : 'archived',
          },
          message: `Will stop ${enrollmentCount} enrollment(s), soft-delete ${prospectCount} prospect(s), and ${hard ? 'permanently delete' : 'archive'} the campaign. Re-send without dryRun to confirm.`,
        });
      }

      // Commit atomically.
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        // 1. Stop active/paused enrollments for this campaign's prospects so the
        //    firer no longer processes them.
        const stopRes = await client.query(
          `UPDATE sequence_enrollments se
              SET status = 'stopped', stopped_at = NOW(), stop_reason = 'campaign_deleted'
             FROM prospects p
            WHERE se.prospect_id = p.id
              AND p.org_id = $1 AND p.campaign_id = $2
              AND se.status IN ('active', 'paused')`,
          [req.orgId, req.params.id]
        );
        // 2. Soft-delete the prospects (recoverable — deleted_at only).
        const delRes = await client.query(
          `UPDATE prospects SET deleted_at = NOW()
            WHERE org_id = $1 AND campaign_id = $2 AND deleted_at IS NULL`,
          [req.orgId, req.params.id]
        );
        // 3. Remove or archive the campaign.
        if (hard) {
          await client.query(
            `DELETE FROM prospecting_campaigns WHERE id = $1 AND org_id = $2`,
            [req.params.id, req.orgId]
          );
        } else {
          await client.query(
            `UPDATE prospecting_campaigns SET status = 'archived'
              WHERE id = $1 AND org_id = $2`,
            [req.params.id, req.orgId]
          );
        }
        await client.query('COMMIT');
        return res.json({
          ok: true,
          cascade: true,
          campaign: hard ? 'deleted' : 'archived',
          enrollmentsStopped: stopRes.rowCount,
          prospectsDeleted:   delRes.rowCount,
        });
      } catch (txErr) {
        await client.query('ROLLBACK');
        console.error('campaigns DELETE cascade', txErr);
        return res.status(500).json({ error: { message: 'Cascade delete failed: ' + txErr.message } });
      } finally {
        client.release();
      }
    }

    // ── Campaign-only path (unchanged) ────────────────────────────────────────
    if (hard) {
      await pool.query(
        `DELETE FROM prospecting_campaigns WHERE id = $1 AND org_id = $2`,
        [req.params.id, req.orgId]
      );
      return res.json({ ok: true, deleted: true });
    }

    await pool.query(
      `UPDATE prospecting_campaigns SET status = 'archived'
        WHERE id = $1 AND org_id = $2`,
      [req.params.id, req.orgId]
    );
    res.json({ ok: true, archived: true });
  } catch (err) {
    console.error('campaigns DELETE /:id', err);
    res.status(500).json({ error: { message: 'Failed to delete campaign' } });
  }
});

// ── PUT /:id/delete-lock — set/clear a campaign's delete lock ─────────────────
// body: { locked: boolean }
//
// Gated by CampaignAccess.canSetCampaignLock (NOT requireCanMutate): admins/
// owners may lock any campaign; a manager may lock/unlock only campaigns owned
// by someone in their team (req.subordinateIds); the campaign owner may NOT
// lock/unlock their own. Stamps delete_locked_by / delete_locked_at for audit.
router.put('/:id/delete-lock', async (req, res) => {
  try {
    const existing = await loadCampaign(req.orgId, req.params.id);
    if (!existing) return res.status(404).json({ error: { message: 'Campaign not found' } });

    const { allowed, reason } = await CampaignAccess.canSetCampaignLock(req, existing);
    if (!allowed) {
      return res.status(403).json({ error: { message: reason } });
    }

    const { locked } = req.body || {};
    if (typeof locked !== 'boolean') {
      return res.status(400).json({ error: { message: 'locked must be a boolean' } });
    }

    // delete_locked_by is INTEGER; null it out when unlocking. Computed in JS
    // (rather than a CASE) so the parameter is assigned directly to the column
    // and Postgres types it correctly — a CASE with two untyped branches
    // ($2 + NULL) collapses to text and fails against the integer column.
    const actorId = locked ? req.userId : null;

    const { rows } = await pool.query(
      `UPDATE prospecting_campaigns
          SET delete_locked    = $1,
              delete_locked_by = $2,
              delete_locked_at = CASE WHEN $1 THEN NOW() ELSE NULL END
        WHERE id = $3 AND org_id = $4
      RETURNING id, delete_locked, delete_locked_by, delete_locked_at`,
      [locked, actorId, req.params.id, req.orgId]
    );
    if (rows.length === 0) {
      return res.status(404).json({ error: { message: 'Campaign not found' } });
    }
    res.json({ ok: true, ...rows[0] });
  } catch (err) {
    console.error('campaigns PUT /:id/delete-lock', err);
    res.status(500).json({ error: { message: 'Failed to update delete lock' } });
  }
});

// ── POST /:id/reeval-signals — re-evaluate this campaign's pool → queue ───────
// Signal-Based Campaigns (P5). Sweeps every prospect in the campaign through
// CampaignSignalEngine and reconciles their signal actions (upsert qualifiers,
// resolve those that dropped out). Used by the "refresh queue" affordance and
// after a bulk import (P6). Freshness is applied inside the engine, so this is
// also a manual "age the stale signals now" trigger.
router.post('/:id/reeval-signals', async (req, res) => {
  try {
    const campaign = await loadCampaign(req.orgId, req.params.id);
    if (!campaign) return res.status(404).json({ error: { message: 'Campaign not found' } });
    if (!(await CampaignAccess.requireCanMutate(req, res, campaign))) return;

    const result = await SignalActionSurfacer.surfaceForCampaign({ orgId: req.orgId, campaign });
    res.json({ result });
  } catch (err) {
    console.error('campaigns POST /:id/reeval-signals', err);
    res.status(500).json({ error: { message: 'Failed to re-evaluate campaign signals' } });
  }
});

// ── POST /:id/prospects — assign prospects to this campaign ───────────────────
// body: { prospectIds: [int] }
router.post('/:id/prospects', async (req, res) => {
  const { prospectIds } = req.body;
  if (!Array.isArray(prospectIds) || prospectIds.length === 0) {
    return res.status(400).json({ error: { message: 'prospectIds[] is required' } });
  }
  try {
    const campaign = await loadCampaign(req.orgId, req.params.id);
    if (!campaign) return res.status(404).json({ error: { message: 'Campaign not found' } });
    if (!(await CampaignAccess.requireCanMutate(req, res, campaign))) return;

    // Only re-assign prospects that actually belong to this org.
    const { rows } = await pool.query(
      `UPDATE prospects
          SET campaign_id = $1
        WHERE org_id = $2
          AND id = ANY($3::int[])
          AND deleted_at IS NULL
       RETURNING id`,
      [req.params.id, req.orgId, prospectIds]
    );
    res.json({ ok: true, assigned: rows.length, prospectIds: rows.map(r => r.id) });
  } catch (err) {
    console.error('campaigns POST /:id/prospects', err);
    res.status(500).json({ error: { message: 'Failed to assign prospects' } });
  }
});

// ── DELETE /:id/prospects — un-assign prospects from this campaign ────────────
// body: { prospectIds: [int] }
router.delete('/:id/prospects', async (req, res) => {
  const { prospectIds } = req.body;
  if (!Array.isArray(prospectIds) || prospectIds.length === 0) {
    return res.status(400).json({ error: { message: 'prospectIds[] is required' } });
  }
  try {
    const campaign = await loadCampaign(req.orgId, req.params.id);
    if (!campaign) return res.status(404).json({ error: { message: 'Campaign not found' } });
    if (!(await CampaignAccess.requireCanMutate(req, res, campaign))) return;

    // Removing someone from a campaign must also take them out of the
    // campaign's sequence, otherwise the firer keeps sending. Stop their
    // active/paused enrollments FIRST (scoped to prospects currently in THIS
    // campaign, before we null campaign_id) so a partial failure can never
    // leave a prospect untagged but still enrolled. Mirrors the campaign-delete
    // cascade's stop step.
    const stopRes = await pool.query(
      `UPDATE sequence_enrollments se
          SET status = 'stopped', stopped_at = NOW(), stop_reason = 'removed_from_campaign'
         FROM prospects p
        WHERE se.prospect_id = p.id
          AND p.org_id      = $1
          AND p.campaign_id = $2
          AND p.id = ANY($3::int[])
          AND se.status IN ('active', 'paused')`,
      [req.orgId, req.params.id, prospectIds]
    );

    const { rows } = await pool.query(
      `UPDATE prospects
          SET campaign_id = NULL
        WHERE org_id = $1
          AND campaign_id = $2
          AND id = ANY($3::int[])
       RETURNING id`,
      [req.orgId, req.params.id, prospectIds]
    );
    res.json({ ok: true, removed: rows.length, enrollmentsStopped: stopRes.rowCount });
  } catch (err) {
    console.error('campaigns DELETE /:id/prospects', err);
    res.status(500).json({ error: { message: 'Failed to remove prospects' } });
  }
});

// ── POST /:id/enroll-all — enroll campaign members into a sequence ───────────
// body: { sequenceId?, onlyStage?, skipEnrolled = true }
//   sequenceId  — defaults to the campaign's default_sequence_id
//   onlyStage   — optional: enroll only members in this stage
//   skipEnrolled — skip prospects already in an ACTIVE enrollment of that seq
//
// This thin wrapper resolves the member list, then inserts enrollments using
// the exact same logic as POST /api/sequences/enroll (kept in sync with it).
router.post('/:id/enroll-all', async (req, res) => {
  const { sequenceId: bodySeqId, onlyStage, skipEnrolled = true } = req.body;

  const client = await pool.connect();
  try {
    const campaign = await loadCampaign(req.orgId, req.params.id);
    if (!campaign) return res.status(404).json({ error: { message: 'Campaign not found' } });
    if (!(await CampaignAccess.requireCanMutate(req, res, campaign))) return;

    const sequenceId = bodySeqId || campaign.default_sequence_id;
    if (!sequenceId) {
      return res.status(400).json({
        error: { message: 'No sequence specified and campaign has no default sequence' },
      });
    }

    // Validate sequence is active and in-org.
    const seqRes = await client.query(
      `SELECT * FROM sequences WHERE id = $1 AND org_id = $2 AND status = 'active'`,
      [sequenceId, req.orgId]
    );
    if (!seqRes.rows.length) {
      return res.status(404).json({ error: { message: 'Active sequence not found' } });
    }
    const sequenceName = seqRes.rows[0].name;

    // First step delay → next_step_due.
    const firstStepRes = await client.query(
      `SELECT delay_days, delay_hours FROM sequence_steps
        WHERE sequence_id = $1 ORDER BY step_order LIMIT 1`,
      [sequenceId]
    );
    const firstDelayDays  = firstStepRes.rows[0]?.delay_days  ?? 0;
    const firstDelayHours = firstStepRes.rows[0]?.delay_hours ?? 0;

    // Resolve member list.
    const memberParams = [req.orgId, req.params.id];
    let stageFilter = '';
    if (onlyStage) {
      memberParams.push(onlyStage);
      stageFilter = `AND stage = $${memberParams.length}`;
    }
    const memberRes = await client.query(
      `SELECT id FROM prospects
        WHERE org_id = $1 AND campaign_id = $2 AND deleted_at IS NULL ${stageFilter}`,
      memberParams
    );
    const memberIds = memberRes.rows.map(r => r.id);
    if (memberIds.length === 0) {
      return res.json({ enrolled: 0, skipped: [], message: 'No matching prospects in campaign' });
    }

    // Pre-fetch active enrollments for this sequence to skip duplicates.
    let alreadyEnrolled = new Set();
    if (skipEnrolled) {
      const enrRes = await client.query(
        `SELECT prospect_id FROM sequence_enrollments
          WHERE sequence_id = $1 AND org_id = $2 AND status = 'active'
            AND prospect_id = ANY($3::int[])`,
        [sequenceId, req.orgId, memberIds]
      );
      alreadyEnrolled = new Set(enrRes.rows.map(r => r.prospect_id));
    }

    const nextDue = new Date(Date.now()
      + (firstDelayDays * 24 + firstDelayHours) * 3600000);

    await client.query('BEGIN');
    const enrolled = [];
    const skipped  = [];

    for (const prospectId of memberIds) {
      if (skipEnrolled && alreadyEnrolled.has(prospectId)) {
        skipped.push({ prospectId, reason: 'already enrolled' });
        continue;
      }
      try {
        // A/B (2026_47): pure hash of (experiment_id, prospect_id). Both null
        // when the sequence has no running experiment.
        const { experimentId, variantKey } = await ExperimentAssigner.assignVariant(client, {
          sequenceId, prospectId,
        });

        const er = await client.query(
          `INSERT INTO sequence_enrollments
                 (org_id, sequence_id, prospect_id, enrolled_by, next_step_due, personalised_steps, variant_key, experiment_id)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
           ON CONFLICT (sequence_id, prospect_id) DO NOTHING
           RETURNING id`,
          [req.orgId, sequenceId, prospectId, req.user.userId, nextDue, JSON.stringify({}), variantKey, experimentId]
        );
        if (er.rows.length) {
          // Stamp the identity cursor (current_step_id + channel) for the first step.
          await EnrollmentStepResolver.stampInitialCursor(client, er.rows[0].id, sequenceId);
          enrolled.push(prospectId);
          // Mirror the activity write done by /api/sequences/enroll.
          try {
            await client.query(
              `INSERT INTO prospecting_activities
                     (org_id, prospect_id, user_id, activity_type, description, metadata)
               VALUES ($1, $2, $3, 'sequence_enrolled', $4, $5)`,
              [
                req.orgId, prospectId, req.user.userId,
                `Enrolled in sequence "${sequenceName}" via campaign "${campaign.name}"`,
                JSON.stringify({
                  sequenceId, sequenceName,
                  enrollmentId: er.rows[0].id,
                  campaignId: campaign.id, campaignName: campaign.name,
                }),
              ]
            );
          } catch (actErr) {
            console.warn('enroll-all: activity log failed for prospect', prospectId, actErr.message);
          }
        } else {
          skipped.push({ prospectId, reason: 'already enrolled' });
        }
      } catch (err) {
        skipped.push({ prospectId, reason: err.message });
      }
    }

    await client.query('COMMIT');
    res.json({ enrolled: enrolled.length, skipped, sequenceId, sequenceName });
  } catch (err) {
    try { await client.query('ROLLBACK'); } catch (_) { /* noop */ }
    console.error('campaigns POST /:id/enroll-all', err);
    res.status(500).json({ error: { message: 'Enroll-all failed' } });
  } finally {
    client.release();
  }
});

// ═════════════════════════════════════════════════════════════════════════════
// GET /:id/sequence-health
// Sprint 4 (Group C). Campaign-scoped sequence health — same shape as
// /api/sequences/health but restricted to enrollments whose prospects are
// in this campaign.
//
// Phase 3 extensions (all optional, additive — backward compat preserved):
//   ?depth=direct|plus1|plus2|all   filter to a scope of enrolled_by users
//   ?userIds=1,2,3                   filter to a specific set (∩ with scope)
//   ?startDate=ISO  ?endDate=ISO     time window
//   ?windowDays=N                    alternative to start/end (default 7)
//   ?groupBy=sequence|user|both      defaults to 'sequence' (current behavior).
//                                    'user' or 'both' add a byUser[] array.
//
// ─────────────────────────────────────────────────────────────────────────────
// 2026-07 FIX — the drill-down disagreed with the campaign row above it
//
// Two independent bugs made Team reporting → By campaign → (drill down) show
// different numbers from the row that was clicked.
//
//   BUG 1 — REPLIES CAME FROM A COLUMN NOTHING WRITES.
//     This endpoint counted `ssl.status = 'replied'`. Nothing in the codebase
//     ever writes that value (SequenceStepFirer writes 'replied' to
//     sequence_enrollments.status, not to sequence_step_logs.status), so
//     `replied` and every reply rate on this surface were structurally 0 —
//     while the campaign row, which sources replies from `emails` +
//     `prospecting_activities`, showed 5 replies at 45.5%.
//     Replies now come from services/ReplyEventsQuery.js, the SAME builder
//     reporting.routes.js uses. The two surfaces reconcile by construction.
//
//   BUG 2 — THE WINDOW PICKER WAS IGNORED.
//     The 24h/7d aggregates were hardcoded to NOW() - interval. The frontend
//     passes ?windowDays=30 (or start/end), but that only ever reached the
//     byUser block. So with "30d" selected the tiles summed 7d numbers, and
//     the by-rep table below them summed 30d numbers — two windows, one panel.
//     Each health[] row now carries an additional `window` block bounded by
//     the requested window. last24h/last7d are UNCHANGED in shape and remain
//     hardcoded, because CampaignsView.js's SequenceHealthTile calls this
//     endpoint with no params at all and reads them directly.
//
//   Also: the per-sequence `stalled` counter anchored on NOW() - 7 days while
//   reporting.routes.js anchors on endDate - 7 days. Identical for trailing
//   windows, divergent for any Custom range ending in the past. Now aligned.
//
// The 24h/7d `replied` counters are ALSO now sourced from reply_events, so
// CampaignsView's "Idle" pill and its "N replied" line stop reading 0 forever.
//
// CHANNEL SPLIT. `sent` counts every step log regardless of channel, so a
// blended reply rate divides EMAIL replies by EMAIL + LINKEDIN sends. The
// `window` block and byUser[] therefore expose sentEmail / sentLinkedin /
// repliedEmail / repliedLinkedin and per-channel rates, matching the columns
// the campaign, rep and sequence tabs now render.
// ═════════════════════════════════════════════════════════════════════════════
router.get('/:id/sequence-health', async (req, res) => {
  try {
    const campaign = await loadCampaign(req.orgId, req.params.id);
    if (!campaign) return res.status(404).json({ error: { message: 'Campaign not found' } });
    if (!(await CampaignAccess.requireCanAccess(req, res, campaign))) return;

    const day  = `'24 hours'::interval`;
    const week = `'7 days'::interval`;

    const campaignId = parseInt(req.params.id, 10);

    // ── Phase 3: parse optional filters ──────────────────────────────
    const groupBy = ['sequence', 'user', 'both'].includes(req.query.groupBy)
      ? req.query.groupBy
      : 'sequence';

    const hasUserFilter = req.query.userIds !== undefined || req.query.depth !== undefined;
    let scope = null;
    let userFilterIds = null;
    if (hasUserFilter || groupBy !== 'sequence') {
      const explicitUserIds = req.query.userIds !== undefined
        ? String(req.query.userIds).split(',').map(s => parseInt(s.trim(), 10)).filter(Number.isInteger)
        : null;
      scope = await ReportingScopeService.resolveReportingScope(
        req.user.userId,
        req.orgId,
        { depth: req.query.depth, explicitUserIds }
      );
      userFilterIds = scope.userIds;
    }

    // ── The requested window, parsed BEFORE the aggregates (Bug 2) ────
    // _parseCampaignHealthWindow defaults to the trailing 7 days, so a caller
    // that passes nothing (CampaignsView.js) gets window === last7d and sees
    // no behaviour change.
    const w = _parseCampaignHealthWindow(req.query);

    // reply_events is scanned once and bucketed three ways (24h / 7d / window),
    // so its range must cover all three. For any trailing window this is just
    // the window itself; for a Custom range ending last month it widens to
    // include the trailing 7 days that last24h/last7d still describe.
    const nowMs      = Date.now();
    const sevenAgoMs = nowMs - 7 * 24 * 60 * 60 * 1000;
    const cteStartISO = new Date(Math.min(new Date(w.startISO).getTime(), sevenAgoMs)).toISOString();
    const cteEndISO   = new Date(Math.max(new Date(w.endISO).getTime(), nowMs)).toISOString();

    // Rep-filter clause appended to each state query when a user filter
    // was opted into explicitly. When groupBy is non-default but no
    // user filter was set, the state queries stay unfiltered for
    // back-compat (only the byUser block uses the scope).
    let stateRepClause = '';
    const stateRepParam = (hasUserFilter && userFilterIds) ? userFilterIds : null;
    if (stateRepParam) {
      stateRepClause = `AND se.enrolled_by = ANY($3::int[])`;
    }

    // Each query below gets its OWN param array. They used to share one, which
    // is why the window bounds could not be added without breaking the others:
    // Postgres rejects a bind that supplies a parameter the statement does not
    // reference. Positions $1/$2 (+ $3 when rep-filtered) are identical across
    // all of them, so stateRepClause stays a single shared string.
    const base = stateRepParam ? [req.orgId, req.params.id, stateRepParam]
                               : [req.orgId, req.params.id];

    // ── Per-sequence aggregates ──────────────────────────────────────
    // Scoped to this campaign's enrollments. We list only sequences that
    // actually have at least one campaign enrollment — different from the
    // global /health endpoint which lists every active sequence in the org.
    //
    // NOTE: no `replied` counters here. ssl.status never reaches 'replied'
    // (see services/ReplyEventsQuery.js header). Replies are joined in below.
    const aggParams = [...base, w.startISO, w.endISO];
    const wStart = `$${aggParams.length - 1}`;
    const wEnd   = `$${aggParams.length}`;
    const inWindow = `ssl.fired_at >= ${wStart}::timestamptz AND ssl.fired_at <= ${wEnd}::timestamptz`;

    const aggRes = await pool.query(
      `SELECT
         s.id    AS sequence_id,
         s.name  AS sequence_name,
         COUNT(*) FILTER (WHERE ssl.fired_at >= NOW() - ${day}  AND ssl.status = 'draft')::int                              AS drafts_24h,
         COUNT(*) FILTER (WHERE ssl.fired_at >= NOW() - ${day}  AND ssl.status IN ('sent','completed'))::int                AS sent_24h,
         COUNT(*) FILTER (WHERE ssl.fired_at >= NOW() - ${day}  AND ssl.status = 'failed')::int                             AS failed_24h,
         COUNT(*) FILTER (WHERE ssl.fired_at >= NOW() - ${week} AND ssl.status = 'draft')::int                              AS drafts_7d,
         COUNT(*) FILTER (WHERE ssl.fired_at >= NOW() - ${week} AND ssl.status IN ('sent','completed'))::int                AS sent_7d,
         COUNT(*) FILTER (WHERE ssl.fired_at >= NOW() - ${week} AND ssl.status = 'failed')::int                             AS failed_7d,
         COUNT(*) FILTER (WHERE ${inWindow} AND ssl.status = 'draft')::int                                                  AS drafts_win,
         COUNT(*) FILTER (WHERE ${inWindow} AND ssl.status IN ('sent','completed'))::int                                    AS sent_win,
         COUNT(*) FILTER (WHERE ${inWindow} AND ssl.status IN ('sent','completed') AND ssl.channel = 'email')::int          AS sent_win_email,
         COUNT(*) FILTER (WHERE ${inWindow} AND ssl.status IN ('sent','completed') AND ssl.channel = 'linkedin')::int       AS sent_win_linkedin,
         COUNT(*) FILTER (WHERE ${inWindow} AND ssl.status = 'failed')::int                                                 AS failed_win,
         MAX(ssl.fired_at) AS last_fired_at
       FROM sequences s
       JOIN sequence_enrollments se ON se.sequence_id = s.id
       JOIN prospects p             ON p.id = se.prospect_id
       LEFT JOIN sequence_step_logs ssl ON ssl.enrollment_id = se.id
      WHERE s.org_id      = $1
        AND p.campaign_id = $2
        ${stateRepClause}
      GROUP BY s.id, s.name
      ORDER BY s.id ASC`,
      aggParams
    );

    // ── Per-sequence replies (Bug 1) ─────────────────────────────────
    // One scan of reply_events, bucketed into 24h / 7d / window. When the
    // caller sent no ?depth and no ?userIds we pass userParam=null so the
    // reply counts stay unscoped, matching the unfiltered state queries above.
    const replyParams = [req.orgId];
    let replyUserParam = null;
    if (stateRepParam) {
      replyParams.push(stateRepParam);
      replyUserParam = `$${replyParams.length}`;
    }
    replyParams.push([campaignId]);   const replyCampaignParam = `$${replyParams.length}`;
    replyParams.push(cteStartISO);    const replyStartParam    = `$${replyParams.length}`;
    replyParams.push(cteEndISO);      const replyEndParam      = `$${replyParams.length}`;
    replyParams.push(w.startISO);     const replyWinStart      = `$${replyParams.length}`;
    replyParams.push(w.endISO);       const replyWinEnd        = `$${replyParams.length}`;

    // replied_at is naive UTC wall time (see ReplyEventsQuery header), so it is
    // lifted to timestamptz before any comparison against NOW().
    const rIn24h = `(replied_at AT TIME ZONE 'UTC') >= NOW() - ${day}`;
    const rIn7d  = `(replied_at AT TIME ZONE 'UTC') >= NOW() - ${week}`;
    const rInWin = `replied_at >= (${replyWinStart}::timestamptz AT TIME ZONE 'UTC')
                AND replied_at <= (${replyWinEnd}::timestamptz   AT TIME ZONE 'UTC')`;

    const replyRes = await pool.query(
      `WITH ${replyEventsCte({
         orgParam:      '$1',
         userParam:     replyUserParam,
         startParam:    replyStartParam,
         endParam:      replyEndParam,
         campaignParam: replyCampaignParam,
       })}
       SELECT
         sequence_id,
         COUNT(*) FILTER (WHERE ${rIn24h})::int                                        AS replied_24h,
         COUNT(*) FILTER (WHERE ${rIn7d})::int                                         AS replied_7d,
         COUNT(*) FILTER (WHERE ${rInWin})::int                                        AS replied_win,
         COUNT(*) FILTER (WHERE (${rInWin}) AND channel = 'email')::int                AS replied_win_email,
         COUNT(*) FILTER (WHERE (${rInWin}) AND channel = 'linkedin')::int             AS replied_win_linkedin
       FROM reply_events
       WHERE sequence_id IS NOT NULL
       GROUP BY sequence_id`,
      replyParams
    );
    const repliesBySeq = new Map(replyRes.rows.map(r => [r.sequence_id, r]));

    // ── Per-sequence delivery failures ───────────────────────────────
    // Bounded on the SEND's fired_at (same window as sent_win above), so
    // bounce_events is a strict subset of the sends we just counted and
    // delivered = sent - bounced is never negative. See BounceEventsQuery.
    const bounceParams = [req.orgId];
    let bounceUserParam = null;
    if (stateRepParam) {
      bounceParams.push(stateRepParam);
      bounceUserParam = `$${bounceParams.length}`;
    }
    bounceParams.push([campaignId]);  const bounceCampaignParam = `$${bounceParams.length}`;
    bounceParams.push(w.startISO);    const bounceStartParam    = `$${bounceParams.length}`;
    bounceParams.push(w.endISO);      const bounceEndParam      = `$${bounceParams.length}`;

    const bounceRes = await pool.query(
      `WITH ${bounceEventsCte({
         orgParam:      '$1',
         userParam:     bounceUserParam,
         startParam:    bounceStartParam,
         endParam:      bounceEndParam,
         campaignParam: bounceCampaignParam,
       })}
       SELECT sequence_id, ${BOUNCE_COUNTERS}
       FROM bounce_events
       WHERE sequence_id IS NOT NULL
       GROUP BY sequence_id`,
      bounceParams
    );
    const bouncesBySeq = new Map(bounceRes.rows.map(r => [r.sequence_id, r]));

    // Top errors per sequence within this campaign.
    const errRes = await pool.query(
      `SELECT se.sequence_id,
              ssl.error_message,
              COUNT(*)::int AS count
         FROM sequence_step_logs ssl
         JOIN sequence_enrollments se ON se.id = ssl.enrollment_id
         JOIN prospects p             ON p.id = se.prospect_id
        WHERE ssl.org_id    = $1
          AND p.campaign_id = $2
          AND ssl.status    = 'failed'
          AND ssl.fired_at >= NOW() - ${week}
          AND ssl.error_message IS NOT NULL
          ${stateRepClause}
     GROUP BY se.sequence_id, ssl.error_message
     ORDER BY se.sequence_id, count DESC`,
      base
    );
    const errorsBySeq = {};
    for (const row of errRes.rows) {
      if (!errorsBySeq[row.sequence_id]) errorsBySeq[row.sequence_id] = [];
      if (errorsBySeq[row.sequence_id].length < 3) {
        errorsBySeq[row.sequence_id].push({ message: row.error_message, count: row.count });
      }
    }

    // Stalled enrollments per sequence within this campaign.
    // Anchored on the window's END minus 7 days, matching reporting.routes.js
    // team-overview. Was NOW() - 7 days, which drifted on Custom ranges.
    const stalledParams = [...base, w.endISO];
    const stalledEnd = `$${stalledParams.length}`;
    const stalledRes = await pool.query(
      `SELECT se.sequence_id,
              COUNT(*)::int AS stalled
         FROM sequence_enrollments se
         JOIN prospects p ON p.id = se.prospect_id
         LEFT JOIN LATERAL (
           SELECT MAX(fired_at) AS last_fired
             FROM sequence_step_logs
            WHERE enrollment_id = se.id
         ) ssl ON true
        WHERE se.org_id     = $1
          AND p.campaign_id = $2
          AND se.status     = 'active'
          AND COALESCE(ssl.last_fired, se.enrolled_at) < ${stalledEnd}::timestamptz - ${week}
          ${stateRepClause}
     GROUP BY se.sequence_id`,
      stalledParams
    );
    const stalledBySeq = {};
    for (const row of stalledRes.rows) stalledBySeq[row.sequence_id] = row.stalled;

    const health = aggRes.rows.map(r => {
      const rep = repliesBySeq.get(r.sequence_id) || {};
      const bnc = bouncesBySeq.get(r.sequence_id) || {};
      const repliedWinEmail = rep.replied_win_email || 0;
      const repliedWinLi    = rep.replied_win_linkedin || 0;
      const bounced         = bnc.bounced || 0;
      const deliveredEmail  = _healthDelivered(r.sent_win_email, bounced);
      return {
        sequenceId:   r.sequence_id,
        sequenceName: r.sequence_name,
        // Hardcoded trailing buckets. Shape frozen — CampaignsView.js reads
        // these directly and calls this endpoint with no query params.
        last24h: {
          drafts:  r.drafts_24h,
          sent:    r.sent_24h,
          replied: rep.replied_24h || 0,
          failed:  r.failed_24h,
        },
        last7d: {
          drafts:  r.drafts_7d,
          sent:    r.sent_7d,
          replied: rep.replied_7d || 0,
          failed:  r.failed_7d,
        },
        // The block the drill-down panel actually renders. Bounded by the
        // caller's ?windowDays / ?startDate+?endDate.
        window: {
          drafts:              r.drafts_win,
          sent:                r.sent_win,
          sentEmail:           r.sent_win_email,
          sentLinkedin:        r.sent_win_linkedin,
          replied:             rep.replied_win || 0,
          repliedEmail:        repliedWinEmail,
          repliedLinkedin:     repliedWinLi,
          failed:              r.failed_win,
          bouncedHard:         bnc.bounced_hard  || 0,
          bouncedBlock:        bnc.bounced_block || 0,
          bouncedSoft:         bnc.bounced_soft  || 0,
          bounced,
          deliveredEmail,
          deliveredRate:       _healthDeliveredRate(r.sent_win_email, bounced),
          repliedRate:         _healthRepliedRate(rep.replied_win || 0, r.sent_win),
          // Email replies over DELIVERED email, matching reporting.routes.js.
          emailRepliedRate:    _healthRepliedRate(repliedWinEmail, deliveredEmail),
          linkedinRepliedRate: _healthRepliedRate(repliedWinLi, r.sent_win_linkedin),
        },
        lastFiredAt:        r.last_fired_at,
        topErrors:          errorsBySeq[r.sequence_id] || [],
        stalledEnrollments: stalledBySeq[r.sequence_id] || 0,
      };
    });

    const response = {
      campaignId,
      health,
      // Same guard the tabs use: with no delivery events, `bounced` is 0 and
      // `deliveredRate` is a meaningless 100%. Let the UI say "—" instead.
      deliveryTelemetry: await _healthDeliveryTelemetry(pool, req.orgId),
      // Echoed on every call now (not just groupBy=user|both) so the UI can
      // label the `window` block without guessing.
      period: {
        startDate:   w.startISO,
        endDate:     w.endISO,
        description: w.isoIntervalDescription,
      },
    };

    // ── Phase 3: byUser block (window-bound) ─────────────────────────
    if (groupBy === 'user' || groupBy === 'both') {
      // $1 orgId · $2 campaignId · $3 scope.userIds · $4 winStart · $5 winEnd
      // $6 campaignId[] · $7 cteStart · $8 cteEnd   (last three: reply_events)
      const buParams = [
        req.orgId, req.params.id, scope.userIds, w.startISO, w.endISO,
        [campaignId], cteStartISO, cteEndISO,
      ];

      const buIn24h = `(replied_at AT TIME ZONE 'UTC') >= NOW() - ${day}`;
      const buIn7d  = `(replied_at AT TIME ZONE 'UTC') >= NOW() - ${week}`;
      const buInWin = `replied_at >= ($4::timestamptz AT TIME ZONE 'UTC')
                   AND replied_at <= ($5::timestamptz AT TIME ZONE 'UTC')`;

      const buRes = await pool.query(
        `WITH log_agg AS (
           SELECT
             se.enrolled_by AS user_id,
             COUNT(*) FILTER (WHERE ssl.status = 'draft')::int                              AS drafts,
             COUNT(*) FILTER (WHERE ssl.status IN ('sent','completed'))::int                AS sent,
             COUNT(*) FILTER (WHERE ssl.status IN ('sent','completed')
                                    AND ssl.channel = 'email')::int                         AS sent_email,
             COUNT(*) FILTER (WHERE ssl.status IN ('sent','completed')
                                    AND ssl.channel = 'linkedin')::int                      AS sent_linkedin,
             COUNT(*) FILTER (WHERE ssl.status = 'failed')::int                             AS failed,
             COUNT(*) FILTER (WHERE ssl.status = 'draft'    AND ssl.fired_at >= NOW() - INTERVAL '24 hours')::int               AS drafts_24h,
             COUNT(*) FILTER (WHERE ssl.status IN ('sent','completed') AND ssl.fired_at >= NOW() - INTERVAL '24 hours')::int    AS sent_24h,
             COUNT(*) FILTER (WHERE ssl.status = 'failed'   AND ssl.fired_at >= NOW() - INTERVAL '24 hours')::int               AS failed_24h,
             COUNT(*) FILTER (WHERE ssl.status = 'draft'    AND ssl.fired_at >= NOW() - INTERVAL '7 days')::int                 AS drafts_7d,
             COUNT(*) FILTER (WHERE ssl.status IN ('sent','completed') AND ssl.fired_at >= NOW() - INTERVAL '7 days')::int      AS sent_7d,
             COUNT(*) FILTER (WHERE ssl.status = 'failed'   AND ssl.fired_at >= NOW() - INTERVAL '7 days')::int                 AS failed_7d,
             MAX(ssl.fired_at) AS last_fired_at
           FROM sequence_step_logs ssl
           JOIN sequence_enrollments se ON se.id = ssl.enrollment_id
           JOIN prospects p             ON p.id = se.prospect_id
           WHERE ssl.org_id     = $1
             AND p.campaign_id  = $2
             AND se.enrolled_by = ANY($3::int[])
             AND ssl.fired_at  >= $4::timestamptz
             AND ssl.fired_at  <= $5::timestamptz
           GROUP BY se.enrolled_by
         ),
         ${replyEventsCte({
           orgParam:      '$1',
           userParam:     '$3',
           startParam:    '$7',
           endParam:      '$8',
           campaignParam: '$6',
         })},
         ${bounceEventsCte({
           orgParam:      '$1',
           userParam:     '$3',
           startParam:    '$4',
           endParam:      '$5',
           campaignParam: '$6',
         })},
         bounce_agg AS (
           -- Rep-grain delivery failures. Window is on the SEND's fired_at, the
           -- same bound log_agg uses, so bounced <= sent_email per rep.
           SELECT user_id, ${BOUNCE_COUNTERS}
           FROM bounce_events
           GROUP BY user_id
         ),
         reply_agg AS (
           -- Rep-grain replies. Exactly one row per inbound event (DISTINCT ON
           -- upstream), so these are counts, not a cross-join.
           SELECT
             user_id,
             COUNT(*) FILTER (WHERE ${buInWin})::int                             AS replied,
             COUNT(*) FILTER (WHERE (${buInWin}) AND channel = 'email')::int     AS replied_email,
             COUNT(*) FILTER (WHERE (${buInWin}) AND channel = 'linkedin')::int  AS replied_linkedin,
             COUNT(*) FILTER (WHERE ${buIn24h})::int                             AS replied_24h,
             COUNT(*) FILTER (WHERE ${buIn7d})::int                              AS replied_7d
           FROM reply_events
           GROUP BY user_id
         ),
         enroll_agg AS (
           SELECT
             se.enrolled_by AS user_id,
             COUNT(*)::int AS enrolled,
             COUNT(*) FILTER (WHERE se.status = 'active')::int AS active_enrollments
           FROM sequence_enrollments se
           JOIN prospects p ON p.id = se.prospect_id
           WHERE se.org_id     = $1
             AND p.campaign_id = $2
             AND se.enrolled_by = ANY($3::int[])
             AND se.enrolled_at >= $4::timestamptz
             AND se.enrolled_at <= $5::timestamptz
           GROUP BY se.enrolled_by
         ),
         stalled_agg AS (
           SELECT
             se.enrolled_by AS user_id,
             COUNT(*)::int AS stalled
           FROM sequence_enrollments se
           JOIN prospects p ON p.id = se.prospect_id
           LEFT JOIN LATERAL (
             SELECT MAX(fired_at) AS last_fired FROM sequence_step_logs
              WHERE enrollment_id = se.id
           ) sx ON true
           WHERE se.org_id     = $1
             AND p.campaign_id = $2
             AND se.enrolled_by = ANY($3::int[])
             AND se.status     = 'active'
             AND COALESCE(sx.last_fired, se.enrolled_at) < $5::timestamptz - INTERVAL '7 days'
           GROUP BY se.enrolled_by
         )
         SELECT
           u.id AS user_id, u.first_name, u.last_name, u.email,
           COALESCE(l.drafts, 0)    AS drafts,
           COALESCE(l.sent, 0)      AS sent,
           COALESCE(l.sent_email, 0)        AS sent_email,
           COALESCE(l.sent_linkedin, 0)     AS sent_linkedin,
           COALESCE(rp.replied, 0)          AS replied,
           COALESCE(rp.replied_email, 0)    AS replied_email,
           COALESCE(rp.replied_linkedin, 0) AS replied_linkedin,
           COALESCE(bo.bounced_hard, 0)     AS bounced_hard,
           COALESCE(bo.bounced_block, 0)    AS bounced_block,
           COALESCE(bo.bounced_soft, 0)     AS bounced_soft,
           COALESCE(bo.bounced, 0)          AS bounced,
           COALESCE(l.failed, 0)    AS failed,
           COALESCE(l.drafts_24h,  0) AS drafts_24h,
           COALESCE(l.sent_24h,    0) AS sent_24h,
           COALESCE(rp.replied_24h, 0) AS replied_24h,
           COALESCE(l.failed_24h,  0) AS failed_24h,
           COALESCE(l.drafts_7d,   0) AS drafts_7d,
           COALESCE(l.sent_7d,     0) AS sent_7d,
           COALESCE(rp.replied_7d, 0) AS replied_7d,
           COALESCE(l.failed_7d,   0) AS failed_7d,
           l.last_fired_at,
           COALESCE(e.enrolled, 0)            AS enrolled,
           COALESCE(e.active_enrollments, 0)  AS active_enrollments,
           COALESCE(st.stalled, 0)            AS stalled
         FROM users u
         LEFT JOIN log_agg     l  ON l.user_id  = u.id
         LEFT JOIN reply_agg   rp ON rp.user_id = u.id
         LEFT JOIN bounce_agg  bo ON bo.user_id = u.id
         LEFT JOIN enroll_agg  e  ON e.user_id  = u.id
         LEFT JOIN stalled_agg st ON st.user_id = u.id
         WHERE u.id = ANY($3::int[])
         ORDER BY l.last_fired_at DESC NULLS LAST, u.first_name ASC`,
        buParams
      );

      const reportByUserId = new Map(scope.reports.map(r => [r.userId, r]));
      response.byUser = buRes.rows.map(r => {
        const name = [r.first_name, r.last_name].filter(Boolean).join(' ').trim() || r.email;
        const meta = reportByUserId.get(r.user_id);
        const isViewer = r.user_id === req.user.userId;
        const deliveredEmail = _healthDelivered(r.sent_email, r.bounced);
        return {
          userId:           r.user_id,
          name,
          email:            r.email,
          isDirect:         isViewer ? false : (meta?.isDirect ?? null),
          depthFromManager: isViewer ? 0     : (meta?.depthFromManager ?? null),
          enrolled:         r.enrolled,
          drafts:           r.drafts,
          sent:             r.sent,
          replied:          r.replied,
          failed:           r.failed,
          stalled:          r.stalled,
          sentEmail:            r.sent_email,
          sentLinkedin:         r.sent_linkedin,
          repliedEmail:         r.replied_email,
          repliedLinkedin:      r.replied_linkedin,
          bouncedHard:          r.bounced_hard,
          bouncedBlock:         r.bounced_block,
          bouncedSoft:          r.bounced_soft,
          bounced:              r.bounced,
          deliveredEmail,
          deliveredRate:        _healthDeliveredRate(r.sent_email, r.bounced),
          repliedRate:          _healthRepliedRate(r.replied, r.sent),
          emailRepliedRate:     _healthRepliedRate(r.replied_email, deliveredEmail),
          linkedinRepliedRate:  _healthRepliedRate(r.replied_linkedin, r.sent_linkedin),
          drafts_24h:       r.drafts_24h,
          sent_24h:         r.sent_24h,
          replied_24h:      r.replied_24h,
          failed_24h:       r.failed_24h,
          drafts_7d:        r.drafts_7d,
          sent_7d:          r.sent_7d,
          replied_7d:       r.replied_7d,
          failed_7d:        r.failed_7d,
          lastFiredAt:      r.last_fired_at,
          activeEnrollments: r.active_enrollments,
        };
      });
      response.scope = scope;
    }

    res.json(response);
  } catch (err) {
    console.error('campaign sequence-health error:', err);
    res.status(500).json({ error: { message: 'Failed to load sequence health: ' + err.message } });
  }
});

// Phase 3 window-parsing helper for /:id/sequence-health (mirrors the one
// in sequences.routes.js and reporting.routes.js).
function _parseCampaignHealthWindow(query) {
  const { startDate, endDate, windowDays } = query;
  if (startDate && endDate) {
    const s = new Date(startDate);
    const e = new Date(endDate);
    if (Number.isNaN(s.getTime()) || Number.isNaN(e.getTime())) {
      throw new Error('startDate and endDate must be valid ISO date strings');
    }
    return {
      startISO: s.toISOString(),
      endISO:   e.toISOString(),
      isoIntervalDescription: `${s.toISOString().slice(0, 10)} to ${e.toISOString().slice(0, 10)}`,
    };
  }
  const days = windowDays !== undefined
    ? Math.max(1, Math.min(365, parseInt(windowDays, 10) || 7))
    : 7;
  const end = new Date();
  const start = new Date(end.getTime() - days * 24 * 60 * 60 * 1000);
  return {
    startISO: start.toISOString(),
    endISO:   end.toISOString(),
    isoIntervalDescription: `last ${days} day${days === 1 ? '' : 's'}`,
  };
}


// ─────────────────────────────────────────────────────────────────────────────
// CAMPAIGN-LEVEL PROSPECTING_CONFIG OVERRIDE (Slice 1)
// ─────────────────────────────────────────────────────────────────────────────
// A campaign can override the org's prospecting_config for specific fields
// (value_props, target_personas, etc.). The override is stored as a JSONB
// blob on prospecting_campaigns.prospecting_config_override.
//
// Resolution semantics (enforced in services/SkillContextService.js
// buildOrgContext):
//   - Non-empty arrays on the campaign REPLACE the org array
//   - Empty arrays mean "inherit from org" — to explicitly clear a field
//     campaign-wide, DELETE the entire override (column → NULL)
//   - Guardrails (banned_phrasings / required_disclaimers) UNION across layers
//
// Endpoints:
//   GET    /:id/config   → { override, resolved, org_baseline }
//   PUT    /:id/config   → write/replace the override JSONB
//   DELETE /:id/config   → clear the override (column → NULL)
//
// Owner/admin only — matches the gating on routes/prospecting-config.routes.js
// (org-level config). Campaign-level config is a config-write privilege.
// ─────────────────────────────────────────────────────────────────────────────

// ─────────────────────────────────────────────────────────────────────────────
// Campaign config access guard.
//
// Original rule: only owner/admin can read/write a campaign's prospecting_config_override.
// That's too restrictive — campaigns are owned by individual reps, and the rep
// running a campaign needs to author its pain narrative, value props, and hook
// preferences without bothering an admin.
//
// Updated rules after owner-scoping (2026_13_campaign_owner_scoping):
//   • configReadGuard  → admins, the campaign owner, AND managers of the
//                        owner (manager rollup via subordinateIds).
//   • configWriteGuard → admins and the campaign owner ONLY. Managers can
//                        read but not mutate, matching the rest of the
//                        campaigns CRUD surface.
//
// created_by is no longer consulted: after the migration owner_id is NOT
// NULL and is the source of truth. Removing the created_by fallback prevents
// the case where a campaign's owner has been reassigned but the original
// creator still retains write access via the old fallback.
//
// Both guards set req.userRole, req.campaignOwnerId, req.isCampaignOwner for
// downstream use, preserving the existing shape so callers that read those
// flags (e.g. for UI semantics) keep working.
function buildCampaignGuard({ allowManagerRead }) {
  return async (req, res, next) => {
    try {
      // 1) Org role check — fastest, gates the whole thing if user is admin/owner.
      const role = await CampaignAccess.loadUserRole(req);
      if (!role) {
        return res.status(403).json({ error: { message: 'Access denied — not a member of this org' } });
      }
      req.userRole = role;

      // 2) Admin/owner role: grant immediately, skip the campaign lookup.
      if (CampaignAccess.ADMIN_ROLES.has(role)) {
        req.isCampaignOwner = true;   // for UI semantics, even though it's role-based
        return next();
      }

      // 3) Otherwise look up the campaign and check owner_id (+ manager rollup
      //    for read guards). owner_id is NOT NULL after 2026_13 migration.
      const cRes = await pool.query(
        `SELECT id, owner_id
           FROM prospecting_campaigns
          WHERE id = $1 AND org_id = $2`,
        [req.params.id, req.orgId]
      );
      if (cRes.rows.length === 0) {
        return res.status(404).json({ error: { message: 'Campaign not found' } });
      }
      const camp = cRes.rows[0];
      req.campaignOwnerId = camp.owner_id;

      if (camp.owner_id === req.userId) {
        req.isCampaignOwner = true;
        return next();
      }

      // Manager-read path (only the read guard takes this branch).
      if (allowManagerRead) {
        const subs = req.subordinateIds || [];
        if (subs.includes(camp.owner_id)) {
          req.isCampaignOwner = false;
          return next();
        }
      }

      // 4) Neither role nor ownership match — refuse.
      return res.status(403).json({ error: {
        message: allowManagerRead
          ? "You don't have permission to view this campaign's config."
          : "You don't have permission to modify this campaign's config. Only the owner or an admin can change it.",
      } });
    } catch (err) {
      console.error('campaign config guard error:', err);
      return res.status(500).json({ error: { message: 'Permission check failed' } });
    }
  };
}

// Two flavours:
//   configReadGuard  — admin OR owner OR manager-of-owner (read-only access)
//   configWriteGuard — admin OR owner only (mutation)
// buildCampaignGuard is synchronous — it just returns a middleware function;
// the work happens inside the returned function, per-request.
const configReadGuard  = buildCampaignGuard({ allowManagerRead: true });
const configWriteGuard = buildCampaignGuard({ allowManagerRead: false });

// ── GET /:id/config — current override + resolved view + org baseline ────────
// Read-gated: admins, the owner, and managers-of-the-owner can view. Use
// configReadGuard (not configWriteGuard) so a manager browsing a subordinate's
// campaign can see how it's configured without being able to mutate it.
router.get('/:id/config', configReadGuard, async (req, res) => {
  try {
    const campRes = await pool.query(
      `SELECT id, prospecting_config_override
         FROM prospecting_campaigns
        WHERE id = $1 AND org_id = $2`,
      [req.params.id, req.orgId]
    );
    if (!campRes.rows.length) {
      return res.status(404).json({ error: { message: 'Campaign not found' } });
    }
    const rawOverride = campRes.rows[0].prospecting_config_override;
    // sanitizeCampaignConfig always returns the full shape (empty arrays where
    // unset) — handy for the UI which can render an editor without null guards.
    const override = sanitizeCampaignConfig(rawOverride);

    // Org baseline — same shape, returned so the UI can show "Inherits: ..." next
    // to each field.
    const orgRes = await pool.query(
      `SELECT settings FROM organizations WHERE id = $1`,
      [req.orgId]
    );
    const orgBaseline = sanitizeOrgConfig(orgRes.rows[0]?.settings?.prospecting_config);

    // Resolved view — what the skill will actually see. Mirrors buildOrgContext
    // semantics without invoking it (no user layer here — that's per-rep).
    const resolveReplace = (orgArr, campArr) =>
      (Array.isArray(campArr) && campArr.length > 0) ? campArr : (orgArr || []);

    const resolved = {
      products:                     resolveReplace(orgBaseline.products,                     override.products),
      default_value_props:          resolveReplace(orgBaseline.default_value_props,          override.default_value_props),
      default_target_personas:      resolveReplace(orgBaseline.default_target_personas,      override.default_target_personas),
      default_case_study_summaries: resolveReplace(orgBaseline.default_case_study_summaries, override.default_case_study_summaries),
      hook_preferences: {
        preferred_categories: resolveReplace(
          orgBaseline.hook_preferences?.preferred_categories,
          override.hook_preferences?.preferred_categories
        ),
      },
      guardrails: {
        banned_phrasings: [...new Set([
          ...(orgBaseline.guardrails?.banned_phrasings     || []),
          ...(override.guardrails?.banned_phrasings        || []),
        ])],
        required_disclaimers: [...new Set([
          ...(orgBaseline.guardrails?.required_disclaimers || []),
          ...(override.guardrails?.required_disclaimers    || []),
        ])],
      },
    };

    res.json({
      override,
      resolved,
      org_baseline: orgBaseline,
      has_override: rawOverride !== null && rawOverride !== undefined,
      // Slice-5-fix: tell the client whether the requesting user is allowed
      // to edit. The guard already ran; this just surfaces its result so the
      // UI doesn't need to re-derive role/ownership logic client-side.
      can_edit: true,                    // if we got this far, guard passed
      access_via: req.userRole === 'owner' || req.userRole === 'admin'
        ? 'org_role'
        : 'campaign_ownership',
    });
  } catch (err) {
    console.error('campaign GET /:id/config:', err);
    res.status(500).json({ error: { message: 'Failed to load campaign config' } });
  }
});

// ── PUT /:id/config — write/replace the override JSONB ───────────────────────
// Body: { override: { ...sanitizeCampaignConfig-shape... } }
router.put('/:id/config', configWriteGuard, async (req, res) => {
  try {
    if (!req.body || typeof req.body.override !== 'object' || req.body.override === null) {
      return res.status(400).json({ error: { message: 'override object is required' } });
    }
    const clean = sanitizeCampaignConfig(req.body.override);

    const r = await pool.query(
      `UPDATE prospecting_campaigns
          SET prospecting_config_override = $3::jsonb,
              updated_at = now()
        WHERE id = $1 AND org_id = $2
      RETURNING id, prospecting_config_override`,
      [req.params.id, req.orgId, JSON.stringify(clean)]
    );
    if (!r.rows.length) {
      return res.status(404).json({ error: { message: 'Campaign not found' } });
    }

    res.json({
      override: sanitizeCampaignConfig(r.rows[0].prospecting_config_override),
      has_override: true,
    });
  } catch (err) {
    console.error('campaign PUT /:id/config:', err);
    res.status(500).json({ error: { message: 'Failed to save campaign config' } });
  }
});

// ── DELETE /:id/config — clear the override (column → NULL) ──────────────────
// After this the campaign inherits org config entirely.
router.delete('/:id/config', configWriteGuard, async (req, res) => {
  try {
    const r = await pool.query(
      `UPDATE prospecting_campaigns
          SET prospecting_config_override = NULL,
              updated_at = now()
        WHERE id = $1 AND org_id = $2
      RETURNING id`,
      [req.params.id, req.orgId]
    );
    if (!r.rows.length) {
      return res.status(404).json({ error: { message: 'Campaign not found' } });
    }
    res.json({ cleared: true, has_override: false });
  } catch (err) {
    console.error('campaign DELETE /:id/config:', err);
    res.status(500).json({ error: { message: 'Failed to clear campaign config' } });
  }
});


// ─────────────────────────────────────────────────────────────────────────────
// SLICE 2 — RESEARCHER WORKFLOW + BATCH ACTIVATION + PACING
// ─────────────────────────────────────────────────────────────────────────────

// ── Helper: load this org's effective LinkedIn activation cap ────────────────
// Org ceiling: org_integrations.config.linkedinDailyActivationCap (default 25).
// User target:  user_preferences.preferences.linkedin_daily_activation_target.
// Effective = min(userTarget || orgCap, orgCap). NULL user target → orgCap.
async function resolveActivationLimits(orgId, userId) {
  const [orgRes, userRes] = await Promise.all([
    pool.query(
      `SELECT config FROM org_integrations
        WHERE org_id = $1 AND integration_type = 'prospecting_email'`,
      [orgId]
    ),
    pool.query(
      `SELECT preferences FROM user_preferences
        WHERE user_id = $1 AND org_id = $2`,
      [userId, orgId]
    ),
  ]);
  const cfg = orgRes.rows[0]?.config || {};
  const orgCap = parseInt(cfg.linkedinDailyActivationCap, 10);
  const effectiveOrgCap = (Number.isFinite(orgCap) && orgCap > 0) ? orgCap : 25;

  const prefs = userRes.rows[0]?.preferences || {};
  const userTargetRaw = prefs.linkedin_daily_activation_target;
  const userTarget = parseInt(userTargetRaw, 10);
  const effectiveTarget = (Number.isFinite(userTarget) && userTarget > 0)
    ? Math.min(userTarget, effectiveOrgCap)
    : effectiveOrgCap;

  return {
    orgCap:    effectiveOrgCap,
    userTarget: Number.isFinite(userTarget) && userTarget > 0 ? userTarget : null,
    effective: effectiveTarget,
    activationSlaDays: parseInt(cfg.activationSlaDays, 10) || 7,
    researchSlaDays:   parseInt(cfg.researchSlaDays, 10)   || 14,
  };
}

// ── GET /:id/research-queue — paginated list of `target` prospects ──────────
// For the Research Queue UI. Returns prospects newest-first by default; the UI
// processes one at a time. Returned shape includes everything the researcher
// needs to write the signal without re-doing the AI's account research.
router.get('/:id/research-queue', async (req, res) => {
  try {
    const limit  = Math.min(parseInt(req.query.limit  || '20', 10), 50);
    const offset = parseInt(req.query.offset || '0', 10);
    const stage  = req.query.stage === 'research' ? 'research' : 'target';

    const campRes = await pool.query(
      `SELECT id, owner_id FROM prospecting_campaigns WHERE id = $1 AND org_id = $2`,
      [req.params.id, req.orgId]
    );
    if (!campRes.rows.length) {
      return res.status(404).json({ error: { message: 'Campaign not found' } });
    }
    if (!(await CampaignAccess.requireCanAccess(req, res, campRes.rows[0]))) return;

    const { rows } = await pool.query(
      `SELECT p.id, p.first_name, p.last_name, p.email, p.linkedin_url,
              p.title, p.company_name, p.company_industry,
              p.stage, p.stage_changed_at, p.research_notes, p.research_meta,
              p.created_at,
              a.research_notes AS account_research,
              a.research_meta  AS account_research_meta,
              -- LinkedIn capture status — joined on slug parsed from
              -- linkedin_url with the same regex linkedin-profiles.routes.js
              -- uses on write. last_captured_at is the most recent of any
              -- per-section capture timestamp on the row, written by the
              -- extension upsert. NULL when no row exists for the prospect's
              -- LinkedIn URL — the Research Queue UI renders the "amber"
              -- capture-missing badge in that case.
              lp.last_captured_at        AS linkedin_captured_at,
              lp.last_activity_captured_at AS linkedin_activity_captured_at
         FROM prospects p
    LEFT JOIN accounts a ON a.id = p.account_id
    LEFT JOIN linkedin_profiles lp
           ON lp.org_id = p.org_id
          AND lp.deleted_at IS NULL
          AND lp.linkedin_slug = LOWER(SUBSTRING(p.linkedin_url FROM '/in/([^/?#]+)'))
        WHERE p.org_id      = $1
          AND p.campaign_id = $2
          AND p.stage       = $3
          AND p.deleted_at IS NULL
     ORDER BY p.created_at ASC
        LIMIT $4 OFFSET $5`,
      [req.orgId, req.params.id, stage, limit, offset]
    );

    // Total for paging.
    const countRes = await pool.query(
      `SELECT COUNT(*)::int AS total
         FROM prospects
        WHERE org_id      = $1
          AND campaign_id = $2
          AND stage       = $3
          AND deleted_at IS NULL`,
      [req.orgId, req.params.id, stage]
    );

    res.json({
      campaignId: parseInt(req.params.id, 10),
      stage,
      total: countRes.rows[0].total,
      limit,
      offset,
      prospects: rows.map(r => ({
        id: r.id,
        firstName:   r.first_name,
        lastName:    r.last_name,
        email:       r.email,
        linkedinUrl: r.linkedin_url,
        title:       r.title,
        companyName: r.company_name,
        companyIndustry: r.company_industry,
        stage:       r.stage,
        stageChangedAt: r.stage_changed_at,
        createdAt:   r.created_at,
        researchNotes: r.research_notes,
        researchMeta:  r.research_meta,
        // Surface the account-level research so the researcher can decide
        // whether they need to type anything at all, or just hit Approve.
        accountResearch:     r.account_research,
        accountResearchMeta: r.account_research_meta,
        // LinkedIn capture status drives the badge in the Research Queue
        // UI. linkedinCapturedAt is NULL when no row exists; in that case
        // the UI shows an amber "Not captured" hint with a "Open LinkedIn"
        // CTA so the researcher can run the Chrome extension on the page.
        linkedinCapturedAt:         r.linkedin_captured_at,
        linkedinActivityCapturedAt: r.linkedin_activity_captured_at,
      })),
    });
  } catch (err) {
    console.error('research-queue error:', err);
    res.status(500).json({ error: { message: 'Failed to load research queue' } });
  }
});

// ── POST /:id/bulk-activate — batch-activate research-stage prospects ───────
// Creates fresh sequence_enrollments in 'active' status using the campaign's
// default_sequence_id. Optionally runs PersonalizationDispatcher per prospect
// before enrolling, walking every step of the sequence and calling the right
// per-channel skill (outreach-email / outreach-linkedin) with the inferred
// step_intent. Replaces Slice 2's inline single-skill mapping.
//
// Body:
//   {
//     count?:        number,                  // pick N oldest first
//     prospectIds?:  number[],                // explicit list (capped at limit)
//     runSkill?:     boolean (default true),  // call skill before enroll
//     skipPersonalisation?: boolean           // alias for runSkill=false
//   }
//
// Caps: min(userTarget, orgCap), default 25. Hard ceiling enforced server-side.
//
// Returns:
//   {
//     activated: number,
//     enrollments: [{prospectId, enrollmentId, skillStatus}],
//     skipped:   [{prospectId, reason}],
//     cap:       { orgCap, userTarget, effective, used }
//   }
router.post('/:id/bulk-activate', async (req, res) => {
  try {
    const { count, prospectIds, runSkill, skipPersonalisation, enrollAll = false } = req.body || {};

    // Validate campaign + ensure it has a default sequence to enroll into.
    // Pull the default sequence's ai_enabled so runSkill can default to it.
    const campRes = await pool.query(
      `SELECT c.id, c.default_sequence_id, c.name, c.owner_id,
              s.ai_enabled AS sequence_ai_enabled
         FROM prospecting_campaigns c
    LEFT JOIN sequences s ON s.id = c.default_sequence_id
        WHERE c.id = $1 AND c.org_id = $2 AND c.status IN ('active', 'paused')`,
      [req.params.id, req.orgId]
    );
    if (!campRes.rows.length) {
      return res.status(404).json({ error: { message: 'Campaign not found or archived' } });
    }
    const campaign = campRes.rows[0];
    if (!(await CampaignAccess.requireCanMutate(req, res, campaign))) return;
    if (!campaign.default_sequence_id) {
      return res.status(400).json({ error: {
        message: 'Campaign has no default sequence — set one before bulk-activating.',
      } });
    }

    // Compute cap. When enrollAll=true the caller wants to enroll the entire
    // eligible queue in one click; the scheduler will spread enrollments
    // across days respecting the daily cap (next_step_due dates). When
    // enrollAll=false (legacy "today's batch only" behavior), we cap the
    // candidate count at limits.effective so only that many enroll.
    const limits = await resolveActivationLimits(req.orgId, req.user.userId);
    // Set a hard safety ceiling even in enrollAll mode — refuse to schedule
    // beyond 10,000 enrollments in a single call (operational sanity).
    const HARD_BATCH_CEILING = 10000;

    // ── Per-channel capacity — keyed on the ACTIVATING user ────────────────
    // The firer sends from the enrolled_by user's sender accounts, and
    // enrolled_by = req.user.userId here, so capacity must be computed for the
    // same user (NOT the campaign owner) to keep the soft gate (scheduler) and
    // hard gate (firer) consistent. Email → live sender headroom; LinkedIn →
    // soft per-day release cap; call/task → uncapped (window-limited only).
    const capInfo = await resolveCampaignCapacity(
      req.orgId, parseInt(req.params.id, 10), req.user.userId, campaign.default_sequence_id
    );
    const firstChannel  = capInfo.firstChannel;
    const channelCap    = capInfo.channelCap;
    const emailCapacity = capInfo.emailCapacity;
    const scheduleSettings = capInfo.settings;
    // Today's room for this channel; default batch size for "today's batch only".
    const todayRoom    = channelCap.todayRemaining;
    const defaultBatch = Number.isFinite(todayRoom) ? Math.max(1, todayRoom) : 25;

    // Determine candidate set.
    let candidates;
    if (Array.isArray(prospectIds) && prospectIds.length > 0) {
      // Explicit list — validate they're all in this campaign, research stage,
      // and not already enrolled in the default sequence.
      const ids = prospectIds.map(x => parseInt(x, 10)).filter(Number.isFinite);
      const r = await pool.query(
        `SELECT p.id
           FROM prospects p
          WHERE p.org_id      = $1
            AND p.campaign_id = $2
            AND p.stage       = 'research'
            AND p.deleted_at IS NULL
            AND p.id = ANY($3::int[])
            AND NOT EXISTS (
              SELECT 1 FROM sequence_enrollments se
               WHERE se.prospect_id = p.id
                 AND se.sequence_id = $4
                 AND se.status IN ('active', 'paused')
            )`,
        [req.orgId, req.params.id, ids, campaign.default_sequence_id]
      );
      candidates = r.rows.map(row => row.id);
    } else {
      // enrollAll → everything eligible (scheduler spreads across days,
      // respecting capacity). Else "today's batch only": count if provided,
      // else today's room for this channel. Capacity no longer hard-limits the
      // candidate count — the scheduler rolls overflow forward and we warn.
      const cap = enrollAll ? HARD_BATCH_CEILING : (parseInt(count, 10) || defaultBatch);
      const requested = enrollAll
        ? HARD_BATCH_CEILING
        : (parseInt(count, 10) || defaultBatch);
      const n = Math.max(1, Math.min(requested, cap));
      const r = await pool.query(
        `SELECT p.id
           FROM prospects p
          WHERE p.org_id      = $1
            AND p.campaign_id = $2
            AND p.stage       = 'research'
            AND p.deleted_at IS NULL
            AND NOT EXISTS (
              SELECT 1 FROM sequence_enrollments se
               WHERE se.prospect_id = p.id
                 AND se.sequence_id = $3
                 AND se.status IN ('active', 'paused')
            )
       ORDER BY p.stage_changed_at ASC NULLS FIRST, p.id ASC
          LIMIT $4`,
        [req.orgId, req.params.id, campaign.default_sequence_id, n]
      );
      candidates = r.rows.map(row => row.id);
    }

    // Secondary clamp: only the operational safety ceiling. Per-channel
    // capacity is handled by the scheduler (rolls overflow forward) + the
    // warning below — it does NOT truncate the candidate set.
    const effectiveCeiling = HARD_BATCH_CEILING;
    if (candidates.length > effectiveCeiling) {
      candidates = candidates.slice(0, effectiveCeiling);
    }

    if (candidates.length === 0) {
      return res.json({
        activated: 0,
        enrollments: [],
        skipped: [],
        cap: { ...limits, used: 0 },
        message: 'No eligible prospects (must be in research stage and not already enrolled).',
      });
    }

    // Load sequence to compute next_step_due.
    // Pull both delay_days and channel from the first step — channel
    // controls within-day scheduling (email = spread across window;
    // linkedin/task/call = released at window start for manual action).
    const seqRes = await pool.query(
      `SELECT s.id, s.name,
              (SELECT delay_days FROM sequence_steps
                 WHERE sequence_id = s.id ORDER BY step_order LIMIT 1) AS first_delay,
              (SELECT delay_hours FROM sequence_steps
                 WHERE sequence_id = s.id ORDER BY step_order LIMIT 1) AS first_delay_hours,
              (SELECT channel     FROM sequence_steps
                 WHERE sequence_id = s.id ORDER BY step_order LIMIT 1) AS first_channel
         FROM sequences s
        WHERE s.id = $1 AND s.org_id = $2 AND s.status = 'active'`,
      [campaign.default_sequence_id, req.orgId]
    );
    if (!seqRes.rows.length) {
      return res.status(400).json({ error: {
        message: 'Default sequence not found or inactive.',
      } });
    }
    const seq = seqRes.rows[0];
    const firstDelay      = parseInt(seq.first_delay, 10) || 0;
    const firstDelayHours = parseInt(seq.first_delay_hours, 10) || 0;
    // firstChannel was resolved earlier (capInfo) — reused below.

    // ── Slice 1: pre-schedule all N enrollments across days ────────────────
    //
    // Compute one next_step_due per candidate, spread across valid days/hours
    // respecting the per-channel daily capacity + send window. Settings +
    // capacity were resolved once above (capInfo).
    //
    // existingByDay counts already-booked, future-due slots so the new batch
    // doesn't double up on days that already have work.
    //   - SHARED mode: OWNER-WIDE + channel-filtered — every active enrollment
    //     for this user whose current step is this channel, across all their
    //     campaigns. Makes the shared pool real (a 2nd campaign sees the 1st's
    //     bookings).
    //   - WEIGHTED mode: scoped to THIS CAMPAIGN only — each campaign has its
    //     own allocated slice, so it should only net against its own bookings.
    // (Uncapped channels skip this — there's no budget to share.)
    const tz = scheduleSettings.sendWindowTimezone;
    const existingByDay = {};
    if (Number.isFinite(channelCap.perDayFull)) {
      // Always OWNER-WIDE. The weighted mode that scoped this per-campaign is
      // gone; every campaign of this rep now draws on the same mailboxes, so
      // the pre-booked slots of one must be visible to the next.
      const weighted = false;
      const existingRes = await pool.query(
        `SELECT se.next_step_due
           FROM sequence_enrollments se
           JOIN sequence_steps ss
             ON ss.sequence_id = se.sequence_id
            AND ss.id             = se.current_step_id
           JOIN prospects p ON p.id = se.prospect_id
          WHERE se.org_id      = $1
            AND se.enrolled_by = $2
            AND se.status      = 'active'
            AND se.next_step_due > NOW()
            AND ss.channel     = $3
            AND ($4::int IS NULL OR p.campaign_id = $4)`,
        [req.orgId, req.user.userId, firstChannel, weighted ? parseInt(req.params.id, 10) : null]
      );
      for (const r of existingRes.rows) {
        const local = SendingSchedule._internal.getLocalCalendarDate(new Date(r.next_step_due), tz);
        existingByDay[local.dayKey] = (existingByDay[local.dayKey] || 0) + 1;
      }
    }
    const scheduledSlots = SendingSchedule.scheduleBatchSlots({
      count: candidates.length,
      settings: scheduleSettings,
      channel: firstChannel,
      dayCap: channelCap,
      existingByDay,
      now: new Date(),
    });
    // Apply the sequence's first_step delay (legacy: "first step fires N days
    // after enrollment") on top of the scheduled slot. Hour-aware (WS3):
    // total offset = days*24 + hours. Zero delay is the common case for
    // prospecting sequences.
    const firstDelayMs = (firstDelay * 24 + firstDelayHours) * 3600000;
    const finalSlots = firstDelayMs > 0
      ? scheduledSlots.map(s => new Date(s.getTime() + firstDelayMs))
      : scheduledSlots;

    // Per-prospect processing — sequential to keep skill rate-limited and to
    // produce clean per-prospect error messages. For 25 prospects with skill
    // calls (~3-6s each per step; multiple steps per sequence) this completes
    // in a couple of minutes; the UI shows a progress count.
    //
    // Slice 3: personalisation is now delegated to PersonalizationDispatcher,
    // which walks all steps and routes each to outreach-email or
    // outreach-linkedin with the inferred step_intent. The dispatcher handles
    // any sequence shape — 3 steps or 8 steps, LinkedIn-first or email-first,
    // with breakups and tasks in any position.
    // Lazy by default (D-lazy): personalisation now happens just-in-time in the
    // SequenceStepFirer, so activation does NOT spend LLM calls. The rep can opt
    // into eager "create drafts now" preview per activation via personalizeNow,
    // which pre-personalises the whole batch up front (those drafts are then
    // frozen — the firer reuses them as-is). Only meaningful when the sequence
    // uses AI; skipPersonalisation remains a hard "force off".
    const wantSkill = req.body.personalizeNow === true
      && campaign.sequence_ai_enabled !== false
      && skipPersonalisation !== true;
    const enrollments = [];
    const skipped     = [];
    let slotIndex     = 0;

    // step_order → step id map for remapping AI drafts (dispatcher keys by
    // step_order) to the stable step-ID keys the firer reads by.
    const cEnrollStepMap = await pool.query(
      `SELECT id, step_order FROM sequence_steps WHERE sequence_id=$1`,
      [campaign.default_sequence_id]
    );
    const cEnrollOrderToId = new Map(cEnrollStepMap.rows.map(r => [r.step_order, r.id]));

    for (const prospectId of candidates) {
      let personalisedSteps = {};
      let skillStatus       = 'not_run';
      let dispatchSummary   = null;

      // A/B (2026_46). Resolved HERE, above the dispatcher, not next to the
      // INSERT below: the dispatcher personalises FROM the step's template, and
      // in a test that must be the ARM's template — but no enrollment row exists
      // yet to read an arm from. This is exactly why ExperimentAssigner is a
      // pure hash of (sequence_id, prospect_id) and never Math.random().
      //
      // v1 scope: routes/sequence-variants.routes.js refuses to create variants
      // on an ai_enabled sequence, so wantSkill is always false when variantKey
      // is non-null and the dispatcher never needs the arm. Lift that guard only
      // together with the PersonalizationDispatcher.loadSequenceSteps patch, or
      // the AI will personalise arm A's copy onto arm B enrollments.
      //
      // No variantKeyOverride here, ever. bulk-activate enrolls hundreds at once;
      // pinning a batch to one arm would quietly destroy the randomisation.
      const { experimentId, variantKey } = await ExperimentAssigner.assignVariant(pool, {
        sequenceId: campaign.default_sequence_id, prospectId,
      });

      // Step 1: dispatch personalisation across all sequence steps (optional).
      if (wantSkill) {
        try {
          const dispatchResult = await PersonalizationDispatcher.personaliseEnrollment({
            orgId:      req.orgId,
            userId:     req.user.userId,
            sequenceId: campaign.default_sequence_id,
            prospectId,
          });
          personalisedSteps = dispatchResult.personalisedSteps || {};
          dispatchSummary   = dispatchResult.summary;

          // Status semantics:
          //   - 'ok':      every personalisable step succeeded
          //   - 'partial': some succeeded, some errored (rep can still enroll;
          //                errored steps fall back to sequence templates)
          //   - 'failed':  zero steps personalised
          if (dispatchSummary.personalised === 0) {
            skillStatus = 'failed';
          } else if (dispatchSummary.errored > 0) {
            skillStatus = 'partial';
          } else {
            skillStatus = 'ok';
          }

          // Log per-step errors at warn level — useful for tuning intents.
          if (dispatchResult.errors && dispatchResult.errors.length > 0) {
            console.warn(
              `bulk-activate: dispatcher errors for prospect ${prospectId}:`,
              dispatchResult.errors.map(e => `step ${e.stepOrder}: ${e.reason}`).join('; ')
            );
          }
        } catch (dispatchErr) {
          // Hard failure (e.g. sequence has no steps) — non-fatal at the
          // batch level. Enrollment still proceeds with empty
          // personalised_steps; the firer will render from sequence templates.
          console.warn(`bulk-activate dispatcher failed for prospect ${prospectId}:`, dispatchErr.message);
          skillStatus = 'error';
        }
      }

      // Step 2: insert enrollment (active, next_step_due = pre-computed
      // slot from the scheduler). The scheduler already accounted for
      // firstDelay above (see finalSlots build).
      try {
        // BOUNDS CHECK: scheduleBatchSlots may return FEWER slots than
        // candidates (it caps the day-walk at ~2 years). Reading past the end
        // yields `undefined`, which node-postgres serializes as NULL — an
        // ACTIVE enrollment with next_step_due = NULL is invisible to the firer
        // (`AND se.next_step_due IS NOT NULL`) and can never fire, forever.
        // Surface it as a skip instead of writing an unexecutable row.
        const nextDue = finalSlots[slotIndex];
        if (!nextDue) {
          skipped.push({ prospectId, reason: 'no_capacity' });
          continue;   // do NOT advance slotIndex — no slot was consumed
        }
        slotIndex++;

        // Remap AI drafts step_order → step id so the firer's id-keyed cache reads them.
        const personalisedById = {};
        for (const [ord, val] of Object.entries(personalisedSteps || {})) {
          const sid = cEnrollOrderToId.get(Number(ord));
          if (sid != null) personalisedById[String(sid)] = val;
        }

        const er = await pool.query(
          `INSERT INTO sequence_enrollments
                       (org_id, sequence_id, prospect_id, enrolled_by,
                        next_step_due, personalised_steps, status, variant_key, experiment_id)
                VALUES ($1, $2, $3, $4, $5, $6::jsonb, 'active', $7, $8)
           ON CONFLICT (sequence_id, prospect_id) DO NOTHING
           RETURNING id`,
          [req.orgId, campaign.default_sequence_id, prospectId,
           req.user.userId, nextDue, JSON.stringify(personalisedById), variantKey, experimentId]
        );

        if (er.rows.length === 0) {
          // Race condition: someone enrolled the prospect between our
          // candidate fetch and this INSERT. Skip silently.
          skipped.push({ prospectId, reason: 'already_enrolled' });
          continue;
        }

        // Stamp the identity cursor (current_step_id + channel) for the first step.
        await EnrollmentStepResolver.stampInitialCursor(pool, er.rows[0].id, campaign.default_sequence_id);

        const enrollmentId = er.rows[0].id;

        // Move stage research → outreach. The firer would do this on first
        // step fire, but advancing now keeps the funnel honest immediately.
        await pool.query(
          `UPDATE prospects
              SET stage = 'outreach',
                  stage_changed_at = CURRENT_TIMESTAMP,
                  updated_at       = CURRENT_TIMESTAMP
            WHERE id = $1 AND org_id = $2 AND stage = 'research'`,
          [prospectId, req.orgId]
        );

        // Activity row — feeds the campaign drawer's activity feed.
        try {
          await pool.query(
            `INSERT INTO prospecting_activities
                         (org_id, prospect_id, user_id, activity_type, description, metadata)
                  VALUES ($1, $2, $3, 'activation_completed', $4, $5::jsonb)`,
            [
              req.orgId, prospectId, req.user.userId,
              `Activated in sequence "${seq.name}"`,
              JSON.stringify({
                campaignId: parseInt(req.params.id, 10),
                sequenceId: campaign.default_sequence_id,
                sequenceName: seq.name,
                enrollmentId,
                skillStatus,
                dispatchSummary,
                bulkActivate: true,
              }),
            ]
          );
        } catch (actErr) {
          console.warn('bulk-activate: activity log failed:', actErr.message);
        }

        enrollments.push({ prospectId, enrollmentId, skillStatus, dispatchSummary });
      } catch (insertErr) {
        console.error(`bulk-activate enroll failed for prospect ${prospectId}:`, insertErr);
        skipped.push({ prospectId, reason: insertErr.message });
      }
    }

    // ── Level 2: materialize 'scheduled' rows for the just-activated, auto-send
    // enrollments so the rep immediately sees the queued emails and their send
    // times. Non-fatal — the cron top-up would create them within a tick anyway.
    // Only email auto-send steps produce rows; draft/manual steps are untouched.
    try {
      const newEnrollmentIds = enrollments.map(e => e.enrollmentId).filter(Boolean);
      if (newEnrollmentIds.length) {
        await require('../services/SequenceStepFirer')
          .materializePendingAutoSends(newEnrollmentIds);
      }
    } catch (matErr) {
      console.warn('bulk-activate: materializePendingAutoSends failed (non-fatal):', matErr.message);
    }

    // ── Capacity warning (Q-D) ─────────────────────────────────────────────
    // Activation always proceeds; if email capacity is exhausted or the batch
    // exceeds today's room, surface a warning naming the real lever (sender
    // daily limit). Slots roll forward to the next available day automatically.
    let warning = null;
    if (firstChannel === 'email' && emailCapacity) {
      if (emailCapacity.activeSenders === 0) {
        warning = {
          code: 'NO_SENDERS',
          message: 'No active email sender accounts. Connect a Gmail or Outlook account in Settings → Outreach before sends can fire.',
        };
      } else if (emailCapacity.todayRemaining <= 0) {
        warning = {
          code: 'NO_CAPACITY_TODAY',
          message: `Your sending accounts have hit today's limit (${emailCapacity.perDayFull}/day across ${emailCapacity.activeSenders} account${emailCapacity.activeSenders === 1 ? '' : 's'}). These prospects are scheduled starting the next available day. To send more today, raise a sender's daily limit or activate another sender.`,
          perDayFull: emailCapacity.perDayFull,
          activeSenders: emailCapacity.activeSenders,
        };
      } else if (enrollments.length > emailCapacity.todayRemaining) {
        warning = {
          code: 'OVER_CAPACITY_TODAY',
          message: `${enrollments.length} prospects enrolled; about ${emailCapacity.todayRemaining} fit today (${emailCapacity.perDayFull}/day). The rest are scheduled across the following days. Raise a sender's daily limit to send more per day.`,
          perDayFull: emailCapacity.perDayFull,
          todayRemaining: emailCapacity.todayRemaining,
        };
      }
    }

    res.json({
      activated: enrollments.length,
      enrollments,
      skipped,
      cap: { ...limits, used: enrollments.length },
      capacity: describeCapacity(firstChannel, channelCap, emailCapacity, scheduleSettings, capInfo.contention),
      warning,
      campaignId: parseInt(req.params.id, 10),
      sequenceName: seq.name,
    });
  } catch (err) {
    console.error('bulk-activate error:', err);
    res.status(500).json({ error: { message: 'Bulk activation failed: ' + err.message } });
  }
});

// ── POST /:id/enroll-one — enroll ONE prospect into this campaign ────────────
//
// Campaign-native, stage-agnostic single enrollment behind the prospect detail
// panel's "Enroll in Campaign" action. Unlike bulk-activate (batch + research-
// stage gated), this:
//   1. sets the prospect's campaign_id (membership) — reassigns if the prospect
//      was in another campaign,
//   2. schedules the FIRST touch using the EXACT capacity + send-window math as
//      GET /schedule-preview, so the time shown before confirming equals the
//      time actually written (no silent drop),
//   3. creates the enrollment in the campaign's default sequence,
//   4. advances a pre-outreach prospect (target/research) to 'outreach' so the
//      funnel reflects active outreach (prospects already past outreach keep
//      their stage),
//   5. returns firstSendAt for the UI's "first touch will go out at …" confirm.
//
// Personalisation is lazy (JIT in the firer), matching bulk-activate's default.
// Body: { prospectId }
router.post('/:id/enroll-one', async (req, res) => {
  try {
    const prospectId = parseInt(req.body?.prospectId, 10);
    if (!Number.isFinite(prospectId)) {
      return res.status(400).json({ error: { message: 'prospectId is required' } });
    }

    // Validate campaign + default sequence + mutate access.
    const campRes = await pool.query(
      `SELECT c.id, c.default_sequence_id, c.name, c.owner_id, s.name AS sequence_name
         FROM prospecting_campaigns c
    LEFT JOIN sequences s ON s.id = c.default_sequence_id
        WHERE c.id = $1 AND c.org_id = $2 AND c.status IN ('active','paused')`,
      [req.params.id, req.orgId]
    );
    if (!campRes.rows.length) {
      return res.status(404).json({ error: { message: 'Campaign not found or archived' } });
    }
    const campaign = campRes.rows[0];
    if (!(await CampaignAccess.requireCanMutate(req, res, campaign))) return;
    if (!campaign.default_sequence_id) {
      // The exact "prospect would be dropped" case — refuse loudly so the caller
      // can tell the user no outreach would be scheduled.
      return res.status(400).json({ error: {
        message: 'This campaign has no default sequence, so no outreach can be scheduled. Set a default sequence on the campaign first.',
        code: 'NO_DEFAULT_SEQUENCE',
      } });
    }

    // Validate the prospect (org-scoped, live).
    const pRes = await pool.query(
      `SELECT id, stage, campaign_id FROM prospects
        WHERE id = $1 AND org_id = $2 AND deleted_at IS NULL`,
      [prospectId, req.orgId]
    );
    if (!pRes.rows.length) {
      return res.status(404).json({ error: { message: 'Prospect not found' } });
    }

    // Already enrolled in this campaign's default sequence? Stop (idempotent).
    const dupe = await pool.query(
      `SELECT id FROM sequence_enrollments
        WHERE sequence_id = $1 AND prospect_id = $2 AND status IN ('active','paused')`,
      [campaign.default_sequence_id, prospectId]
    );
    if (dupe.rows.length) {
      return res.json({
        enrolled: false,
        alreadyEnrolled: true,
        sequenceName: campaign.sequence_name,
        message: 'This prospect is already enrolled in the campaign\u2019s sequence.',
      });
    }

    // ── Compute the first-touch slot — identical basis to schedule-preview ──
    const capInfo    = await resolveCampaignCapacity(
      req.orgId, parseInt(req.params.id, 10), req.user.userId, campaign.default_sequence_id
    );
    const settings   = capInfo.settings;
    const channel    = capInfo.firstChannel;
    const channelCap = capInfo.channelCap;
    const tz = settings.sendWindowTimezone;

    // Owner-wide, channel-filtered future bookings (matches schedule-preview so
    // preview == actual). Only meaningful for capped channels.
    const existingByDay = {};
    if (Number.isFinite(channelCap.perDayFull)) {
      const existingRes = await pool.query(
        `SELECT se.next_step_due
           FROM sequence_enrollments se
           JOIN sequence_steps ss
             ON ss.sequence_id = se.sequence_id AND ss.id = se.current_step_id
           JOIN prospects p ON p.id = se.prospect_id
          WHERE se.org_id = $1 AND se.enrolled_by = $2 AND se.status = 'active'
            AND se.next_step_due > NOW() AND ss.channel = $3`,
        [req.orgId, req.user.userId, channel]
      );
      for (const r of existingRes.rows) {
        const local = SendingSchedule._internal.getLocalCalendarDate(new Date(r.next_step_due), tz);
        existingByDay[local.dayKey] = (existingByDay[local.dayKey] || 0) + 1;
      }
    }

    // First-step delay (days/hours) applied on top of the scheduled slot.
    const stepRes = await pool.query(
      `SELECT delay_days, delay_hours FROM sequence_steps
        WHERE sequence_id = $1 ORDER BY step_order LIMIT 1`,
      [campaign.default_sequence_id]
    );
    const firstDelay      = parseInt(stepRes.rows[0]?.delay_days, 10)  || 0;
    const firstDelayHours = parseInt(stepRes.rows[0]?.delay_hours, 10) || 0;

    const slots = SendingSchedule.scheduleBatchSlots({
      count: 1, settings, channel, dayCap: channelCap, existingByDay, now: new Date(),
    });
    const firstDelayMs = (firstDelay * 24 + firstDelayHours) * 3600000;
    let firstSlot = slots[0];
    if (firstSlot && firstDelayMs > 0) firstSlot = new Date(firstSlot.getTime() + firstDelayMs);
    if (!firstSlot) {
      return res.status(409).json({ error: {
        message: 'No available send slot could be scheduled — check the campaign send window and sender capacity.',
        code: 'NO_SLOT',
      } });
    }

    // ── Membership + enrollment (one transaction) ──────────────────────────
    const client = await pool.connect();
    let enrollmentId = null;
    try {
      await client.query('BEGIN');

      // 1. Set/reassign campaign membership.
      await client.query(
        `UPDATE prospects SET campaign_id = $1, updated_at = CURRENT_TIMESTAMP
          WHERE id = $2 AND org_id = $3`,
        [campaign.id, prospectId, req.orgId]
      );

      // 2. A/B arm (pure hash; null/null when no experiment).
      const { experimentId, variantKey } = await ExperimentAssigner.assignVariant(client, {
        sequenceId: campaign.default_sequence_id, prospectId,
      });

      // 3. Enrollment with the pre-computed slot.
      const er = await client.query(
        `INSERT INTO sequence_enrollments
                     (org_id, sequence_id, prospect_id, enrolled_by,
                      next_step_due, personalised_steps, status, variant_key, experiment_id)
              VALUES ($1, $2, $3, $4, $5, '{}'::jsonb, 'active', $6, $7)
         ON CONFLICT (sequence_id, prospect_id) DO NOTHING
         RETURNING id`,
        [req.orgId, campaign.default_sequence_id, prospectId, req.user.userId,
         firstSlot, variantKey, experimentId]
      );
      if (er.rows.length === 0) {
        // Raced with a concurrent enroll between the dupe check and here.
        await client.query('ROLLBACK');
        return res.json({
          enrolled: false, alreadyEnrolled: true,
          sequenceName: campaign.sequence_name,
          message: 'This prospect is already enrolled in the campaign\u2019s sequence.',
        });
      }
      enrollmentId = er.rows[0].id;

      // Stamp identity cursor (current_step_id + channel) for the first step.
      await EnrollmentStepResolver.stampInitialCursor(client, enrollmentId, campaign.default_sequence_id);

      // 4. Advance pre-outreach prospects to outreach (forward-only).
      await client.query(
        `UPDATE prospects
            SET stage = 'outreach', stage_changed_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
          WHERE id = $1 AND org_id = $2 AND stage IN ('target','research')`,
        [prospectId, req.orgId]
      );

      // 5. Activity feed entry.
      try {
        await client.query(
          `INSERT INTO prospecting_activities
                       (org_id, prospect_id, user_id, activity_type, description, metadata)
                VALUES ($1, $2, $3, 'activation_completed', $4, $5::jsonb)`,
          [req.orgId, prospectId, req.user.userId,
           `Enrolled in campaign "${campaign.name}" (sequence "${campaign.sequence_name}")`,
           JSON.stringify({
             campaignId:   campaign.id,
             sequenceId:   campaign.default_sequence_id,
             sequenceName: campaign.sequence_name,
             enrollmentId,
             firstSendAt:  firstSlot.toISOString(),
             enrollOne:    true,
           })],
        );
      } catch (actErr) {
        console.warn('enroll-one: activity log failed:', actErr.message);
      }

      await client.query('COMMIT');
    } catch (txErr) {
      await client.query('ROLLBACK');
      console.error('enroll-one tx error:', txErr);
      return res.status(500).json({ error: { message: 'Enrollment failed: ' + txErr.message } });
    } finally {
      client.release();
    }

    // Materialize immediate auto-send rows so the rep sees queued emails (non-fatal).
    try {
      await require('../services/SequenceStepFirer').materializePendingAutoSends([enrollmentId]);
    } catch (matErr) {
      console.warn('enroll-one: materializePendingAutoSends failed (non-fatal):', matErr.message);
    }

    res.json({
      enrolled:     true,
      enrollmentId,
      firstSendAt:  firstSlot.toISOString(),
      channel,
      sequenceName: campaign.sequence_name,
      timezone:     tz,
      campaignId:   campaign.id,
    });
  } catch (err) {
    console.error('enroll-one error:', err);
    res.status(500).json({ error: { message: 'Enrollment failed: ' + err.message } });
  }
});

// ── POST /:id/enroll-batch — enroll MANY prospects into this campaign ────────
//
// Bulk sibling of enroll-one, behind the pipeline's "Enroll in campaign" bulk
// action. Stage-agnostic; sets membership AND schedules the first touch for
// every eligible prospect (capacity-aware, spread across days — identical math
// to schedule-preview / bulk-activate). This is the fix for "added to a
// campaign but nothing fires": a bulk add now always produces scheduled
// outreach, never a silent membership tag. Prospects already active/paused in
// the default sequence are skipped and reported.
//
// Body: { prospectIds: number[] }
// Returns: { enrolled, skipped[], firstSendAt, lastSendAt, byDay[], channel,
//            timezone, sequenceName, campaignId }
router.post('/:id/enroll-batch', async (req, res) => {
  try {
    const rawIds = Array.isArray(req.body?.prospectIds) ? req.body.prospectIds : [];
    const idList = [...new Set(rawIds.map(x => parseInt(x, 10)).filter(Number.isFinite))];
    if (idList.length === 0) {
      return res.status(400).json({ error: { message: 'prospectIds array is required' } });
    }
    const HARD_CEILING = 500;
    if (idList.length > HARD_CEILING) {
      return res.status(400).json({ error: {
        message: `Too many prospects selected (max ${HARD_CEILING} per bulk enroll).`,
      } });
    }

    // Campaign + default sequence + mutate access.
    const campRes = await pool.query(
      `SELECT c.id, c.default_sequence_id, c.name, c.owner_id, s.name AS sequence_name
         FROM prospecting_campaigns c
    LEFT JOIN sequences s ON s.id = c.default_sequence_id
        WHERE c.id = $1 AND c.org_id = $2 AND c.status IN ('active','paused')`,
      [req.params.id, req.orgId]
    );
    if (!campRes.rows.length) {
      return res.status(404).json({ error: { message: 'Campaign not found or archived' } });
    }
    const campaign = campRes.rows[0];
    if (!(await CampaignAccess.requireCanMutate(req, res, campaign))) return;
    if (!campaign.default_sequence_id) {
      return res.status(400).json({ error: {
        message: 'This campaign has no default sequence, so no outreach can be scheduled. Set a default sequence on the campaign first.',
        code: 'NO_DEFAULT_SEQUENCE',
      } });
    }

    // Candidate set: org-scoped, live, and NOT already active/paused in the
    // default sequence. Everything filtered out is reported as skipped so the
    // caller can show an honest count.
    const candRes = await pool.query(
      `SELECT p.id
         FROM prospects p
        WHERE p.org_id = $1 AND p.deleted_at IS NULL AND p.id = ANY($2::int[])
          AND NOT EXISTS (
            SELECT 1 FROM sequence_enrollments se
             WHERE se.prospect_id = p.id AND se.sequence_id = $3
               AND se.status IN ('active','paused'))`,
      [req.orgId, idList, campaign.default_sequence_id]
    );
    const candidates = candRes.rows.map(r => r.id);
    const candidateSet = new Set(candidates);
    const skipped = idList
      .filter(id => !candidateSet.has(id))
      .map(id => ({ prospectId: id, reason: 'already_enrolled_or_ineligible' }));

    if (candidates.length === 0) {
      return res.json({
        enrolled: 0, skipped,
        sequenceName: campaign.sequence_name, campaignId: campaign.id,
        message: 'No eligible prospects — all selected are already enrolled in this campaign\u2019s sequence.',
      });
    }

    // ── Capacity + schedule (identical basis to schedule-preview) ──────────
    const capInfo    = await resolveCampaignCapacity(
      req.orgId, parseInt(req.params.id, 10), req.user.userId, campaign.default_sequence_id
    );
    const settings   = capInfo.settings;
    const channel    = capInfo.firstChannel;
    const channelCap = capInfo.channelCap;
    const tz = settings.sendWindowTimezone;

    const existingByDay = {};
    if (Number.isFinite(channelCap.perDayFull)) {
      const ex = await pool.query(
        `SELECT se.next_step_due
           FROM sequence_enrollments se
           JOIN sequence_steps ss
             ON ss.sequence_id = se.sequence_id AND ss.id = se.current_step_id
           JOIN prospects p ON p.id = se.prospect_id
          WHERE se.org_id = $1 AND se.enrolled_by = $2 AND se.status = 'active'
            AND se.next_step_due > NOW() AND ss.channel = $3`,
        [req.orgId, req.user.userId, channel]
      );
      for (const r of ex.rows) {
        const local = SendingSchedule._internal.getLocalCalendarDate(new Date(r.next_step_due), tz);
        existingByDay[local.dayKey] = (existingByDay[local.dayKey] || 0) + 1;
      }
    }

    const stepRes = await pool.query(
      `SELECT delay_days, delay_hours FROM sequence_steps
        WHERE sequence_id = $1 ORDER BY step_order LIMIT 1`,
      [campaign.default_sequence_id]
    );
    const firstDelay      = parseInt(stepRes.rows[0]?.delay_days, 10)  || 0;
    const firstDelayHours = parseInt(stepRes.rows[0]?.delay_hours, 10) || 0;

    const slots = SendingSchedule.scheduleBatchSlots({
      count: candidates.length, settings, channel, dayCap: channelCap, existingByDay, now: new Date(),
    });
    const firstDelayMs = (firstDelay * 24 + firstDelayHours) * 3600000;
    const finalSlots = firstDelayMs > 0
      ? slots.map(s => new Date(s.getTime() + firstDelayMs))
      : slots;

    // ── Membership + enrollment (one transaction) ──────────────────────────
    const client = await pool.connect();
    const assignedSlots = [];   // ISO strings actually written
    const enrolledIds   = [];
    try {
      await client.query('BEGIN');

      // Membership for all candidates (reassign from any prior campaign).
      await client.query(
        `UPDATE prospects SET campaign_id = $1, updated_at = CURRENT_TIMESTAMP
          WHERE id = ANY($2::int[]) AND org_id = $3`,
        [campaign.id, candidates, req.orgId]
      );

      let slotIndex = 0;
      for (const prospectId of candidates) {
        // scheduleBatchSlots may return fewer slots than candidates (2-year
        // day-walk cap). A missing slot → skip rather than write a NULL-due,
        // never-firing enrollment. Match bulk-activate: don't advance on miss.
        const nextDue = finalSlots[slotIndex];
        if (!nextDue) { skipped.push({ prospectId, reason: 'no_capacity' }); continue; }
        slotIndex++;

        const { experimentId, variantKey } = await ExperimentAssigner.assignVariant(client, {
          sequenceId: campaign.default_sequence_id, prospectId,
        });

        const er = await client.query(
          `INSERT INTO sequence_enrollments
                       (org_id, sequence_id, prospect_id, enrolled_by,
                        next_step_due, personalised_steps, status, variant_key, experiment_id)
                VALUES ($1, $2, $3, $4, $5, '{}'::jsonb, 'active', $6, $7)
           ON CONFLICT (sequence_id, prospect_id) DO NOTHING
           RETURNING id`,
          [req.orgId, campaign.default_sequence_id, prospectId, req.user.userId,
           nextDue, variantKey, experimentId]
        );
        if (er.rows.length === 0) {
          // Raced between candidate fetch and insert — slot already consumed.
          skipped.push({ prospectId, reason: 'already_enrolled' });
          continue;
        }

        await EnrollmentStepResolver.stampInitialCursor(client, er.rows[0].id, campaign.default_sequence_id);
        enrolledIds.push(prospectId);
        assignedSlots.push(nextDue);

        try {
          await client.query(
            `INSERT INTO prospecting_activities
                         (org_id, prospect_id, user_id, activity_type, description, metadata)
                  VALUES ($1, $2, $3, 'activation_completed', $4, $5::jsonb)`,
            [req.orgId, prospectId, req.user.userId,
             `Enrolled in campaign "${campaign.name}" (sequence "${campaign.sequence_name}")`,
             JSON.stringify({
               campaignId:   campaign.id,
               sequenceId:   campaign.default_sequence_id,
               sequenceName: campaign.sequence_name,
               enrollmentId: er.rows[0].id,
               firstSendAt:  nextDue.toISOString(),
               enrollBatch:  true,
             })],
          );
        } catch (actErr) {
          console.warn('enroll-batch: activity log failed:', actErr.message);
        }
      }

      // Advance pre-outreach prospects to outreach (forward-only, batch).
      if (enrolledIds.length) {
        await client.query(
          `UPDATE prospects
              SET stage = 'outreach', stage_changed_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
            WHERE id = ANY($1::int[]) AND org_id = $2 AND stage IN ('target','research')`,
          [enrolledIds, req.orgId]
        );
      }

      await client.query('COMMIT');
    } catch (txErr) {
      await client.query('ROLLBACK');
      console.error('enroll-batch tx error:', txErr);
      return res.status(500).json({ error: { message: 'Enrollment failed: ' + txErr.message } });
    } finally {
      client.release();
    }

    // Materialize immediate auto-send rows (non-fatal).
    try {
      const newEnrollmentIds = [];
      // (enrollment ids weren't collected above; re-fetch the just-created ones)
      const idRes = await pool.query(
        `SELECT id FROM sequence_enrollments
          WHERE sequence_id = $1 AND prospect_id = ANY($2::int[]) AND status = 'active'`,
        [campaign.default_sequence_id, enrolledIds]
      );
      for (const r of idRes.rows) newEnrollmentIds.push(r.id);
      if (newEnrollmentIds.length) {
        await require('../services/SequenceStepFirer').materializePendingAutoSends(newEnrollmentIds);
      }
    } catch (matErr) {
      console.warn('enroll-batch: materializePendingAutoSends failed (non-fatal):', matErr.message);
    }

    // Per-day summary of the slots we actually assigned (for the result screen).
    const byDayMap = new Map();
    for (const slot of assignedSlots) {
      const key = SendingSchedule._internal.getLocalCalendarDate(slot, tz).dayKey;
      if (!byDayMap.has(key)) byDayMap.set(key, []);
      byDayMap.get(key).push(slot);
    }
    const byDay = [];
    for (const [date, ds] of byDayMap) {
      ds.sort((a, b) => a - b);
      byDay.push({ date, count: ds.length, firstAt: ds[0].toISOString(), lastAt: ds[ds.length - 1].toISOString() });
    }
    byDay.sort((a, b) => a.date.localeCompare(b.date));
    const sortedSlots = [...assignedSlots].sort((a, b) => a - b);

    res.json({
      enrolled:     enrolledIds.length,
      skipped,
      firstSendAt:  sortedSlots[0] ? sortedSlots[0].toISOString() : null,
      lastSendAt:   sortedSlots.length ? sortedSlots[sortedSlots.length - 1].toISOString() : null,
      byDay,
      channel,
      timezone:     tz,
      sequenceName: campaign.sequence_name,
      campaignId:   campaign.id,
    });
  } catch (err) {
    console.error('enroll-batch error:', err);
    res.status(500).json({ error: { message: 'Bulk enrollment failed: ' + err.message } });
  }
});

// ── GET /:id/schedule-preview?count=N — predict slot timestamps ──────────────
//
// Returns the N future timestamps that bulk-activate would assign as
// next_step_due for N new prospects, given current schedule settings and
// already-scheduled enrollments. The BatchActivateModal renders these so
// the user knows what they're about to commit to ("first 25 will go out
// tomorrow 9am–11am ET, then ...").
//
// Response shape:
//   {
//     count, settings,
//     summary: { days: 3, firstAt: ISO, lastAt: ISO },
//     byDay:   [ { date: 'YYYY-MM-DD', count: 25, firstAt: ISO, lastAt: ISO }, ... ]
//   }
//
// Does NOT mutate anything. Pure preview.
router.get('/:id/schedule-preview', async (req, res) => {
  try {
    const count = Math.max(1, Math.min(parseInt(req.query.count, 10) || 25, 10000));

    const campRes = await pool.query(
      `SELECT id, default_sequence_id, owner_id FROM prospecting_campaigns
        WHERE id = $1 AND org_id = $2 AND status IN ('active','paused')`,
      [req.params.id, req.orgId]
    );
    if (!campRes.rows.length) {
      return res.status(404).json({ error: { message: 'Campaign not found' } });
    }
    const campaign = campRes.rows[0];
    if (!(await CampaignAccess.requireCanAccess(req, res, campaign))) return;
    if (!campaign.default_sequence_id) {
      return res.status(400).json({ error: {
        message: 'Campaign has no default sequence — preview unavailable.',
      } });
    }

    // Resolve effective schedule + per-channel capacity for the activating
    // user (req.user.userId) — same basis as bulk-activate so the preview
    // matches what activation will actually do.
    const capInfo = await resolveCampaignCapacity(
      req.orgId, parseInt(req.params.id, 10), req.user.userId, campaign.default_sequence_id
    );
    const settings    = capInfo.settings;
    const channel     = capInfo.firstChannel;
    const channelCap  = capInfo.channelCap;
    const tz = settings.sendWindowTimezone;

    // Already-booked slots: owner-wide in shared mode, per-campaign in weighted
    // mode (matches bulk-activate so the preview equals what activation does).
    const existingByDay = {};
    if (Number.isFinite(channelCap.perDayFull)) {
      // Always OWNER-WIDE — see the matching note in bulk-activate. The preview
      // must equal what activation actually does.
      const weighted = false;
      const existingRes = await pool.query(
        `SELECT se.next_step_due
           FROM sequence_enrollments se
           JOIN sequence_steps ss
             ON ss.sequence_id = se.sequence_id
            AND ss.id             = se.current_step_id
           JOIN prospects p ON p.id = se.prospect_id
          WHERE se.org_id      = $1
            AND se.enrolled_by = $2
            AND se.status      = 'active'
            AND se.next_step_due > NOW()
            AND ss.channel     = $3
            AND ($4::int IS NULL OR p.campaign_id = $4)`,
        [req.orgId, req.user.userId, channel, weighted ? parseInt(req.params.id, 10) : null]
      );
      for (const r of existingRes.rows) {
        const local = SendingSchedule._internal.getLocalCalendarDate(new Date(r.next_step_due), tz);
        existingByDay[local.dayKey] = (existingByDay[local.dayKey] || 0) + 1;
      }
    }

    const slots = SendingSchedule.scheduleBatchSlots({
      count,
      settings,
      channel,
      dayCap: channelCap,
      existingByDay,
      now: new Date(),
    });

    // Group slots by local-tz day for the per-day summary.
    const byDayMap = new Map();
    for (const slot of slots) {
      const key = SendingSchedule._internal.getLocalCalendarDate(slot, tz).dayKey;
      if (!byDayMap.has(key)) byDayMap.set(key, []);
      byDayMap.get(key).push(slot);
    }
    const byDay = [];
    for (const [date, daySlots] of byDayMap) {
      daySlots.sort((a, b) => a.getTime() - b.getTime());
      byDay.push({
        date,
        count: daySlots.length,
        firstAt: daySlots[0].toISOString(),
        lastAt:  daySlots[daySlots.length - 1].toISOString(),
      });
    }
    byDay.sort((a, b) => a.date.localeCompare(b.date));

    res.json({
      count: slots.length,
      requestedCount: count,
      channel,
      settings,
      capacity: describeCapacity(channel, channelCap, capInfo.emailCapacity, settings, capInfo.contention),
      existingScheduled: Object.values(existingByDay).reduce((a, b) => a + b, 0),
      summary: slots.length > 0 ? {
        days:    byDay.length,
        firstAt: slots[0].toISOString(),
        lastAt:  slots[slots.length - 1].toISOString(),
      } : null,
      byDay,
    });
  } catch (err) {
    console.error('schedule-preview error:', err);
    res.status(500).json({ error: { message: 'Failed to preview schedule: ' + err.message } });
  }
});

// ── GET /:id/pacing — funnel counts + 7d activation rate + days-to-clear ────
router.get('/:id/pacing', async (req, res) => {
  try {
    const campRes = await pool.query(
      `SELECT id, name, end_date, default_sequence_id, owner_id
         FROM prospecting_campaigns
        WHERE id = $1 AND org_id = $2`,
      [req.params.id, req.orgId]
    );
    if (!campRes.rows.length) {
      return res.status(404).json({ error: { message: 'Campaign not found' } });
    }
    const campaign = campRes.rows[0];
    if (!(await CampaignAccess.requireCanAccess(req, res, campaign))) return;

    // Stage counts.
    const stageRes = await pool.query(
      `SELECT stage, COUNT(*)::int AS count
         FROM prospects
        WHERE org_id = $1 AND campaign_id = $2 AND deleted_at IS NULL
     GROUP BY stage`,
      [req.orgId, req.params.id]
    );
    const stageCounts = {};
    stageRes.rows.forEach(r => { stageCounts[r.stage] = r.count; });

    // 7d activation rate: count activation_completed activities in last 7 days.
    const actRes = await pool.query(
      `SELECT COUNT(*)::int AS recent_activations
         FROM prospecting_activities pa
         JOIN prospects p ON p.id = pa.prospect_id
        WHERE pa.org_id = $1
          AND p.campaign_id = $2
          AND pa.activity_type = 'activation_completed'
          AND pa.created_at >= NOW() - INTERVAL '7 days'`,
      [req.orgId, req.params.id]
    );
    const recentActivations = actRes.rows[0].recent_activations;
    const activationsPerDay = recentActivations / 7;

    const readyToActivate = stageCounts.research || 0;
    const daysToClear = activationsPerDay > 0
      ? Math.ceil(readyToActivate / activationsPerDay)
      : null;

    // Health: green if pace is sufficient to clear within end_date (or 60d
    // default), amber if it'll take 1.5x the window, red if more.
    let health = 'gray';
    if (readyToActivate === 0) {
      health = 'green';
    } else if (daysToClear === null) {
      health = 'red';   // ready to activate but no recent activity
    } else {
      const windowDays = campaign.end_date
        ? Math.max(1, Math.ceil((new Date(campaign.end_date) - new Date()) / (1000 * 60 * 60 * 24)))
        : 60;
      const ratio = daysToClear / windowDays;
      if (ratio <= 1)      health = 'green';
      else if (ratio <= 1.5) health = 'amber';
      else                  health = 'red';
    }

    res.json({
      campaignId: parseInt(req.params.id, 10),
      stages: {
        target:         stageCounts.target         || 0,
        research:       stageCounts.research       || 0,
        outreach:       stageCounts.outreach       || 0,
        engaged:        stageCounts.engaged        || 0,
        discovery_call: stageCounts.discovery_call || 0,
        qualified_sal:  stageCounts.qualified_sal  || 0,
        disqualified:   stageCounts.disqualified   || 0,
        nurture:        stageCounts.nurture        || 0,
      },
      pacing: {
        readyToActivate,
        activationsLast7d: recentActivations,
        activationsPerDay: Math.round(activationsPerDay * 10) / 10,
        daysToClear,
        health,
      },
    });
  } catch (err) {
    console.error('pacing error:', err);
    res.status(500).json({ error: { message: 'Failed to load pacing' } });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// SLICE 4 — SENDER VISIBILITY
// ─────────────────────────────────────────────────────────────────────────────
// "Where are emails going FROM, and which LinkedIn account drives the LinkedIn
// tasks?" — exposed on the campaign drawer so reps don't have to navigate to
// Settings to find out before launching.
//
// Sender resolution logic mirrors SequenceStepFirer.resolveSender, simplified:
//   1. Per-campaign owner sender (campaign.owner_id) — primary path
//   2. Fallback: any active sender for that owner
//
// LinkedIn doesn't have a server-side account binding — it's whoever's signed
// into the Chrome extension when LinkedIn tasks fire. We surface this as a
// "you" answer with a tooltip explaining the model.
//
// Response shape:
//   {
//     email: {
//       configured: bool,
//       email: string | null,
//       provider: 'google' | 'outlook' | null,
//       display_name: string | null,
//       is_active: bool,
//       emails_sent_today: number,
//       daily_limit: number,
//       health: 'healthy' | 'warning' | 'unconfigured' | 'over_limit',
//       health_reason: string | null,
//       owner_id: number,
//       owner_name: string
//     },
//     linkedin: {
//       model: 'chrome_extension',
//       owner_id: number,
//       owner_name: string,
//       note: string
//     }
//   }

router.get('/:id/sender-summary', async (req, res) => {
  try {
    // Load campaign + owner. Sender resolution follows the campaign owner;
    // for backstop, owner_id falls back to created_by (same pattern as the
    // SLA sweeps).
    const campRes = await pool.query(
      `SELECT c.id, c.owner_id,
              COALESCE(c.owner_id, c.created_by) AS resolved_owner_id,
              u.first_name, u.last_name, u.email AS owner_user_email
         FROM prospecting_campaigns c
    LEFT JOIN users u ON u.id = COALESCE(c.owner_id, c.created_by)
        WHERE c.id = $1 AND c.org_id = $2`,
      [req.params.id, req.orgId]
    );
    if (!campRes.rows.length) {
      return res.status(404).json({ error: { message: 'Campaign not found' } });
    }
    const camp = campRes.rows[0];
    if (!(await CampaignAccess.requireCanAccess(req, res, camp))) return;
    const ownerId = camp.resolved_owner_id;
    const ownerName = [camp.first_name, camp.last_name].filter(Boolean).join(' ') || 'Unassigned';

    // Load ALL active senders for the owner — not just the next-to-fire. The
    // firer round-robins across active senders by emails_sent_today then
    // last_sent_at, so a campaign with multiple connected senders sends from
    // all of them. Surface that to the UI so reps don't think the campaign
    // sends from a single account.
    //
    // Sort order matches the firer's selection logic, so the FIRST row is
    // the next-to-fire sender (rep can see "[email protected] sends next").
    const sRes = await pool.query(
      `SELECT id, email, provider, display_name, is_active,
              emails_sent_today, daily_limit, last_reset_at, last_sent_at,
              created_at, account_data
         FROM prospecting_sender_accounts
        WHERE org_id = $1
          AND user_id = $2
          AND client_id IS NULL
          AND is_active = true
        ORDER BY
          (CASE WHEN last_reset_at < CURRENT_DATE THEN 0 ELSE emails_sent_today END) ASC,
          last_sent_at ASC NULLS FIRST`,
      [req.orgId, ownerId]
    );

    // Also load inactive senders for the owner — useful for the UI to show
    // "you have 1 active + 2 inactive senders, here's how to reactivate."
    const inactiveRes = await pool.query(
      `SELECT id, email, provider, display_name, is_active,
              emails_sent_today, daily_limit, account_data
         FROM prospecting_sender_accounts
        WHERE org_id = $1
          AND user_id = $2
          AND client_id IS NULL
          AND is_active = false`,
      [req.orgId, ownerId]
    );

    // Today-aware sent count — sender rows that haven't reset since yesterday
    // still carry yesterday's counter. UI should display 0 in that case.
    const todayStr = new Date().toISOString().slice(0, 10);
    function sentTodayFor(s) {
      if (!s.last_reset_at) return s.emails_sent_today || 0;
      return new Date(s.last_reset_at) < new Date(todayStr) ? 0 : (s.emails_sent_today || 0);
    }

    function computeHealth(s) {
      const sentToday = sentTodayFor(s);
      const dailyLimit = s.daily_limit || 0;
      const th = s.account_data && s.account_data.token_health;
      if (th && th.status === 'revoked') {
        return { health: 'revoked', reason: 'Disconnected — reconnect this account to resume sending.' };
      }
      if (!s.is_active) {
        return { health: 'warning', reason: 'Connected but inactive. Reactivate under Settings → Email senders.' };
      }
      if (dailyLimit > 0 && sentToday >= dailyLimit) {
        return { health: 'over_limit', reason: `Daily limit (${dailyLimit}) reached. Future sends queue until tomorrow.` };
      }
      if (dailyLimit > 0 && sentToday >= dailyLimit * 0.9) {
        return { health: 'warning', reason: `Near daily limit (${sentToday}/${dailyLimit}). Plan activations carefully.` };
      }
      return { health: 'healthy', reason: null };
    }

    // Build the senders[] list — active first (in firer order), then inactive.
    const senders = [
      ...sRes.rows.map(s => {
        const h = computeHealth(s);
        return {
          id: s.id,
          email: s.email,
          provider: s.provider,
          display_name: s.display_name,
          is_active: true,
          revoked: h.health === 'revoked',
          emails_sent_today: sentTodayFor(s),
          daily_limit: s.daily_limit || 0,
          health: h.health,
          health_reason: h.reason,
        };
      }),
      ...inactiveRes.rows.map(s => {
        const th = s.account_data && s.account_data.token_health;
        const revoked = !!(th && th.status === 'revoked');
        return {
          id: s.id,
          email: s.email,
          provider: s.provider,
          display_name: s.display_name,
          is_active: false,
          revoked,
          emails_sent_today: 0,
          daily_limit: s.daily_limit || 0,
          health: revoked ? 'revoked' : 'warning',
          health_reason: revoked
            ? 'Disconnected — reconnect this account to resume sending.'
            : 'Inactive — not in round-robin rotation.',
        };
      }),
    ];

    // Aggregate health across all ACTIVE senders. The overall rollup is the
    // worst-state among active senders, falling back to 'unconfigured' if
    // none are active.
    const activeSenders = senders.filter(s => s.is_active);

    let emailSummary;
    if (activeSenders.length === 0) {
      emailSummary = {
        configured: false,
        sender_count: 0,
        active_count: 0,
        inactive_count: senders.filter(s => !s.is_active).length,
        senders,                  // empty if no connected senders at all
        next_to_fire: null,
        health: 'unconfigured',
        health_reason: 'No active email senders connected for the campaign owner. Connect one under Settings → Email senders.',
        owner_id: ownerId,
        owner_name: ownerName,
        // Backward-compat: keep the old single-sender shape readable by the
        // pre-Slice-5 UI. Points at the first inactive sender if none active.
        email: senders[0]?.email || null,
        provider: senders[0]?.provider || null,
        display_name: senders[0]?.display_name || null,
        is_active: false,
        emails_sent_today: 0,
        daily_limit: 0,
      };
    } else {
      // Pick worst health among active senders for the rollup.
      const worstActive = activeSenders.reduce((worst, s) => {
        const rank = { healthy: 0, warning: 1, over_limit: 2 };
        return (rank[s.health] > rank[worst.health]) ? s : worst;
      }, activeSenders[0]);
      const nextToFire = activeSenders[0];   // already sorted by firer order

      emailSummary = {
        configured: true,
        sender_count: senders.length,
        active_count: activeSenders.length,
        inactive_count: senders.length - activeSenders.length,
        senders,
        next_to_fire: { id: nextToFire.id, email: nextToFire.email, provider: nextToFire.provider },
        health: worstActive.health,
        health_reason: worstActive.health_reason,
        owner_id: ownerId,
        owner_name: ownerName,
        // Backward-compat shape — pre-Slice-5 UI will still render the
        // next-to-fire sender from the top-level fields.
        email: nextToFire.email,
        provider: nextToFire.provider,
        display_name: nextToFire.display_name,
        is_active: true,
        emails_sent_today: nextToFire.emails_sent_today,
        daily_limit: nextToFire.daily_limit,
      };
    }

    // LinkedIn: execution happens from the rep's logged-in browser session
    // via the Chrome extension. Since the connection-sync feature, the
    // rep's LinkedIn identity IS known server-side: user_linkedin_seats
    // binds the LinkedIn publicIdentifier to the GoWarm user the first
    // time they run "Check & update" in the extension. Surface the bound
    // seat(s) so the campaign shows WHICH LinkedIn account sends.
    const linkedinSummary = {
      model: 'chrome_extension',
      owner_id: ownerId,
      owner_name: ownerName,
      seats: [],
      note: 'LinkedIn connection requests and messages are executed from the rep\'s logged-in LinkedIn account via the GoWarmCRM Chrome extension. The account shown here was verified the last time the rep synced connection activity; if no account is shown, the rep hasn\'t run "Check & update" in the extension yet.',
    };
    try {
      const seatRes = await pool.query(
        `SELECT public_identifier, display_name, last_seen_at
           FROM user_linkedin_seats
          WHERE org_id = $1 AND user_id = $2
       ORDER BY last_seen_at DESC`,
        [req.orgId, ownerId]
      );
      linkedinSummary.seats = seatRes.rows.map(s => ({
        public_identifier: s.public_identifier,
        display_name:      s.display_name || null,
        last_seen_at:      s.last_seen_at,
      }));
    } catch (seatErr) {
      // Table may predate the 2026_20 migration in some envs — the card
      // simply falls back to the unbound explanatory state.
      console.warn('sender-summary: linkedin seats lookup failed:', seatErr.message);
    }

    res.json({ email: emailSummary, linkedin: linkedinSummary });
  } catch (err) {
    console.error('sender-summary error:', err);
    res.status(500).json({ error: { message: 'Failed to load sender summary' } });
  }
});

module.exports = router;
