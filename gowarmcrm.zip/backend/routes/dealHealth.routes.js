/**
 * Deal Health Config & Competitors Routes
 *
 * Mounted at /api/deal-health (changed from a bare /api mount — see server.js).
 * The bare /api mount was a footgun: because this router does
 * `router.use(auth)`, ANY request under /api/* that didn't match a more
 * specific mount fell through to here and got 401'd — including public
 * webhooks. Mounting under a specific prefix removes that hazard.
 *
 * Resulting endpoints:
 *   GET/PUT        /api/deal-health/health-config
 *   GET/POST       /api/deal-health/competitors
 *   PUT/DELETE     /api/deal-health/competitors/:id
 *   POST           /api/deal-health/deals/:id/score
 *   POST           /api/deal-health/deals/score-all
 *   PATCH          /api/deal-health/deals/:id/signals
 *
 * Internal route paths below are UNCHANGED — only the mount prefix moved.
 */

const express = require('express');
const router = express.Router();
const db = require('../config/database');
const auth = require('../middleware/auth.middleware');
const { orgContext } = require('../middleware/orgContext.middleware');
const { scoreDeal } = require('../services/dealHealthService');

router.use(auth);
router.use(orgContext);

// ── Health Config ─────────────────────────────────────────────

router.get('/health-config', async (req, res) => {
  try {
    let r = await db.query(
      'SELECT * FROM deal_health_config WHERE user_id = $1 AND org_id = $2',
      [req.user.userId, req.orgId]
    );

    if (r.rows.length === 0) {
      r = await db.query(
        'INSERT INTO deal_health_config (user_id, org_id) VALUES ($1, $2) RETURNING *',
        [req.user.userId, req.orgId]
      );
    }

    res.json({ config: parseConfig(r.rows[0]) });
  } catch (err) {
    console.error('Get health config error:', err);
    res.status(500).json({ error: { message: 'Failed to fetch config' } });
  }
});

router.put('/health-config', async (req, res) => {
  try {
    const {
      aiEnabled,
      paramsEnabled,
      weightCloseDate, weightBuyerEngagement, weightProcess,
      weightDealSize, weightCompetitive, weightMomentum,
      paramWeights, thresholdHealthy, thresholdWatch,
      execTitles, legalTitles, procurementTitles, securityTitles,
      segmentAvgSmb, segmentAvgMidmarket, segmentAvgEnterprise,
      segmentSizeMultiplier, noMeetingDays, responseTimeMultiplier,
      multiThreadMinContacts
    } = req.body;

    const total = (weightCloseDate || 0) + (weightBuyerEngagement || 0) +
                  (weightProcess || 0) + (weightDealSize || 0) +
                  (weightCompetitive || 0) + (weightMomentum || 0);
    if (total !== 100) {
      return res.status(400).json({ error: { message: `Category weights must sum to 100 (got ${total})` } });
    }

    const r = await db.query(
      `INSERT INTO deal_health_config (
        user_id, org_id,
        ai_enabled, params_enabled,
        weight_close_date, weight_buyer_engagement, weight_process,
        weight_deal_size, weight_competitive, weight_momentum,
        param_weights, threshold_healthy, threshold_watch,
        exec_titles, legal_titles, procurement_titles, security_titles,
        segment_avg_smb, segment_avg_midmarket, segment_avg_enterprise,
        segment_size_multiplier, no_meeting_days, response_time_multiplier,
        multi_thread_min_contacts, updated_at
      ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,NOW())
      ON CONFLICT (user_id, org_id) DO UPDATE SET
        ai_enabled               = EXCLUDED.ai_enabled,
        params_enabled           = EXCLUDED.params_enabled,
        weight_close_date        = EXCLUDED.weight_close_date,
        weight_buyer_engagement  = EXCLUDED.weight_buyer_engagement,
        weight_process           = EXCLUDED.weight_process,
        weight_deal_size         = EXCLUDED.weight_deal_size,
        weight_competitive       = EXCLUDED.weight_competitive,
        weight_momentum          = EXCLUDED.weight_momentum,
        param_weights            = EXCLUDED.param_weights,
        threshold_healthy        = EXCLUDED.threshold_healthy,
        threshold_watch          = EXCLUDED.threshold_watch,
        exec_titles              = EXCLUDED.exec_titles,
        legal_titles             = EXCLUDED.legal_titles,
        procurement_titles       = EXCLUDED.procurement_titles,
        security_titles          = EXCLUDED.security_titles,
        segment_avg_smb          = EXCLUDED.segment_avg_smb,
        segment_avg_midmarket    = EXCLUDED.segment_avg_midmarket,
        segment_avg_enterprise   = EXCLUDED.segment_avg_enterprise,
        segment_size_multiplier  = EXCLUDED.segment_size_multiplier,
        no_meeting_days          = EXCLUDED.no_meeting_days,
        response_time_multiplier = EXCLUDED.response_time_multiplier,
        multi_thread_min_contacts = EXCLUDED.multi_thread_min_contacts,
        ai_enabled_updated_at    = CASE WHEN EXCLUDED.ai_enabled != deal_health_config.ai_enabled THEN NOW() ELSE deal_health_config.ai_enabled_updated_at END,
        updated_at               = NOW()
      RETURNING *`,
      [
        req.user.userId, req.orgId,
        aiEnabled !== false,
        JSON.stringify(paramsEnabled || {}),
        weightCloseDate, weightBuyerEngagement, weightProcess,
        weightDealSize, weightCompetitive, weightMomentum,
        JSON.stringify(paramWeights),
        thresholdHealthy, thresholdWatch,
        JSON.stringify(execTitles), JSON.stringify(legalTitles),
        JSON.stringify(procurementTitles), JSON.stringify(securityTitles),
        segmentAvgSmb, segmentAvgMidmarket, segmentAvgEnterprise,
        segmentSizeMultiplier, noMeetingDays, responseTimeMultiplier,
        multiThreadMinContacts
      ]
    );

    res.json({ config: parseConfig(r.rows[0]), message: 'Config saved' });
  } catch (err) {
    console.error('Save health config error:', err);
    res.status(500).json({ error: { message: 'Failed to save config' } });
  }
});

// ── Competitors ───────────────────────────────────────────────

router.get('/competitors', async (req, res) => {
  try {
    const r = await db.query(
      'SELECT * FROM competitors WHERE org_id = $1 AND user_id = $2 ORDER BY name ASC',
      [req.orgId, req.user.userId]
    );
    res.json({ competitors: r.rows.map(parseCompetitor) });
  } catch (err) {
    res.status(500).json({ error: { message: 'Failed to fetch competitors' } });
  }
});

router.post('/competitors', async (req, res) => {
  try {
    const { name, aliases, website, notes } = req.body;
    if (!name) return res.status(400).json({ error: { message: 'Name required' } });

    const r = await db.query(
      `INSERT INTO competitors (org_id, user_id, name, aliases, website, notes)
       VALUES ($1, $2, $3, $4, $5, $6) RETURNING *`,
      [req.orgId, req.user.userId, name, JSON.stringify(aliases || []), website, notes]
    );
    res.status(201).json({ competitor: parseCompetitor(r.rows[0]) });
  } catch (err) {
    res.status(500).json({ error: { message: 'Failed to create competitor' } });
  }
});

router.put('/competitors/:id', async (req, res) => {
  try {
    const { name, aliases, website, notes } = req.body;
    const r = await db.query(
      `UPDATE competitors
       SET name=$1, aliases=$2, website=$3, notes=$4, updated_at=NOW()
       WHERE id=$5 AND org_id=$6 AND user_id=$7 RETURNING *`,
      [name, JSON.stringify(aliases || []), website, notes, req.params.id, req.orgId, req.user.userId]
    );
    if (r.rows.length === 0) return res.status(404).json({ error: { message: 'Not found' } });
    res.json({ competitor: parseCompetitor(r.rows[0]) });
  } catch (err) {
    res.status(500).json({ error: { message: 'Failed to update competitor' } });
  }
});

router.delete('/competitors/:id', async (req, res) => {
  try {
    await db.query(
      'DELETE FROM competitors WHERE id=$1 AND org_id=$2 AND user_id=$3',
      [req.params.id, req.orgId, req.user.userId]
    );
    res.json({ message: 'Deleted' });
  } catch (err) {
    res.status(500).json({ error: { message: 'Failed to delete competitor' } });
  }
});

// ── Deal Scoring ──────────────────────────────────────────────

router.post('/deals/:id/score', async (req, res) => {
  try {
    const result = await scoreDeal(req.params.id, req.user.userId);
    res.json({ result });
  } catch (err) {
    console.error('Score deal error:', err);
    res.status(500).json({ error: { message: 'Failed to score deal' } });
  }
});

router.post('/deals/score-all', async (req, res) => {
  try {
    const deals = await db.query(
      `SELECT id FROM deals
       WHERE org_id = $1 AND owner_id = $2 AND stage NOT IN ($3,$4)`,
      [req.orgId, req.user.userId, 'closed_won', 'closed_lost']
    );

    const results = [];
    for (const deal of deals.rows) {
      try {
        const r = await scoreDeal(deal.id, req.user.userId);
        results.push(r);
      } catch (e) {
        results.push({ dealId: deal.id, error: e.message });
      }
    }

    res.json({ scored: results.length, results });
  } catch (err) {
    res.status(500).json({ error: { message: 'Failed to score deals' } });
  }
});

// ── Deal signal flags (manual) ────────────────────────────────
//
// BUG FIX: The original used string interpolation to embed the
// userId param position: `owner_id = ${Object.keys(updates).length + 2}`
// This produced SQL like `WHERE id = $1 AND owner_id = 4`
// treating 4 as a literal number, not a bound parameter.
// Fixed: userId is always the last bound value.

router.patch('/deals/:id/signals', async (req, res) => {
  try {
    const allowed = [
      'close_date_user_confirmed', 'buyer_event_user_confirmed',
      'buyer_event_description', 'economic_buyer_contact_id',
      'legal_engaged_user', 'security_review_user',
      'scope_approved_user', 'competitive_deal_user',
      'price_sensitivity_user', 'discount_pending_user'
    ];

    const updates = {};
    allowed.forEach(f => { if (req.body[f] !== undefined) updates[f] = req.body[f]; });

    if (Object.keys(updates).length === 0) {
      return res.status(400).json({ error: { message: 'No valid fields' } });
    }

    // Build parameterised SET clauses starting at $1
    const setClauses = Object.keys(updates).map((k, i) => `${k} = $${i + 1}`).join(', ');
    const values     = Object.values(updates);

    // $N+1 = dealId, $N+2 = orgId, $N+3 = userId — all properly bound
    const dealParamIdx = values.length + 1;
    const orgParamIdx  = values.length + 2;
    const userParamIdx = values.length + 3;

    values.push(req.params.id, req.orgId, req.user.userId);

    const r = await db.query(
      `UPDATE deals
       SET ${setClauses}, updated_at = NOW()
       WHERE id = $${dealParamIdx} AND org_id = $${orgParamIdx} AND owner_id = $${userParamIdx}
       RETURNING id, health, health_score, ${Object.keys(updates).join(', ')}`,
      values
    );

    if (r.rows.length === 0) return res.status(404).json({ error: { message: 'Deal not found' } });

    const scored = await scoreDeal(req.params.id, req.user.userId);
    res.json({ deal: r.rows[0], scored });
  } catch (err) {
    console.error('Update signals error:', err);
    res.status(500).json({ error: { message: 'Failed to update signals' } });
  }
});

// ── Helpers ───────────────────────────────────────────────────

function parseConfig(row) {
  const parse = v => typeof v === 'string' ? JSON.parse(v) : v;
  return {
    ...row,
    param_weights:      parse(row.param_weights),
    params_enabled:     parse(row.params_enabled),
    exec_titles:        parse(row.exec_titles),
    legal_titles:       parse(row.legal_titles),
    procurement_titles: parse(row.procurement_titles),
    security_titles:    parse(row.security_titles),
  };
}

function parseCompetitor(row) {
  return {
    ...row,
    aliases: typeof row.aliases === 'string' ? JSON.parse(row.aliases) : row.aliases
  };
}

module.exports = router;
