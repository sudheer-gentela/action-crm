/**
 * sequences.routes.js
 *
 * Mount at: app.use('/api/sequences', sequencesRoutes)
 *
 * Endpoints
 * ─────────────────────────────────────────────────────
 * GET    /                          list sequences for org
 * POST   /                          create sequence (+ steps)
 * GET    /:id                       get sequence with steps
 * PUT    /:id                       update name/description
 * DELETE /:id                       archive (soft)
 *
 * POST   /:id/steps                 add a step
 * PUT    /:id/steps/:stepId         update a step
 * DELETE /:id/steps/:stepId         delete a step
 * POST   /:id/steps/reorder         reorder steps
 *
 * POST   /:id/ai-generate           AI pre-fill steps for a prospect
 *
 * POST   /enroll                    enroll one or many prospects
 * GET    /enrollments               list enrollments for org
 * GET    /enrollments/:enrollId     get single enrollment + step logs
 * POST   /enrollments/:enrollId/stop  manually stop enrollment
 * POST   /enrollments/:enrollId/pause
 * POST   /enrollments/:enrollId/resume
 *
 * Cron logic lives in services/SequenceStepFirer.js — called directly by server.js
 */

const express = require('express');
const { sendEmail: sendGmailEmail }   = require('../services/googleService');
const { sendEmail: sendOutlookEmail } = require('../services/outlookService');
const { plainTextToHtml }             = require('../services/emailFormatter');
const router  = express.Router();

const authenticateToken = require('../middleware/auth.middleware');
const { orgContext }    = require('../middleware/orgContext.middleware');
const { pool }          = require('../config/database');
const SenderTokenHealth = require('../services/SenderTokenHealth');   // pre-approve sender credential guard
const TokenTrackingService = require('../services/TokenTrackingService');
const { resolvePersonalizeConfig } = require('../services/personalizeConfig');
// Slice 3: personalisation runs through the dispatcher, which walks every
// sequence step and calls per-channel skills with the right step_intent.
const PersonalizationDispatcher = require('../services/PersonalizationDispatcher');
const { buildLinkedInArtifacts }   = require('../services/linkedinSnippets');
const SendingSchedule              = require('../services/SendingScheduleResolver');

// ── AI provider chain (same pattern as ProspectingAIEnhancer) ─────────────────
const AIClientResolver = require('../services/ai/AIClientResolver');

// Phase 3 — sequence reporting: per-rep filters on /enrollments and /:id/stats
// go through the scope service for auth (silently drop out-of-scope userIds).
const ReportingScopeService = require('../services/ReportingScopeService');
const AccessPolicy          = require('../services/AccessPolicy');
const EnrollmentStepResolver = require('../services/EnrollmentStepResolver'); // identity-cursor + freeze copy-on-write
const ExperimentAssigner     = require('../services/ExperimentAssigner');     // A/B arm assignment (2026_47)
const CampaignAccess         = require('../services/CampaignAccess');        // isAdmin gate for A/B arm override

// ── Auth middleware on all routes ─────────────────────────────────────────────
router.use(authenticateToken, orgContext);

// ─────────────────────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────────────────────

/** Calculate next_step_due based on delay_days + delay_hours from now (used by enroll) */
function calcDueDate(delayDays, delayHours = 0) {
  const ms = ((parseInt(delayDays) || 0) * 24 + (parseInt(delayHours) || 0)) * 3600000;
  return new Date(Date.now() + ms);
}

/**
 * Resolve which LinkedIn funnel event a manually-actioned LinkedIn step
 * represents: 'connection_request_sent' or 'message_sent'.
 *
 * Replaces the old `step_order === 1` heuristic, which mislabeled a CR at
 * step 2 (e.g. email-first sequences) as a message. Mirrors
 * PersonalizationDispatcher.inferIntent:
 *   1. Explicit sequence_steps.step_intent wins.
 *   2. Already connected (channel_data.linkedin at/past connection_accepted)
 *      → message_sent (re-engagement DM, never a duplicate CR).
 *   3. Otherwise: first LinkedIn-channel step in the sequence → CR;
 *      any later LinkedIn step → message_sent.
 * Best-effort: any lookup failure falls back to message_sent (the
 * non-inflating choice for "requests sent" funnel counts).
 */
async function resolveLinkedInLogStatus(client, {
  sequenceId, stepId, stepIntent, connectionStatus,
}) {
  if (stepIntent) {
    return stepIntent === 'connection_request'
      ? 'connection_request_sent' : 'message_sent';
  }
  const STATUS_ORDER = [
    'connection_request_sent', 'connection_accepted',
    'message_sent', 'reply_received', 'meeting_booked',
  ];
  const acceptedIdx = STATUS_ORDER.indexOf('connection_accepted');
  if (STATUS_ORDER.indexOf(connectionStatus || '') >= acceptedIdx) {
    return 'message_sent';
  }
  try {
    const r = await client.query(
      `SELECT id FROM sequence_steps
        WHERE sequence_id = $1 AND channel = 'linkedin'
        ORDER BY step_order ASC
        LIMIT 1`,
      [sequenceId]
    );
    return (r.rows[0]?.id === stepId) ? 'connection_request_sent' : 'message_sent';
  } catch (err) {
    console.warn('resolveLinkedInLogStatus: first-step lookup failed:', err.message);
    return 'message_sent';
  }
}

/**
 * Render a sequence-step template with {{var}} substitution.
 *
 * Mirrors SequenceStepFirer.renderTemplate so the non-AI ("runSkill=false")
 * preview path produces exactly what the firer would send when an enrollment
 * has no personalised_steps blob and falls back to the raw template.
 *
 * Account-derived vars (company/industry/domain) fall back to the prospect's
 * own company_* fields, matching the firer's COALESCE(account, prospect)
 * resolution closely enough for a non-destructive preview.
 */
function renderPreviewTemplate(template, p) {
  if (!template) return '';
  const vars = {
    first_name: p.first_name || '',
    last_name:  p.last_name  || '',
    full_name:  `${p.first_name || ''} ${p.last_name || ''}`.trim(),
    title:      p.title            || '',
    company:    p.company_name     || '',
    industry:   p.company_industry || '',
    domain:     p.company_domain   || '',
  };
  return template.replace(/\{\{(\w+)\}\}/g, (_, key) => vars[key] ?? `{{${key}}}`);
}

// ─────────────────────────────────────────────────────────────────────────────
// SEQUENCES CRUD
// ─────────────────────────────────────────────────────────────────────────────

// GET /api/sequences
// Shared ownership gate for sequence mutations. Loads the sequence's owner and
// enforces AccessPolicy.requireCanEdit (owner / admin / permitted manager).
// Sends the 404 or 403 and returns false when the caller may not proceed.
async function gateSequenceEdit(req, res, seqId) {
  const r = await pool.query(
    `SELECT created_by, allow_manager_edit FROM sequences WHERE id = $1 AND org_id = $2`,
    [seqId, req.orgId]
  );
  if (!r.rows.length) {
    res.status(404).json({ error: { message: 'Not found' } });
    return false;
  }
  return AccessPolicy.requireCanEdit(req, res, r.rows[0].created_by, {
    allowManagerEdit: r.rows[0].allow_manager_edit,
  });
}

router.get('/', async (req, res) => {
  try {
    // Visibility scope: shared sequences are listed for everyone; private
    // sequences only for their owner and — via the resolved scope — that
    // owner's manager / an admin. Optional ?scope=mine|team and ?depth= drive
    // the Mine/Team toggle; default resolves by role (member→self,
    // manager→team, admin→all).
    const explicitUserIds = req.query.scope === 'mine' ? [req.userId] : undefined;
    const { userIds } = await AccessPolicy.resolveScope(req, {
      depth: req.query.depth,
      explicitUserIds,
    });

    const params = [req.orgId];
    const visClause = AccessPolicy.visibilityClause(
      { alias: 's', ownerCol: 'created_by', scopeUserIds: userIds },
      params
    );

    const { rows } = await pool.query(
      `SELECT s.*,
              COUNT(DISTINCT ss.id)::int  AS step_count,
              COUNT(DISTINCT se.id)::int  AS enrollment_count,
              cu.first_name AS creator_first_name,
              cu.last_name  AS creator_last_name
         FROM sequences s
    LEFT JOIN sequence_steps ss       ON ss.sequence_id = s.id
    LEFT JOIN sequence_enrollments se ON se.sequence_id = s.id AND se.status = 'active'
    LEFT JOIN users           cu      ON cu.id = s.created_by
        WHERE s.org_id = $1 AND s.status != 'archived'
          AND ${visClause}
     GROUP BY s.id, cu.first_name, cu.last_name
     ORDER BY s.created_at DESC`,
      params
    );
    // Per-row editability for the UI (owner / admin / permitted manager),
    // resolved with a single batch context — no N+1 queries.
    const editCtx = await AccessPolicy.editContext(req);
    res.json({
      sequences: rows.map(r => ({ ...r, can_edit: AccessPolicy.canEditWith(editCtx, r.created_by, r.allow_manager_edit) })),
    });
  } catch (err) {
    console.error('sequences GET /', err);
    res.status(500).json({ error: { message: 'Failed to load sequences' } });
  }
});

// POST /api/sequences  — body: { name, description, require_approval, ai_enabled, steps: [{channel, delay_days, subject_template, body_template, task_note, require_approval}] }
router.post('/', async (req, res) => {
  const { name, description, require_approval = true, ai_enabled = false, personalize_config_default = null, steps = [], visibility = 'shared', allow_manager_edit = false, stop_on_connection_accept = false } = req.body;
  if (!name?.trim()) return res.status(400).json({ error: { message: 'name is required' } });
  const vis = visibility === 'private' ? 'private' : 'shared';

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const seqRes = await client.query(
      `INSERT INTO sequences (org_id, name, description, created_by, require_approval, ai_enabled, personalize_config_default, visibility, allow_manager_edit, stop_on_connection_accept)
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) RETURNING *`,
      [req.orgId, name.trim(), description || null, req.user.userId, require_approval,
       ai_enabled === true,
       personalize_config_default ? JSON.stringify(personalize_config_default) : null,
       vis, allow_manager_edit === true, stop_on_connection_accept === true]
    );
    const seq = seqRes.rows[0];

    const insertedSteps = [];
    for (let i = 0; i < steps.length; i++) {
      const s = steps[i];
      const sr = await client.query(
        `INSERT INTO sequence_steps
                     (sequence_id, org_id, step_order, channel, delay_days, delay_hours,
                      subject_template, body_template, task_note, require_approval,
                      personalize_config, step_intent)
              VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
        [seq.id, req.orgId, i + 1, s.channel, s.delay_days ?? 0, s.delay_hours ?? 0,
         s.subject_template || null, s.body_template || null, s.task_note || null,
         s.require_approval !== undefined ? s.require_approval : null,
         s.personalize_config ? JSON.stringify(s.personalize_config) : null,
         // Slice 3: step_intent — null means "auto-infer at dispatch time".
         s.step_intent || null]
      );
      insertedSteps.push(sr.rows[0]);
    }

    await client.query('COMMIT');
    res.status(201).json({ sequence: { ...seq, steps: insertedSteps } });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('sequences POST /', err);
    res.status(500).json({ error: { message: 'Failed to create sequence' } });
  } finally {
    client.release();
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// AI PERSONALISE ENROLLMENT  (Slice 3 — refactored)
// POST /api/sequences/ai-personalise-enrollment
// body: { sequenceId, prospectId, hookPreferences? }
//
// Returns personalised step content for ONE prospect. This endpoint is now
// a thin wrapper around PersonalizationDispatcher — the entire 250-line
// inline prompt that lived here previously is replaced by the dispatcher,
// which walks every sequence step and calls the right per-channel skill
// (outreach-email / outreach-linkedin) with the inferred step_intent.
//
// Response shape is preserved for back-compat with existing callers
// (SequencesView "Preview personalised" feature, etc.):
//   {
//     prospectId,
//     hasResearch,
//     steps: [{ step_order, subject, body, task_note, personalize_sources }],
//     dispatchSummary: { total, personalised, skipped, errored },
//     errors: [{ stepOrder, channel, intent, reason }]
//   }
//
// The dispatchSummary and errors fields are NEW in Slice 3 — additive, so
// callers that ignore them still work.
// ─────────────────────────────────────────────────────────────────────────────
router.post('/ai-personalise-enrollment', async (req, res) => {
  const { sequenceId, prospectId, hookPreferences } = req.body || {};
  if (!sequenceId || !prospectId) {
    return res.status(400).json({ error: { message: 'sequenceId and prospectId are required' } });
  }

  try {
    // Sequence existence + org scope — guards against the dispatcher loading
    // a sequence from a different org.
    const seqRes = await pool.query(
      `SELECT id, name FROM sequences WHERE id = $1 AND org_id = $2`,
      [sequenceId, req.orgId]
    );
    if (!seqRes.rows.length) {
      return res.status(404).json({ error: { message: 'Sequence not found' } });
    }

    // Prospect existence — same guard.
    const pRes = await pool.query(
      `SELECT id, research_notes, research_meta FROM prospects
        WHERE id = $1 AND org_id = $2 AND deleted_at IS NULL`,
      [prospectId, req.orgId]
    );
    if (!pRes.rows.length) {
      return res.status(404).json({ error: { message: 'Prospect not found' } });
    }
    const p = pRes.rows[0];
    const hasResearch = !!(
      p.research_notes ||
      (p.research_meta && typeof p.research_meta === 'object' &&
        (p.research_meta.signal_summary || p.research_meta.researchBullets))
    );

    // Dispatch.
    const dispatchResult = await PersonalizationDispatcher.personaliseEnrollment({
      orgId:      req.orgId,
      userId:     req.user.userId,
      sequenceId,
      prospectId,
      hookPreferences,
    });

    // Convert dispatcher's keyed map into the legacy steps[] array shape.
    const stepOrders = Object.keys(dispatchResult.personalisedSteps || {})
      .map(k => parseInt(k, 10))
      .filter(Number.isFinite)
      .sort((a, b) => a - b);

    const steps = stepOrders.map(order => {
      const s = dispatchResult.personalisedSteps[String(order)] || {};
      return {
        step_order:          order,
        subject:             s.subject   || '',
        body:                s.body      || '',
        task_note:           s.task_note || '',
        personalize_sources: s.personalize_sources || null,
      };
    });

    res.json({
      prospectId,
      hasResearch,
      steps,
      dispatchSummary: dispatchResult.summary,
      errors:          dispatchResult.errors || [],
    });
  } catch (err) {
    console.error('ai-personalise-enrollment error:', err);
    res.status(err.statusCode || 500).json({
      error: { message: 'AI personalisation failed: ' + err.message },
    });
  }
});


// ─────────────────────────────────────────────────────────────────────────────
// ENROLL  (must be before /:id to avoid shadowing)
// ─────────────────────────────────────────────────────────────────────────────

// POST /api/sequences/enroll
// body: { sequenceId, prospectIds: [id, ...], personalisedSteps?: { [prospectId]: { [step_order]: { subject, body, task_note } } } }
router.post('/enroll', async (req, res) => {
  const { sequenceId, prospectIds, personalisedSteps, variantKeyOverride } = req.body;

  // A/B manual override (2026_47). Admin-only, single-prospect only. A pinned
  // prospect is not a randomised one; pinning a batch would quietly destroy the
  // randomisation the whole design rests on. bulk-activate never accepts it.
  if (variantKeyOverride) {
    if (!(await CampaignAccess.isAdmin(req))) {
      return res.status(403).json({ error: { message: 'Only admins can pin a prospect to an A/B arm' } });
    }
    if (!Array.isArray(prospectIds) || prospectIds.length !== 1) {
      return res.status(400).json({ error: {
        message: 'variantKeyOverride applies to exactly one prospect. Pinning a batch would destroy randomisation.',
        code: 'AB_OVERRIDE_BATCH' } });
    }
  }
  if (!sequenceId || !Array.isArray(prospectIds) || prospectIds.length === 0) {
    return res.status(400).json({ error: { message: 'sequenceId and prospectIds[] are required' } });
  }

  // Validate sequence belongs to org
  const seqRes = await pool.query(
    `SELECT * FROM sequences WHERE id=$1 AND org_id=$2 AND status='active'`,
    [sequenceId, req.orgId]
  );
  if (!seqRes.rows.length) return res.status(404).json({ error: { message: 'Sequence not found' } });

  const sequenceName = seqRes.rows[0].name;

  // Get first step to calculate next_step_due
  const firstStepRes = await pool.query(
    `SELECT delay_days, delay_hours FROM sequence_steps WHERE sequence_id=$1 ORDER BY step_order LIMIT 1`,
    [sequenceId]
  );
  const firstDelayDays  = firstStepRes.rows[0]?.delay_days  ?? 0;
  const firstDelayHours = firstStepRes.rows[0]?.delay_hours ?? 0;

  // step_order → step id map, so any AI drafts supplied at enroll (keyed by
  // step_order in the request body) get stored under the stable step ID that the
  // firer now reads personalised_steps by.
  const stepMapRes = await pool.query(
    `SELECT id, step_order FROM sequence_steps WHERE sequence_id=$1`,
    [sequenceId]
  );
  const orderToStepId = new Map(stepMapRes.rows.map(r => [r.step_order, r.id]));

  const enrolled = [];
  const skipped  = [];

  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    for (const prospectId of prospectIds) {
      try {
        const nextDue = calcDueDate(firstDelayDays, firstDelayHours);

        // Pull per-prospect AI drafts if provided (request keys by step_order) and
        // remap to step-ID keys so the firer's id-keyed cache picks them up.
        const prosStepsByOrder = personalisedSteps?.[prospectId] ?? {};
        const prosSteps = {};
        for (const [ord, val] of Object.entries(prosStepsByOrder)) {
          const sid = orderToStepId.get(Number(ord));
          if (sid != null) prosSteps[String(sid)] = val;
        }

        // A/B (2026_47): pure hash of (experiment_id, prospect_id). Both nulls
        // when the sequence has no running experiment — every downstream read
        // then falls through to the base step templates.
        //
        // variantKeyOverride pins this prospect to a named arm. Admin-gated
        // above; throws AB_BAD_OVERRIDE if the arm is not active in the running
        // experiment, rather than silently falling back to the hash. Each
        // override is a known, small bias — use it to inspect copy, not to steer
        // a test. chk_se_arm_has_experiment forces both columns or neither.
        const { experimentId, variantKey } = await ExperimentAssigner.assignVariant(client, {
          sequenceId, prospectId, variantKeyOverride,
        });

        const er = await client.query(
          `INSERT INTO sequence_enrollments
                       (org_id, sequence_id, prospect_id, enrolled_by, next_step_due, personalised_steps, variant_key, experiment_id)
                VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
           ON CONFLICT (sequence_id, prospect_id) DO NOTHING
           RETURNING *`,
          [req.orgId, sequenceId, prospectId, req.user.userId, nextDue, JSON.stringify(prosSteps), variantKey, experimentId]
        );

        if (er.rows.length) {
          // Stamp the identity cursor (current_step_id + channel) for the first step.
          await EnrollmentStepResolver.stampInitialCursor(client, er.rows[0].id, sequenceId);
          enrolled.push(er.rows[0]);

          // Write activity so enrollment appears in the prospect's Activity tab
          try {
            await client.query(
              `INSERT INTO prospecting_activities
                           (org_id, prospect_id, user_id, activity_type, description, metadata)
                    VALUES ($1, $2, $3, 'sequence_enrolled', $4, $5)`,
              [req.orgId, 
                prospectId,
                req.user.userId,
                `Enrolled in sequence "${sequenceName}"`,
                JSON.stringify({
                  sequenceId,
                  sequenceName,
                  enrollmentId: er.rows[0].id,
                }),
              ]
            );
          } catch (actErr) {
            // Non-fatal — don't block enrollment if activity log fails
            console.warn('sequence enroll: activity log failed for prospect', prospectId, actErr.message);
          }
        } else {
          skipped.push({ prospectId, reason: 'already enrolled' });
        }
      } catch (err) {
        // A bad arm override is caller error, not a per-prospect skip: fail the
        // whole call loudly rather than silently enrolling with the hashed arm.
        if (err.code === 'AB_BAD_OVERRIDE') {
          await client.query('ROLLBACK');
          return res.status(400).json({ error: { message: err.message, code: err.code } });
        }
        skipped.push({ prospectId, reason: err.message });
      }
    }

    await client.query('COMMIT');
    res.json({ enrolled: enrolled.length, skipped, enrollments: enrolled });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('enroll error', err);
    res.status(500).json({ error: { message: 'Enrollment failed' } });
  } finally {
    client.release();
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// ENROLLMENTS  (must be before /:id to avoid shadowing)
// ─────────────────────────────────────────────────────────────────────────────

// GET /api/sequences/enrollments
router.get('/enrollments', async (req, res) => {
  const { prospectId, status, enrolledBy, depth, sequenceId, campaignId } = req.query;
  try {
    // Pagination (Phase 5): ?limit= & ?offset=. Backward compatible — callers
    // that pass neither get the original first-page behavior (200 rows). The
    // response now also carries { total, limit, offset } so the UI can page
    // through campaigns/sequences larger than one page (e.g. 396 enrollments).
    // limit is clamped to [1, 500] per page; total reflects the full filtered
    // set regardless of limit/offset.
    const PAGE_MAX = 500;
    const limit = Math.min(
      Math.max(parseInt(req.query.limit, 10) || 200, 1),
      PAGE_MAX
    );
    const offset = Math.max(parseInt(req.query.offset, 10) || 0, 0);
    // Phase 3: optional ?enrolledBy=csv and ?depth= filter the enrollments
    // by the rep who enrolled the prospect, intersected with the viewer's
    // resolved scope (silently drops out-of-scope IDs).
    //
    // Phase 4: added ?sequenceId= and ?campaignId= so the reporting view
    // can list prospects within a specific sequence / campaign without
    // pulling the whole org's enrollments.
    //
    // Backward compat: callers without enrolledBy/depth see the original
    // behavior (no per-rep filter). All other filters are independently
    // applied.
    // Deny-by-default: ALWAYS scope by the viewer's reporting scope (member →
    // self, manager → team, admin → all), even when no enrolledBy/depth is
    // passed. ?enrolledBy= or ?scope=mine narrow within that scope; out-of-
    // scope IDs are silently dropped by the service.
    const explicitUserIds = enrolledBy !== undefined
      ? String(enrolledBy).split(',').map(s => parseInt(s.trim(), 10)).filter(Number.isInteger)
      : (req.query.scope === 'mine' ? [req.user.userId] : null);
    const scope = await ReportingScopeService.resolveReportingScope(
      req.user.userId,
      req.orgId,
      { depth, explicitUserIds }
    );
    const scopedUserIds = scope.userIds;   // always non-null now

    // Build the shared filter clause once so the COUNT and the data query can
    // never drift apart. $1 is always org_id; subsequent placeholders are
    // appended in lockstep with `params`.
    let whereClause = ' WHERE se.org_id = $1';
    const params = [req.orgId];

    if (prospectId) { params.push(prospectId); whereClause += ` AND se.prospect_id = $${params.length}`; }
    if (status)     { params.push(status);     whereClause += ` AND se.status = $${params.length}`; }
    if (sequenceId) { params.push(sequenceId); whereClause += ` AND se.sequence_id = $${params.length}`; }
    if (campaignId) { params.push(campaignId); whereClause += ` AND p.campaign_id = $${params.length}`; }
    if (scopedUserIds !== null) {
      params.push(scopedUserIds);
      whereClause += ` AND se.enrolled_by = ANY($${params.length}::int[])`;
    }


    // Total over the full filtered set (independent of limit/offset) so the UI
    // knows how many pages remain. Same FROM/JOIN/WHERE as the data query.
    const countRes = await pool.query(
      `SELECT COUNT(*)::int AS total
         FROM sequence_enrollments se
         JOIN sequences s ON s.id = se.sequence_id
         JOIN prospects p ON p.id = se.prospect_id
        ${whereClause}`,
      params
    );
    const total = countRes.rows[0]?.total || 0;

    // Phase 4: enriched response. The reporting view needs per-enrollment
    // step progress (current step, total steps, last log activity) without
    // a per-row follow-up fetch. We compute these inline via subqueries on
    // sequence_steps and sequence_step_logs.
    //
    // ORDER BY enrolled_at DESC, id DESC — the id tiebreaker keeps ordering
    // stable across pages when many rows share an enrolled_at (e.g. a single
    // bulk-activate stamps near-identical timestamps); without it, rows could
    // shift between pages and be skipped or duplicated.
    const dataQuery = `
      SELECT se.*,
             s.name AS sequence_name,
             p.first_name, p.last_name, p.email, p.company_name,
             p.campaign_id,
             eu.first_name AS enrolled_by_first_name,
             eu.last_name  AS enrolled_by_last_name,
             (SELECT COUNT(*)::int FROM sequence_steps
                WHERE sequence_id = se.sequence_id) AS total_steps,
             (SELECT MAX(fired_at) FROM sequence_step_logs
                WHERE enrollment_id = se.id) AS last_fired_at,
             (SELECT status FROM sequence_step_logs
                WHERE enrollment_id = se.id
                ORDER BY fired_at DESC NULLS LAST LIMIT 1) AS last_log_status
        FROM sequence_enrollments se
        JOIN sequences s ON s.id = se.sequence_id
        JOIN prospects p ON p.id = se.prospect_id
   LEFT JOIN users     eu ON eu.id = se.enrolled_by
        ${whereClause}
       ORDER BY se.enrolled_at DESC, se.id DESC
       LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;

    const { rows } = await pool.query(dataQuery, [...params, limit, offset]);
    res.json({ enrollments: rows, total, limit, offset });
  } catch (err) {
    console.error('enrollments GET', err);
    res.status(500).json({ error: { message: 'Failed to load enrollments' } });
  }
});

// GET /api/sequences/enrollments/:enrollId
// Returns enrollment + full step timeline:
//   - Executed steps (from sequence_step_logs) with fired_at, subject, body, status
//   - Future planned steps (from sequence_steps) with calculated due dates
//   - `inbound[]` on each executed step: what came BACK after we sent it
//
// ─────────────────────────────────────────────────────────────────────────────
// INBOUND THREADING (2026-07)
//
// The timeline used to render only what we sent and what we plan to send. A
// prospect could reply, or hard-bounce, and the panel whose whole job is to
// explain the enrollment would say nothing about it. Three inbound sources now
// nest under the step they answer:
//
//   email_reply     `emails`, direction received/inbound, deleted_at IS NULL
//   linkedin_reply  `prospecting_activities`, linkedin_event/reply_received or
//                   response_received with metadata->>'channel'='linkedin'
//   bounce          `email_delivery_events`
//
// These are the SAME predicates services/ReplyEventsQuery.js uses to count
// replies. A reply visible here is a reply counted there. `deleted_at IS NULL`
// means an NDR quarantined by NdrCleanupService vanishes from the reply slot
// and reappears on the same step as a bounce — which is the correct story.
//
// HOW AN INBOUND EVENT FINDS ITS STEP
//
//   * bounce  → `email_delivery_events.step_log_id` is a direct FK. Exact.
//   * replies → the most recent executed log whose fired_at precedes the reply,
//               preferring a log on the same channel.
//
// There is no message-threading key to use, and this is worth stating plainly
// rather than discovering later: `emails.conversation_id` is written ONLY by
// jobs/syncScheduler.js (the deals/contacts mailbox sync). Neither
// SequenceStepFirer's outbound INSERT (services/SequenceStepFirer.js:1714) nor
// the prospecting inbox's inbound INSERT (routes/prospecting-inbox.routes.js:923)
// populates it, and no In-Reply-To / References header is stored anywhere. So
// for sequence mail every conversation_id is NULL and provider-level threading
// is unavailable. Timestamp anchoring is not a shortcut here — it is the only
// signal that exists. When conversation_id IS present (a prospect whose mail
// also flows through the deals sync) we use it, because it is strictly better.
//
// Populating conversation_id + external_id on both prospecting paths would let
// this become exact. That is a separate change, flagged not smuggled.
//
// GRAIN
//
// Replies are scoped to `prospect_id` and `enrolled_at`, not to enrollment_id —
// an inbound email carries no enrollment reference. A prospect enrolled twice
// will therefore show the same reply on both enrollments. That mirrors what the
// reply COUNT does (reply_events attributes to the most recent preceding
// enrollment), so a manager reading one enrollment sees a true statement; it is
// only across two open panels that the same reply appears twice.
// ─────────────────────────────────────────────────────────────────────────────
router.get('/enrollments/:enrollId', async (req, res) => {
  try {
    const er = await pool.query(
      `SELECT se.*, s.name AS sequence_name, s.id AS seq_id,
              p.first_name, p.last_name, p.email, p.company_name
         FROM sequence_enrollments se
         JOIN sequences s ON s.id = se.sequence_id
         JOIN prospects p ON p.id = se.prospect_id
        WHERE se.id=$1 AND se.org_id=$2`,
      [req.params.enrollId, req.orgId]
    );
    if (!er.rows.length) return res.status(404).json({ error: { message: 'Not found' } });
    const enrollment = er.rows[0];

    // All executed / drafted logs for this enrollment
    const logsRes = await pool.query(
      `SELECT ssl.id, ssl.status, ssl.fired_at, ssl.scheduled_send_at,
              ssl.subject, ssl.body, ssl.channel, ssl.error_message,
              ssl.email_id,
              oe.conversation_id AS out_conversation_id,
              ss.step_order, ss.channel AS step_channel, ss.task_note,
              ss.delay_days, ss.delay_hours, ss.id AS step_id
         FROM sequence_step_logs ssl
         JOIN sequence_steps ss ON ss.id = ssl.sequence_step_id
         LEFT JOIN emails oe ON oe.id = ssl.email_id AND oe.org_id = $2
        WHERE ssl.enrollment_id = $1
        ORDER BY ss.step_order ASC, ssl.fired_at ASC NULLS LAST`,
      [req.params.enrollId, req.orgId]
    );

    // ── Inbound: replies and bounces, anchored to the step they answer ──
    //
    // Keyed by STEP_ORDER, not by log id. Migration 2026_48 can leave a second
    // 'superseded_duplicate' row on a (enrollment, step) pair, and the timeline
    // renders exactly one log per step_order. Keying by log id would silently
    // drop a reply anchored to the row that lost. Those rows are also excluded
    // from the anchor set — a duplicate send is not a thing a prospect answered.
    const inboundByStep = {};
    const inboundUnanchored = [];
    const stepOrderByLogId = new Map(logsRes.rows.map(l => [l.id, l.step_order]));
    const DEAD_LOG_STATUS = new Set(['superseded_duplicate', 'skipped']);
    const anchors = logsRes.rows
      .filter(l => l.fired_at && !DEAD_LOG_STATUS.has(l.status))
      .map(l => ({
        stepOrder: l.step_order,
        firedAt:   new Date(l.fired_at).getTime(),
        channel:   l.channel,
        convId:    l.out_conversation_id || null,
      }))
      .sort((a, b) => a.firedAt - b.firedAt);

    /**
     * Which step does this inbound event answer?
     * conversation_id when the provider gave us one (never, for sequence mail
     * — see header); otherwise the latest preceding log, same channel first.
     */
    function anchorFor(occurredAtIso, preferChannel, convId) {
      if (convId) {
        const byConv = anchors.find(a => a.convId && a.convId === convId);
        if (byConv) return byConv.stepOrder;
      }
      const t = new Date(occurredAtIso).getTime();
      if (Number.isNaN(t)) return null;
      const preceding = anchors.filter(a => a.firedAt <= t);
      if (!preceding.length) return null;
      const sameChannel = preceding.filter(a => a.channel === preferChannel);
      const candidates = sameChannel.length ? sameChannel : preceding;
      return candidates[candidates.length - 1].stepOrder;
    }

    function push(stepOrder, item) {
      if (stepOrder === null || stepOrder === undefined) { inboundUnanchored.push(item); return; }
      (inboundByStep[stepOrder] = inboundByStep[stepOrder] || []).push(item);
    }

    // enrolled_at is timestamptz; emails.sent_at and prospecting_activities
    // .created_at are `timestamp without time zone` holding UTC wall time. Every
    // comparison is made explicit, and every value is returned AT TIME ZONE 'UTC'
    // so node-postgres hands JS a real instant instead of re-reading the naive
    // value in the server's local zone.
    const [replyRes, liRes, bounceRes] = await Promise.all([
      pool.query(
        `SELECT e.id,
                (e.sent_at AT TIME ZONE 'UTC') AS occurred_at,
                e.subject, LEFT(e.body, 4000) AS body,
                e.from_address, e.conversation_id
           FROM emails e
          WHERE e.org_id      = $1
            AND e.prospect_id = $2
            AND e.direction   IN ('received', 'inbound')
            AND e.deleted_at  IS NULL
            AND e.sent_at    >= ($3::timestamptz AT TIME ZONE 'UTC')
          ORDER BY e.sent_at ASC`,
        [req.orgId, enrollment.prospect_id, enrollment.enrolled_at]
      ),
      pool.query(
        `SELECT a.id,
                (a.created_at AT TIME ZONE 'UTC') AS occurred_at,
                a.description,
                a.metadata ->> 'note'      AS note,
                a.metadata ->> 'sentiment' AS sentiment
           FROM prospecting_activities a
          WHERE a.org_id      = $1
            AND a.prospect_id = $2
            AND (
                 (a.activity_type = 'linkedin_event'
                  AND a.metadata ->> 'event' = 'reply_received')
              OR (a.activity_type = 'response_received'
                  AND a.metadata ->> 'channel' = 'linkedin')
            )
            AND a.created_at >= ($3::timestamptz AT TIME ZONE 'UTC')
          ORDER BY a.created_at ASC`,
        [req.orgId, enrollment.prospect_id, enrollment.enrolled_at]
      ),
      // step_log_id is the exact anchor. Rows where the NDR could not be linked
      // to a send (step_log_id IS NULL) are still this prospect's bounces — we
      // take them and anchor by time, rather than dropping the one event that
      // explains why a sequence stopped.
      pool.query(
        `SELECT ede.id, ede.step_log_id, ede.event_type, ede.failed_recipient,
                ede.smtp_code, ede.diagnostic_excerpt, ede.enrollment_stopped,
                ede.detected_at AS occurred_at
           FROM email_delivery_events ede
          WHERE ede.org_id = $1
            AND (
                 ede.step_log_id IN (
                   SELECT id FROM sequence_step_logs WHERE enrollment_id = $2
                 )
              OR (ede.step_log_id IS NULL
                  AND ede.prospect_id = $3
                  AND ede.detected_at >= $4::timestamptz)
            )
          ORDER BY ede.detected_at ASC`,
        [req.orgId, req.params.enrollId, enrollment.prospect_id, enrollment.enrolled_at]
      ),
    ]);

    for (const r of replyRes.rows) {
      push(anchorFor(r.occurred_at, 'email', r.conversation_id), {
        kind:        'email_reply',
        id:          r.id,
        occurred_at: r.occurred_at,
        from:        r.from_address || null,
        subject:     r.subject || null,
        body:        r.body || null,
      });
    }

    for (const r of liRes.rows) {
      push(anchorFor(r.occurred_at, 'linkedin', null), {
        kind:        'linkedin_reply',
        id:          r.id,
        occurred_at: r.occurred_at,
        from:        null,
        subject:     null,
        body:        r.note || r.description || null,
        sentiment:   r.sentiment || null,
      });
    }

    for (const r of bounceRes.rows) {
      // step_log_id is a direct FK — resolve it to the step it belongs to.
      // Only when the NDR was never linked to a send do we fall back to time.
      //
      // email_delivery_events.step_log_id is bigint, and node-postgres returns
      // int8 as a STRING (JS numbers can't hold the full range). sequence_step_logs.id
      // is int4 and comes back as a number. Comparing them raw always misses, and
      // every bounce would silently fall through to timestamp anchoring.
      const stepLogId = r.step_log_id === null || r.step_log_id === undefined
        ? null
        : Number(r.step_log_id);
      const exact = (stepLogId !== null && stepOrderByLogId.has(stepLogId))
        ? stepOrderByLogId.get(stepLogId)
        : anchorFor(r.occurred_at, 'email', null);
      push(exact, {
        kind:              'bounce',
        id:                r.id,
        occurred_at:       r.occurred_at,
        event_type:        r.event_type,
        failed_recipient:  r.failed_recipient || null,
        smtp_code:         r.smtp_code || null,
        diagnostic:        r.diagnostic_excerpt || null,
        enrollment_stopped: r.enrollment_stopped === true,
        // The NDR body names the address that actually failed. The old
        // domain-match ingest attached bounces to an arbitrary colleague, so a
        // mismatch here means either a stale prospect address or a
        // misattributed bounce. Worth showing, not worth guessing about.
        address_mismatch: !!(r.failed_recipient && enrollment.email
          && r.failed_recipient.toLowerCase() !== String(enrollment.email).toLowerCase()),
      });
    }

    for (const list of Object.values(inboundByStep)) {
      list.sort((a, b) => new Date(a.occurred_at) - new Date(b.occurred_at));
    }

    // All steps in the sequence (to build future planned steps)
    const stepsRes = await pool.query(
      `SELECT id, step_order, channel, delay_days, delay_hours, subject_template,
              body_template, task_note, require_approval
         FROM sequence_steps
        WHERE sequence_id = $1
        ORDER BY step_order ASC`,
      [enrollment.seq_id]
    );

    // A/B (2026_46): show the prospect's ARM copy in the timeline, not the base
    // step. Display-only. No-op (and no query) when variant_key IS NULL.
    if (enrollment.variant_key) {
      const overlay = await EnrollmentStepResolver.loadVariantOverlay(
        pool, enrollment.experiment_id, enrollment.variant_key
      );
      stepsRes.rows = EnrollmentStepResolver.applyOverlay(stepsRes.rows, overlay);
    }

    // Build a map of step_order → log (most recent if multiple)
    const logByStep = {};
    for (const log of logsRes.rows) {
      logByStep[log.step_order] = log;
    }

    // Calculate due dates for future steps by walking from next_step_due
    const now = new Date();
    let rollingDate = enrollment.next_step_due
      ? new Date(enrollment.next_step_due)
      : now;

    // Resolve the current step's ordinal position by IDENTITY (current_step_id),
    // reorder-safe, falling back to the stored ordinal if the cursor id isn't in
    // the live step list. Prevents the timeline from marking the wrong step as
    // "current" after a reorder. (Frozen-snapshot ordering isn't reflected in the
    // projected future dates — acceptable for a preview.)
    const curStepRow = stepsRes.rows.find(s => s.id === enrollment.current_step_id);
    const curOrder = curStepRow ? curStepRow.step_order : enrollment.current_step;

    const timeline = stepsRes.rows.map(step => {
      const log = logByStep[step.step_order];

      if (log) {
        return {
          step_order:       step.step_order,
          step_id:          step.id,
          channel:          step.channel,
          delay_days:       step.delay_days,
          delay_hours:      step.delay_hours ?? 0,
          task_note:        step.task_note || null,
          subject_template: step.subject_template || null,
          log_id:           log.id,
          status:           log.status,
          fired_at:         log.fired_at || null,
          scheduled_send_at: log.scheduled_send_at || null,
          subject:          log.subject || null,
          body:             log.body    || null,
          error_message:    log.error_message || null,
          is_future:        false,
          inbound:          inboundByStep[step.step_order] || [],
        };
      }

      let due;
      if (step.step_order === curOrder) {
        due = rollingDate;
      } else if (step.step_order > curOrder) {
        const delayMs = ((parseInt(step.delay_days) || 0) * 24
                       + (parseInt(step.delay_hours) || 0)) * 3600000;
        due = new Date(rollingDate.getTime() + delayMs);
        rollingDate = due;
      }

      // personalised_steps is keyed by stable step ID (matches the firer's writer);
      // the legacy step_order keys are read as a fallback for pre-migration data.
      const personalised = enrollment.personalised_steps?.[step.id]
        || enrollment.personalised_steps?.[String(step.id)]
        || enrollment.personalised_steps?.[step.step_order]
        || enrollment.personalised_steps?.[String(step.step_order)];

      return {
        step_order:        step.step_order,
        step_id:           step.id,
        channel:           step.channel,
        delay_days:        step.delay_days,
        delay_hours:       step.delay_hours ?? 0,
        task_note:         step.task_note || null,
        subject_template:  personalised?.subject || step.subject_template || null,
        body_template:     personalised?.body    || step.body_template    || null,
        log_id:            null,
        status:            enrollment.status === 'active' ? 'pending' : 'skipped',
        fired_at:          null,
        scheduled_send_at: due || null,
        subject:           null,
        body:              null,
        error_message:     null,
        is_future:         true,
        is_personalised:   !!personalised,
        inbound:           [],
      };
    });

    // `logs` keeps its existing shape; `inbound` on each entry and
    // `inbound_unanchored` are additive. Nothing that reads this today breaks.
    res.json({ enrollment, logs: timeline, inbound_unanchored: inboundUnanchored });
  } catch (err) {
    console.error('enrollment GET /:id', err);
    res.status(500).json({ error: { message: 'Failed to load enrollment' } });
  }
});

// POST /api/sequences/enrollments/:enrollId/stop
router.post('/enrollments/:enrollId/stop', async (req, res) => {
  const { reason = 'manual' } = req.body;
  try {
    const { rows } = await pool.query(
      `UPDATE sequence_enrollments
          SET status='stopped', stopped_at=NOW(), stop_reason=$1
        WHERE id=$2 AND org_id=$3 RETURNING *`,
      [reason, req.params.enrollId, req.orgId]
    );
    if (!rows.length) return res.status(404).json({ error: { message: 'Not found' } });
    // Cancel any pending auto-send rows so nothing fires after a stop.
    await pool.query(
      `UPDATE sequence_step_logs SET status='skipped'
        WHERE enrollment_id=$1 AND org_id=$2 AND status IN ('scheduled','sending')`,
      [req.params.enrollId, req.orgId]
    );
    res.json({ enrollment: rows[0] });
  } catch (err) {
    console.error('enrollment stop', err);
    res.status(500).json({ error: { message: 'Failed to stop enrollment' } });
  }
});

// POST /api/sequences/enrollments/:enrollId/pause
router.post('/enrollments/:enrollId/pause', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `UPDATE sequence_enrollments SET status='paused'
        WHERE id=$1 AND org_id=$2 AND status='active' RETURNING *`,
      [req.params.enrollId, req.orgId]
    );
    if (!rows.length) return res.status(404).json({ error: { message: 'Not found or not active' } });
    // Cancel pending auto-send rows while paused so the queue doesn't show a
    // send that won't happen. Resume re-stamps next_step_due and the firer
    // top-up re-materializes a fresh scheduled row.
    await pool.query(
      `UPDATE sequence_step_logs SET status='skipped'
        WHERE enrollment_id=$1 AND org_id=$2 AND status IN ('scheduled','sending')`,
      [req.params.enrollId, req.orgId]
    );
    res.json({ enrollment: rows[0] });
  } catch (err) {
    res.status(500).json({ error: { message: 'Failed to pause' } });
  }
});

// POST /api/sequences/enrollments/:enrollId/resume
router.post('/enrollments/:enrollId/resume', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `UPDATE sequence_enrollments SET status='active', next_step_due=NOW()
        WHERE id=$1 AND org_id=$2 AND status='paused' RETURNING *`,
      [req.params.enrollId, req.orgId]
    );
    if (!rows.length) return res.status(404).json({ error: { message: 'Not found or not paused' } });
    res.json({ enrollment: rows[0] });
  } catch (err) {
    res.status(500).json({ error: { message: 'Failed to resume' } });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// DRAFT ROUTES
// ─────────────────────────────────────────────────────────────────────────────

// ── GET /api/sequences/drafts  (?prospectId=X)
// List all draft step logs for the current user.
// Returns everything the UI needs to render + send the email.
router.get('/drafts', async (req, res) => {
  const { prospectId, search } = req.query;
  try {
    // Sender resolution mirrors SequenceStepFirer.resolveSender():
    //   1. If prospect.client_id is set, prefer a client-owned sender.
    //   2. Otherwise fall back to the rep's personal sender (client_id IS NULL).
    //
    // Source-of-truth for rendering: ss.channel (the CURRENT sequence step),
    // NOT ssl.channel (the draft-time snapshot). We return both so the UI
    // can detect drift (rep edited the sequence after draft was created).
    //
    // ownerType is derived in SQL (client vs user priority) rather than
    // read from a column.
    let query = `
      SELECT
        ssl.id, ssl.enrollment_id, ssl.subject, ssl.body,
        ssl.scheduled_send_at, ssl.status,
        ssl.channel        AS draft_channel,
        ssl.personalize_sources,
        ss.step_order,
        ss.channel         AS step_channel,
        -- A/B (2026_46): "sequence default" MUST be the enrollment's ARM copy,
        -- not the base step. The UI offers these as a one-click revert; serving
        -- base copy to an arm-B prospect would silently move them across arms.
        -- COALESCE + NULLIF: a blank arm field falls back to the base step, so
        -- an arm may vary the subject alone and inherit the body.
        COALESCE(NULLIF(sv.subject_template, ''), ss.subject_template) AS step_subject_template,
        COALESCE(NULLIF(sv.body_template, ''),    ss.body_template)    AS step_body_template,
        se.sequence_id, se.enrolled_by, se.variant_key, se.experiment_id,
        s.name AS sequence_name,
        p.id AS prospect_id, p.first_name, p.last_name,
        p.email AS prospect_email, p.company_name, p.linkedin_url,
        p.title AS prospect_title, p.company_industry, p.company_domain,
        p.client_id AS prospect_client_id,
        psa.id                 AS sender_id,
        psa.email              AS sender_email,
        psa.provider           AS sender_provider,
        psa.label              AS sender_label,
        psa.display_name       AS sender_display_name,
        psa.signature          AS sender_signature,
        psa.linkedin_signature AS sender_linkedin_signature,
        psa.owner_type         AS sender_owner_type
      FROM sequence_step_logs ssl
      JOIN sequence_enrollments se ON se.id  = ssl.enrollment_id
      JOIN sequences s             ON s.id   = se.sequence_id
      JOIN sequence_steps ss       ON ss.id  = ssl.sequence_step_id
      JOIN prospects p             ON p.id   = ssl.prospect_id
      -- A/B (2026_47): resolve the enrollment's arm copy on the UNIQUE triple
      -- (experiment_id, sequence_step_id, variant_key). This powers the UI's
      -- one-click "revert to sequence default" — serving BASE copy to an arm-B
      -- prospect would silently move them across arms mid-test. Misses entirely
      -- when se.variant_key IS NULL, so non-test enrollments read as before.
      LEFT JOIN sequence_step_variants sv
             ON sv.experiment_id    = se.experiment_id
            AND sv.sequence_step_id = ss.id
            AND sv.variant_key      = se.variant_key
      LEFT JOIN LATERAL (
        SELECT id, email, provider, label, display_name,
               signature, linkedin_signature, owner_type
        FROM (
          -- Client sender (preferred when prospect belongs to a client).
          -- Dormant: agency module not in use, so this branch returns zero rows.
          SELECT id, email, provider, label, display_name,
                 signature, linkedin_signature,
                 'client'::text AS owner_type,
                 1              AS priority,
                 last_reset_at, emails_sent_today, last_sent_at
            FROM prospecting_sender_accounts
           WHERE org_id     = ssl.org_id
             AND client_id IS NOT NULL
             AND client_id  = p.client_id
             AND is_active  = true

          UNION ALL

          -- Rep personal sender (the only branch that matches in practice).
          SELECT id, email, provider, label, display_name,
                 signature, linkedin_signature,
                 'user'::text AS owner_type,
                 2            AS priority,
                 last_reset_at, emails_sent_today, last_sent_at
            FROM prospecting_sender_accounts
           WHERE org_id     = ssl.org_id
             AND user_id    = se.enrolled_by
             AND client_id IS NULL
             AND is_active  = true
        ) candidates
        ORDER BY
          priority ASC,
          (CASE WHEN last_reset_at < CURRENT_DATE THEN 0 ELSE emails_sent_today END) ASC,
          last_sent_at ASC NULLS FIRST
        LIMIT 1
      ) psa ON true
      WHERE ssl.org_id = $1
        AND ssl.status = 'draft'
        AND se.enrolled_by = $2
    `;
    const params = [req.orgId, req.user.userId];
    if (prospectId) {
      params.push(parseInt(prospectId));
      query += ` AND ssl.prospect_id = $${params.length}`;
    }
    // Prospect-name search filter (name OR email OR company), mirroring the
    // canonical /prospects predicate. ANDed so it only narrows the draft list.
    if (search != null && String(search).trim() !== '') {
      params.push(`%${String(search).toLowerCase()}%`);
      query += ` AND (
        LOWER(p.first_name || ' ' || p.last_name) LIKE $${params.length}
        OR LOWER(p.email) LIKE $${params.length}
        OR LOWER(p.company_name) LIKE $${params.length}
      )`;
    }
    query += ' ORDER BY ssl.scheduled_send_at ASC';

    const { rows } = await pool.query(query, params);

    const drafts = rows.map(r => {
      // Source of truth = current sequence step channel.
      // draftChannel is the snapshot at creation time; exposed so the UI
      // can show a hint when they disagree (rep edited the sequence).
      const channel      = r.step_channel;       // live step channel
      const draftChannel = r.draft_channel;      // snapshot
      const channelDrift = channel !== draftChannel;

      // Subject can be empty on LinkedIn drafts — if the step is now email
      // and the draft was composed as LinkedIn, fall back to the step
      // template so the email has at least something in the subject line.
      const subject = r.subject || (channelDrift && channel === 'email' ? (r.step_subject_template || '') : '');

      // Rendered "sequence default" for this step — exactly what the firer
      // would send if the enrollment had no personalised content (its
      // `personalised ?? renderTemplate(template)` fallback). Surfaced so the
      // rep can compare the AI draft against the default and revert with one
      // click (the UI PATCHes the draft with these values). Uses the same
      // renderPreviewTemplate the /preview endpoint uses, with the firer's
      // account→prospect COALESCE approximated by the prospect's company_*.
      const templateVars = {
        first_name:       r.first_name,
        last_name:        r.last_name,
        title:            r.prospect_title,
        company_name:     r.company_name,
        company_industry: r.company_industry,
        company_domain:   r.company_domain,
      };
      const sequenceDefault = {
        subject: channel === 'email' ? renderPreviewTemplate(r.step_subject_template, templateVars) : '',
        body:    renderPreviewTemplate(r.step_body_template, templateVars),
      };

      return {
        id:              r.id,
        enrollmentId:    r.enrollment_id,
        sequenceId:      r.sequence_id,
        sequenceName:    r.sequence_name,
        stepOrder:       r.step_order,
        channel,                 // live step channel — render by this
        draftChannel,            // snapshot at creation — for drift hint
        channelDrift,            // true if the sequence was edited after drafting
        subject,
        body:            r.body || '',
        scheduledSendAt: r.scheduled_send_at,
        isOverdue:       new Date(r.scheduled_send_at) < new Date(),
        // Send Now is only valid for current-email steps with a prospect email.
        canSendNow:      channel === 'email' && !!r.prospect_email,
        prospect: {
          id:          r.prospect_id,
          firstName:   r.first_name,
          lastName:    r.last_name,
          email:       r.prospect_email,
          companyName: r.company_name,
          linkedinUrl: r.linkedin_url || null,
        },
        suggestedSender: r.sender_id ? {
          id:                r.sender_id,
          email:             r.sender_email,
          provider:          r.sender_provider,
          label:             r.sender_label,
          displayName:       r.sender_display_name,
          signature:         r.sender_signature,
          linkedinSignature: r.sender_linkedin_signature,
          ownerType:         r.sender_owner_type, // 'client' | 'user'
        } : null,
        // Phase 3: provenance for the AI's LinkedIn data sources, if any.
        // Null when the step had no personalize config or no profile data.
        personalizeSources: r.personalize_sources || null,
        // Rendered step template — the non-AI fallback the firer would send.
        // Null only when the step has no templates at all.
        sequenceDefault: (sequenceDefault.subject || sequenceDefault.body) ? sequenceDefault : null,
      };
    });

    res.json({ drafts });
  } catch (err) {
    console.error('GET /sequences/drafts', err);
    res.status(500).json({ error: { message: 'Failed to load drafts' } });
  }
});

// ── PATCH /api/sequences/drafts/:logId
// Rep edits subject, body, and/or channel before sending.
// channel is allowed when correcting a draft whose step was changed after creation
// (e.g. linkedin -> email). Only 'email' is a valid target channel for sending.
router.patch('/drafts/:logId', async (req, res) => {
  const { subject, body, channel } = req.body;
  const ALLOWED_CHANNELS = ['email', 'linkedin', 'call', 'task'];
  if (channel !== undefined && !ALLOWED_CHANNELS.includes(channel)) {
    return res.status(400).json({ error: { message: `Invalid channel: ${channel}` } });
  }
  try {
    const { rows } = await pool.query(
      `UPDATE sequence_step_logs
          SET subject = COALESCE($1, subject),
              body    = COALESCE($2, body),
              channel = COALESCE($3, channel)
        WHERE id = $4
          AND org_id = $5
          AND status = 'draft'
        RETURNING *`,
      [subject ?? null, body ?? null, channel ?? null, req.params.logId, req.orgId]
    );
    if (!rows.length) return res.status(404).json({ error: { message: 'Draft not found or already sent' } });
    res.json({ draft: rows[0] });
  } catch (err) {
    console.error('PATCH /sequences/drafts/:logId', err);
    res.status(500).json({ error: { message: 'Failed to update draft' } });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// SCHEDULED AUTO-SEND ROUTES (Level 2)
//   GET    /scheduled                 list pending auto-send rows (+ signature preview)
//   PATCH  /scheduled/:logId          edit subject/body (timer is NEVER changed)
//   POST   /scheduled/:logId/cancel   cancel → full unenroll (same as /undo)
// ─────────────────────────────────────────────────────────────────────────────

// ── GET /api/sequences/scheduled  (?prospectId=X&search=Y)
// Lists pending auto-send rows (status 'scheduled' or in-flight 'sending') for
// the current rep. Resolves the LIKELY sender at read time to preview the
// signature + From that will be applied AT SEND (the stored body is plain and
// signature-free). For single-sender orgs the preview is exact; for multi-sender
// orgs it is best-effort, since the actual account is chosen by capacity at send.
router.get('/scheduled', async (req, res) => {
  const { prospectId, search } = req.query;
  try {
    let query = `
      SELECT
        ssl.id, ssl.enrollment_id, ssl.subject, ssl.body,
        ssl.scheduled_send_at, ssl.status, ssl.personalize_sources,
        ss.step_order,
        se.sequence_id, se.enrolled_by,
        s.name AS sequence_name,
        p.id AS prospect_id, p.first_name, p.last_name,
        p.email AS prospect_email, p.company_name, p.client_id AS prospect_client_id,
        psa.email              AS sender_email,
        psa.display_name       AS sender_display_name,
        psa.signature          AS sender_signature
      FROM sequence_step_logs ssl
      JOIN sequence_enrollments se ON se.id  = ssl.enrollment_id
      JOIN sequences s             ON s.id   = se.sequence_id
      JOIN sequence_steps ss       ON ss.id  = ssl.sequence_step_id
      JOIN prospects p             ON p.id   = ssl.prospect_id
      LEFT JOIN LATERAL (
        SELECT email, display_name, signature
        FROM (
          SELECT email, display_name, signature, 1 AS priority,
                 last_reset_at, emails_sent_today, last_sent_at
            FROM prospecting_sender_accounts
           WHERE org_id = ssl.org_id AND client_id IS NOT NULL
             AND client_id = p.client_id AND is_active = true
          UNION ALL
          SELECT email, display_name, signature, 2 AS priority,
                 last_reset_at, emails_sent_today, last_sent_at
            FROM prospecting_sender_accounts
           WHERE org_id = ssl.org_id AND user_id = se.enrolled_by
             AND client_id IS NULL AND is_active = true
        ) candidates
        ORDER BY priority ASC,
          (CASE WHEN last_reset_at < CURRENT_DATE THEN 0 ELSE emails_sent_today END) ASC,
          last_sent_at ASC NULLS FIRST
        LIMIT 1
      ) psa ON true
      WHERE ssl.org_id = $1
        AND ssl.status IN ('scheduled','sending')
        AND se.enrolled_by = $2
    `;
    const params = [req.orgId, req.user.userId];
    if (prospectId) {
      params.push(parseInt(prospectId));
      query += ` AND ssl.prospect_id = $${params.length}`;
    }
    if (search != null && String(search).trim() !== '') {
      params.push(`%${String(search).toLowerCase()}%`);
      query += ` AND (
        LOWER(p.first_name || ' ' || p.last_name) LIKE $${params.length}
        OR LOWER(p.email) LIKE $${params.length}
        OR LOWER(p.company_name) LIKE $${params.length}
      )`;
    }
    query += ' ORDER BY ssl.scheduled_send_at ASC';

    const { rows } = await pool.query(query, params);

    const scheduled = rows.map(r => ({
      id:              r.id,
      enrollmentId:    r.enrollment_id,
      sequenceId:      r.sequence_id,
      sequenceName:    r.sequence_name,
      stepOrder:       r.step_order,
      channel:         'email',
      status:          r.status,            // 'scheduled' | 'sending'
      canEdit:         r.status === 'scheduled', // in-flight rows are locked
      canSkip:         r.status === 'scheduled', // skip just this step, keep the sequence
      subject:         r.subject || '',
      body:            r.body || '',
      scheduledSendAt: r.scheduled_send_at,
      isOverdue:       r.scheduled_send_at ? new Date(r.scheduled_send_at) < new Date() : false,
      prospect: {
        id:          r.prospect_id,
        firstName:   r.first_name,
        lastName:    r.last_name,
        email:       r.prospect_email,
        companyName: r.company_name,
      },
      // Applied at send time — shown so the rep sees the full email that will go out.
      fromPreview:      r.sender_email ? { email: r.sender_email, displayName: r.sender_display_name } : null,
      signaturePreview: r.sender_signature || null,
      signatureAppliedOnSend: true,
      personalizeSources: r.personalize_sources || null,
    }));

    res.json({ scheduled });
  } catch (err) {
    console.error('GET /sequences/scheduled', err);
    res.status(500).json({ error: { message: 'Failed to load scheduled sends' } });
  }
});

// ── PATCH /api/sequences/scheduled/:logId
// Edits subject/body of a pending scheduled send. Per design, this NEVER changes
// scheduled_send_at — the email still goes out at its originally scheduled time.
// Only 'scheduled' rows are editable; once the firer claims a row ('sending') or
// it has sent, edits are rejected.
router.patch('/scheduled/:logId', async (req, res) => {
  const { subject, body } = req.body;
  try {
    const { rows } = await pool.query(
      `UPDATE sequence_step_logs
          SET subject = COALESCE($1, subject),
              body    = COALESCE($2, body)
        WHERE id = $3
          AND org_id = $4
          AND status = 'scheduled'
        RETURNING id, subject, body, scheduled_send_at, status`,
      [subject ?? null, body ?? null, req.params.logId, req.orgId]
    );
    if (!rows.length) {
      return res.status(409).json({ error: { message: 'Not editable — already sending or sent.' } });
    }
    res.json({ scheduled: rows[0] });
  } catch (err) {
    console.error('PATCH /sequences/scheduled/:logId', err);
    res.status(500).json({ error: { message: 'Failed to update scheduled send' } });
  }
});

// ── POST /api/sequences/scheduled/:logId/cancel
// Rep cancels a scheduled send. Routes through the SAME unenroll process as a
// manual draft undo: stop the enrollment, discard pending rows (draft+scheduled),
// revert the prospect stage, and write an audit row. (To cancel just one step
// while keeping the sequence running, a separate skip endpoint would be needed.)
router.post('/scheduled/:logId/cancel', async (req, res) => {
  const client = await pool.connect();
  try {
    const lookup = await client.query(
      `SELECT enrollment_id
         FROM sequence_step_logs
        WHERE id = $1 AND org_id = $2 AND status IN ('scheduled','sending')`,
      [req.params.logId, req.orgId]
    );
    if (!lookup.rows.length) {
      return res.status(404).json({ error: { message: 'Scheduled send not found or already sent' } });
    }
    const enrollmentId = lookup.rows[0].enrollment_id;

    await client.query('BEGIN');
    const result = await undoEnrollmentTx(client, req.orgId, req.user.userId, enrollmentId);
    if (result.notFound) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: { message: 'Enrollment not found' } });
    }
    await client.query('COMMIT');
    res.json(result);
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('POST /sequences/scheduled/:logId/cancel', err);
    res.status(500).json({ error: { message: 'Cancel failed: ' + err.message } });
  } finally {
    client.release();
  }
});

// ── POST /api/sequences/scheduled/:logId/skip
// Skip JUST this scheduled email and let the sequence continue — discards the
// pending row and advances the enrollment to the next step (or completes it if
// this was the last step). Mirrors the "discard a draft and advance" behavior
// (DELETE /drafts/:logId) so the two paths can't drift.
//
// Race-safe vs the firer: the skip is a CONDITIONAL update on status='scheduled'.
// If the firer has already claimed the row (status='sending') or it has sent,
// the update matches 0 rows and we return 409 — we never skip an email that is
// already on its way out, and we never double-advance (the firer's claim is
// likewise conditional on status='scheduled').
router.post('/scheduled/:logId/skip', async (req, res) => {
  const client = await pool.connect();
  try {
    // Load for 404 + ownership + step context (status checked again, inside txn).
    const rowRes = await client.query(
      `SELECT ssl.id, ssl.enrollment_id, ssl.prospect_id, ssl.sequence_step_id,
              ss.step_order, se.enrolled_by, se.current_step, se.status AS enrollment_status,
              s.id AS seq_id, s.name AS sequence_name
         FROM sequence_step_logs ssl
         JOIN sequence_steps ss       ON ss.id = ssl.sequence_step_id
         JOIN sequence_enrollments se ON se.id = ssl.enrollment_id
         JOIN sequences s             ON s.id  = se.sequence_id
        WHERE ssl.id = $1 AND ssl.org_id = $2 AND ssl.status = 'scheduled'`,
      [req.params.logId, req.orgId]
    );
    if (!rowRes.rows.length) {
      return res.status(404).json({ error: { message: 'Scheduled send not found, already sending, or already sent' } });
    }
    const row = rowRes.rows[0];
    if (row.enrolled_by !== req.user.userId) {
      return res.status(403).json({ error: { message: 'Only the enrolling rep can skip this step' } });
    }

    await client.query('BEGIN');

    // Conditional skip — loses gracefully to a concurrent firer claim.
    const skipRes = await client.query(
      `UPDATE sequence_step_logs SET status='skipped', fired_at=NOW()
        WHERE id=$1 AND org_id=$2 AND status='scheduled'
        RETURNING id`,
      [row.id, req.orgId]
    );
    if (skipRes.rowCount === 0) {
      await client.query('ROLLBACK');
      return res.status(409).json({ error: { message: 'This email is already sending or sent — too late to skip.' } });
    }

    // Lock the enrollment and re-read authoritative state before advancing.
    const eRes = await client.query(
      `SELECT current_step, status, sequence_id
         FROM sequence_enrollments
        WHERE id=$1 AND org_id=$2 FOR UPDATE`,
      [row.enrollment_id, req.orgId]
    );
    const enrollment = eRes.rows[0];

    let advancedToStep = null;
    let completed      = false;

    // Only advance an ACTIVE enrollment whose current step is the one we skipped.
    // (If it isn't active, the row is still correctly skipped; we just don't move
    // the pointer — resume handles re-materializing the right step.)
    if (enrollment && enrollment.status === 'active' && enrollment.current_step === row.current_step) {
      // Identity-cursor advance (parity with the firer). Re-read the identity
      // fields so applyAdvance moves current_step_id/channel too, not just the ordinal.
      const eFull = await client.query(
        `SELECT id, sequence_id, current_step, current_step_id, current_step_channel, steps_snapshot
           FROM sequence_enrollments WHERE id=$1`,
        [row.enrollment_id]
      );
      const settings = await SendingSchedule.resolveSettings({ orgId: req.orgId, campaignId: null });
      const adv = await EnrollmentStepResolver.applyAdvance(client, eFull.rows[0], {
        computeDue: (s) => SendingSchedule.nextStepDue(s, settings),
      });
      if (adv.completed) { completed = true; }
      else { advancedToStep = adv.step.step_order; }
    }

    await client.query(
      `INSERT INTO prospecting_activities
         (org_id, prospect_id, user_id, activity_type, description, metadata)
       VALUES ($1, $2, $3, 'sequence_step_skipped', $4, $5)`,
      [req.orgId, row.prospect_id, req.user.userId,
       `Scheduled send skipped — ${row.sequence_name} step ${row.step_order}` +
         (completed ? ' (sequence completed)' : advancedToStep ? ` (advanced to step ${advancedToStep})` : ''),
       JSON.stringify({
         enrollmentId: row.enrollment_id, logId: row.id, stepOrder: row.step_order,
         advancedToStep, completed,
       })]
    );

    await client.query('COMMIT');
    res.json({ ok: true, enrollmentId: row.enrollment_id, advancedToStep, completed });
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    console.error('POST /sequences/scheduled/:logId/skip', err);
    res.status(500).json({ error: { message: 'Skip failed: ' + err.message } });
  } finally {
    client.release();
  }
});

// ── POST /api/sequences/drafts/:logId/send
// Rep approves and sends the draft email via their prospecting sender account.
// Mirrors the logic in POST /prospecting-actions/outreach-send.
router.post('/drafts/:logId/send', async (req, res) => {
  const { senderAccountId } = req.body; // optional — omit for auto-rotation
  const client = await pool.connect();
  try {
    // ── 1. Load draft + enrollment + prospect ──────────────────────────────
    // ss.channel is the CURRENT step channel (source of truth).
    // ssl.channel is the snapshot at draft creation — kept for diagnostics.
    const draftRes = await client.query(
      `SELECT ssl.*,
              ssl.channel AS draft_channel,
              ss.step_order,
              ss.channel  AS step_channel,
              ss.step_intent,
              se.enrolled_by, se.sequence_id,
              se.current_step, se.org_id AS enroll_org_id,
              s.name AS sequence_name
         FROM sequence_step_logs ssl
         JOIN sequence_steps ss       ON ss.id  = ssl.sequence_step_id
         JOIN sequence_enrollments se ON se.id  = ssl.enrollment_id
         JOIN sequences s             ON s.id   = se.sequence_id
        WHERE ssl.id = $1 AND ssl.org_id = $2 AND ssl.status = 'draft'`,
      [req.params.logId, req.orgId]
    );
    if (!draftRes.rows.length) {
      return res.status(404).json({ error: { message: 'Draft not found or already sent' } });
    }
    const draft = draftRes.rows[0];

    // Guard: only the rep who enrolled can send
    if (draft.enrolled_by !== req.user.userId) {
      return res.status(403).json({ error: { message: 'Only the enrolling rep can send this draft' } });
    }

    const prospectRes = await client.query(
      `SELECT p.*, a.name AS account_name
         FROM prospects p
    LEFT JOIN accounts a ON a.id = p.account_id
        WHERE p.id = $1 AND p.org_id = $2`,
      [draft.prospect_id, req.orgId]
    );
    if (!prospectRes.rows.length) {
      return res.status(404).json({ error: { message: 'Prospect not found' } });
    }
    const prospect = prospectRes.rows[0];

    // ── Channel guard — send only if the CURRENT step is email ──────────────
    // Source of truth is ss.channel (the live sequence step), not ssl.channel.
    // Two drift scenarios are possible and handled here:
    //   (a) Draft was linkedin, step is now email → allow send (rule #3).
    //   (b) Draft was email, step is now linkedin → block, rep must Mark Done.
    // A non-email send would silently do nothing in the provider branch
    // but still mark the log 'sent' and advance the enrollment — a ghost send.
    if (draft.step_channel !== 'email') {
      return res.status(400).json({
        error: {
          message: `This step is now a ${draft.step_channel} step — use "Mark as Done" once you have completed the action on ${draft.step_channel === 'linkedin' ? 'LinkedIn' : 'the appropriate channel'}.`,
          code: 'WRONG_CHANNEL',
        },
      });
    }

    if (!prospect.email) {
      return res.status(400).json({ error: { message: 'Prospect has no email address' } });
    }

    // ── 2. Select sender account ───────────────────────────────────────────
    // Phase 3 (2026_53): mirrors SequenceStepFirer — a client prospect's
    // manual send prefers the CLIENT's sender; previously both branches were
    // hard-scoped to the rep's personal senders, so every manual send for a
    // client prospect went out from the rep's own mailbox regardless of the
    // draft-time signature. With require_client_sender set on the client and
    // no active client sender, the send is blocked with an actionable 400
    // instead of silently using the wrong identity.
    const prospectClientId = prospect.client_id || null;
    let requireClientSender = false;
    if (prospectClientId) {
      const polRes = await client.query(
        `SELECT require_client_sender FROM clients WHERE id = $1 AND org_id = $2`,
        [prospectClientId, req.orgId]
      );
      requireClientSender = polRes.rows[0]?.require_client_sender === true;
    }

    let sender;
    if (senderAccountId) {
      // Explicit pick: the rep's own personal sender, OR a sender owned by
      // THIS prospect's client. Never another client's sender.
      const r = await client.query(
        `SELECT * FROM prospecting_sender_accounts
          WHERE id=$1 AND org_id=$2 AND is_active=true
            AND ( (user_id=$3 AND client_id IS NULL)
               OR ($4::int IS NOT NULL AND client_id=$4) )`,
        [senderAccountId, req.orgId, req.user.userId, prospectClientId]
      );
      if (!r.rows.length) return res.status(404).json({ error: { message: 'Sender account not found or inactive' } });
      sender = r.rows[0];
      if (requireClientSender && sender.client_id == null) {
        return res.status(400).json({
          error: {
            message: 'This client requires its own sender mailbox — pick one of the client\'s connected accounts (Agency → client → Senders).',
            code: 'CLIENT_SENDER_REQUIRED',
          }
        });
      }
    } else {
      // Auto-rotation: client senders first (least-sent), then — unless the
      // client forbids it — the rep's personal senders. Same ordering as the
      // firer's resolveSender().
      let r = { rows: [] };
      if (prospectClientId) {
        r = await client.query(
          `SELECT * FROM prospecting_sender_accounts
            WHERE org_id=$1 AND client_id=$2 AND is_active=true
            ORDER BY
              (CASE WHEN last_reset_at < CURRENT_DATE THEN 0 ELSE emails_sent_today END) ASC,
              last_sent_at ASC NULLS FIRST
            LIMIT 1`,
          [req.orgId, prospectClientId]
        );
        if (!r.rows.length && requireClientSender) {
          return res.status(400).json({
            error: {
              message: 'This client requires its own sender mailbox and none is connected — connect Gmail or Outlook for the client in Agency → client → Senders (or disable "Require client mailbox").',
              code: 'CLIENT_SENDER_REQUIRED',
            }
          });
        }
      }
      if (!r.rows.length) {
        r = await client.query(
          `SELECT * FROM prospecting_sender_accounts
            WHERE org_id=$1 AND user_id=$2 AND client_id IS NULL AND is_active=true
            ORDER BY
              (CASE WHEN last_reset_at < CURRENT_DATE THEN 0 ELSE emails_sent_today END) ASC,
              last_sent_at ASC NULLS FIRST
            LIMIT 1`,
          [req.orgId, req.user.userId]
        );
      }
      if (!r.rows.length) {
        return res.status(400).json({
          error: { message: 'No active sender accounts. Connect a Gmail or Outlook account in Settings → Outreach.', code: 'NO_SENDER_ACCOUNTS' }
        });
      }
      sender = r.rows[0];
    }

    // ── 3. Reset daily counter if new day ─────────────────────────────────
    if (new Date(sender.last_reset_at).toDateString() !== new Date().toDateString()) {
      await client.query(
        `UPDATE prospecting_sender_accounts
            SET emails_sent_today=0, last_reset_at=CURRENT_DATE, updated_at=CURRENT_TIMESTAMP
          WHERE id=$1`,
        [sender.id]
      );
      sender.emails_sent_today = 0;
    }

    // ── 4. Enforce daily limit ─────────────────────────────────────────────
    const limitsRes = await client.query(
      `SELECT config FROM org_integrations
        WHERE org_id=$1 AND integration_type='prospecting_email'`,
      [req.orgId]
    );
    const orgConfig = limitsRes.rows[0]?.config || {};
    const dailyLimit = Math.min(sender.daily_limit ?? (orgConfig.defaultDailyLimit || 50), orgConfig.dailyLimitCeiling || 100);

    if (sender.emails_sent_today >= dailyLimit) {
      return res.status(429).json({
        error: { message: `Daily send limit reached for ${sender.email} (${dailyLimit}/day). Resets tomorrow.`, code: 'DAILY_LIMIT_REACHED' }
      });
    }

    // ── 5. Ensure signature is present (safety-net), then convert to HTML ────
    // bodyToSend stays as plain text until the very last moment so the
    // DB record (step 7) stores the plain-text version. htmlBody is what
    // actually goes over the wire to Gmail / Outlook.
    let bodyToSend = draft.body || '';
    if (sender.signature) {
      const trimmedSig = sender.signature.trim();
      if (trimmedSig && !bodyToSend.includes(trimmedSig)) {
        bodyToSend = bodyToSend + `\n\n${trimmedSig}`;
      }
    }
    const htmlBody = plainTextToHtml(bodyToSend);

    // ── 6. Send via Gmail or Outlook ───────────────────────────────────────
    // IMPORTANT: errors here are NOT swallowed. If the send fails (expired token,
    // network error, etc.) we return a 502 immediately so:
    //   a) The draft stays in the queue — the rep can retry after reconnecting
    //   b) We never write a ghost 'sent' record to the DB
    // The frontend catches the 502 and shows the error on the draft card.
    try {
      if (sender.provider === 'gmail') {
        await sendGmailEmail(req.user.userId, {
          to:           prospect.email,
          subject:      draft.subject,
          body:         htmlBody,
          isHtml:       true,
          senderEmail:  sender.email,
          accessToken:  sender.access_token,
          refreshToken: sender.refresh_token,
        });
      } else if (sender.provider === 'outlook') {
        await sendOutlookEmail(req.user.userId, {
          to:           prospect.email,
          subject:      draft.subject,
          body:         htmlBody,
          isHtml:       true,
          senderEmail:  sender.email,
          accessToken:  sender.access_token,
          refreshToken: sender.refresh_token,
        });
      }
    } catch (err) {
      console.error(`❌ Draft send failed for log ${req.params.logId} → ${prospect.email}:`, err.message);
      // Surface token expiry as a clear actionable message
      // Only flag as token error on confirmed invalid_grant — not generic 401/unauthorized
      // which can come from other causes and would show a false "needs to be reconnected" message.
      const isTokenError = /invalid_grant|needs to be reconnected/i.test(err.message);
      const userMessage = isTokenError
        ? `Sending account ${sender.email} needs to be reconnected — go to Settings → Outreach and reconnect it.`
        : `Failed to send email: ${err.message}`;
      return res.status(502).json({ error: { message: userMessage, code: isTokenError ? 'TOKEN_EXPIRED' : 'SEND_FAILED' } });
    }

    const sendError = null; // send succeeded — no error
    await client.query('BEGIN');

    // ── 7. Save email to DB ────────────────────────────────────────────────
    const emailRes = await client.query(
      `INSERT INTO emails
         (org_id, user_id, direction, subject, body,
          to_address, from_address, sent_at, prospect_id, sender_account_id, provider)
       VALUES ($1,$2,'sent',$3,$4,$5,$6,CURRENT_TIMESTAMP,$7,$8,$9)
       RETURNING *`,
      [req.orgId, req.user.userId, draft.subject, bodyToSend,
       prospect.email, sender.email, draft.prospect_id, sender.id, sender.provider]
    );
    const newEmail = emailRes.rows[0];

    // ── 8. Flip draft → sent ───────────────────────────────────────────────
    await client.query(
      `UPDATE sequence_step_logs
          SET status='sent', fired_at=NOW(), email_id=$1, body=$2
        WHERE id=$3`,
      [newEmail.id, bodyToSend, draft.id]
    );

    // ── 9. Update sender counters ──────────────────────────────────────────
    await client.query(
      `UPDATE prospecting_sender_accounts
          SET emails_sent_today=emails_sent_today+1,
              last_sent_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP
        WHERE id=$1`,
      [sender.id]
    );

    // ── 10. Update prospect outreach tracking ──────────────────────────────
    await client.query(
      `UPDATE prospects
          SET outreach_count=outreach_count+1, last_outreach_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP
        WHERE id=$1`,
      [draft.prospect_id]
    );

    // Auto-advance stage on first outreach
    const stageRes = await client.query(`SELECT stage, channel_data FROM prospects WHERE id=$1`, [draft.prospect_id]);
    const currentStage = stageRes.rows[0]?.stage;
    if (['target', 'research'].includes(currentStage)) {
      await client.query(
        `UPDATE prospects SET stage='outreach', stage_changed_at=CURRENT_TIMESTAMP, updated_at=CURRENT_TIMESTAMP WHERE id=$1`,
        [draft.prospect_id]
      );
    }

    // ── Sync LinkedIn channel_data if this is a LinkedIn step ────────────────
    if (draft.channel === 'linkedin') {
      const channelData = stageRes.rows[0]?.channel_data || {};
      const li          = channelData.linkedin || {};
      const STATUS_ORDER = [
        'connection_request_sent', 'connection_accepted',
        'message_sent', 'reply_received', 'meeting_booked',
      ];
      // Intent-aware (was: step_order === 1, which mislabeled a CR at step 2
      // in email-first sequences as a message). See resolveLinkedInLogStatus.
      const liStatus = await resolveLinkedInLogStatus(client, {
        sequenceId:       draft.sequence_id,
        stepId:           draft.sequence_step_id,
        stepIntent:       draft.step_intent || null,
        connectionStatus: li.connection_status || null,
      });
      const currentIdx = STATUS_ORDER.indexOf(li.connection_status || '');
      const newIdx     = STATUS_ORDER.indexOf(liStatus);
      if (newIdx > currentIdx) {
        li.connection_status = liStatus;
      }
      if (liStatus === 'connection_request_sent' && !li.request_sent_at) {
        li.request_sent_at = new Date().toISOString();
      } else if (liStatus === 'message_sent') {
        li.last_message_at = new Date().toISOString();
        li.message_count   = (li.message_count || 0) + 1;
      }
      channelData.linkedin = li;
      await client.query(
        `UPDATE prospects SET channel_data = $1::jsonb, updated_at = CURRENT_TIMESTAMP WHERE id = $2`,
        [JSON.stringify(channelData), draft.prospect_id]
      );
    }

    // ── 11. Advance enrollment to next step ────────────────────────────────
    const enrollRes = await client.query(
      `SELECT se.*, s.id AS seq_id FROM sequence_enrollments se
         JOIN sequences s ON s.id = se.sequence_id
        WHERE se.id=$1`,
      [draft.enrollment_id]
    );
    const enrollment = enrollRes.rows[0];

    if (enrollment) {
      // Identity-cursor advance (parity with the firer). enrollment came from
      // `se.*` so it carries current_step_id / current_step_channel / steps_snapshot.
      const settings = await SendingSchedule.resolveSettings({ orgId: req.orgId, campaignId: null });
      await EnrollmentStepResolver.applyAdvance(client, enrollment, {
        computeDue: (s) => SendingSchedule.nextStepDue(s, settings),
      });
    }

    // ── 12. Mark any linked overdue action completed ───────────────────────
    await client.query(
      `UPDATE prospecting_actions
          SET status='completed', completed_at=CURRENT_TIMESTAMP,
              completed_by=$1, outcome='email_sent', updated_at=CURRENT_TIMESTAMP
        WHERE org_id=$2
          AND source='sequence_draft'
          AND (metadata->>'draftLogId')::int = $3
          AND status != 'completed'`,
      [req.user.userId, req.orgId, draft.id]
    );

    // ── 13. Write activity ─────────────────────────────────────────────────
    await client.query(
      `INSERT INTO prospecting_activities
         (org_id, prospect_id, user_id, activity_type, description, metadata)
       VALUES ($1, $2,$3,'sequence_step_sent',$4,$5)`,
      [req.orgId, 
        draft.prospect_id, req.user.userId,
        `Sequence step ${draft.step_order} sent — ${draft.sequence_name}: ${draft.subject || '(no subject)'}`,
        JSON.stringify({
          enrollmentId: draft.enrollment_id,
          sequenceId:   draft.sequence_id,
          sequenceName: draft.sequence_name,
          stepOrder:    draft.step_order,
          draftLogId:   draft.id,
          emailId:      newEmail.id,
          senderId:     sender.id,
          fromEmail:    sender.email,
          sendError:    sendError || null,
        }),
      ]
    );

    await client.query('COMMIT');

    res.status(201).json({
      ok: true,
      emailSent:   !sendError,
      sendError:   sendError || null,
      emailId:     newEmail.id,
      fromAddress: sender.email,
    });
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    console.error('POST /sequences/drafts/:logId/send', err);
    res.status(500).json({ error: { message: 'Failed to send draft: ' + err.message } });
  } finally {
    client.release();
  }
});

// ── Approve drafts → queue for PACED sending ──────────────────────────────
// Flips email drafts ('draft') to pending 'scheduled' rows so the firer's
// auto-send branch delivers them honoring per-account min-delay cooldown,
// daily limit, and send window (rotating senders). Manual 'Send Now' is
// unchanged — it stays an immediate human override.
//
// Scope mirrors GET /drafts: the rep's own org-scoped email drafts only.
// The NOT EXISTS guard keeps us from violating uq_seq_step_logs_pending if a
// pending row somehow already exists for the step.
async function approveDraftLogs(orgId, userId, logIds, sendAt) {
  const ids = (logIds || []).map(Number).filter(Number.isInteger);
  if (!ids.length) return { approved: 0, skipped: 0, approvedIds: [] };

  // Pre-flight: confirm the rep still has a sender that can actually deliver.
  // Approving only flips drafts → 'scheduled'; the firer sends later. Without
  // this, a dead token lets approval "succeed" and silently fail hours later.
  // assertUserCanSend probes the rep's active senders, marks/notifies any dead
  // ones, and throws { needsReconnect, senders } if NONE can send — which the
  // route handlers turn into a 409 the UI renders as a one-click reconnect.
  await SenderTokenHealth.assertUserCanSend(pool, orgId, userId);

  const upd = await pool.query(
    `UPDATE sequence_step_logs ssl
        SET status            = 'scheduled',
            scheduled_send_at = COALESCE($4::timestamptz, NOW()),
            approved_at       = NOW(),
            approved_by       = $3
       FROM sequence_enrollments se
      WHERE ssl.enrollment_id = se.id
        AND ssl.id         = ANY($1::int[])
        AND ssl.org_id     = $2
        AND se.enrolled_by = $3
        AND ssl.status     = 'draft'
        AND ssl.channel    = 'email'
        AND NOT EXISTS (
              SELECT 1 FROM sequence_step_logs x
               WHERE x.enrollment_id    = ssl.enrollment_id
                 AND x.sequence_step_id = ssl.sequence_step_id
                 AND x.status IN ('scheduled','sending'))
      RETURNING ssl.id`,
    [ids, orgId, userId, sendAt || null]
  );
  const approvedIds = upd.rows.map(r => r.id);

  // Best-effort audit trail.
  if (approvedIds.length) {
    try {
      await pool.query(
        `INSERT INTO prospecting_activities
                     (org_id, prospect_id, user_id, activity_type, description, metadata)
         SELECT ssl.org_id, ssl.prospect_id, $2, 'sequence_draft_approved',
                'Approved & queued for paced send',
                jsonb_build_object('logId', ssl.id, 'enrollmentId', ssl.enrollment_id)
           FROM sequence_step_logs ssl
          WHERE ssl.id = ANY($1::int[])`,
        [approvedIds, userId]
      );
    } catch (e) { console.warn('drafts/approve activity log failed:', e.message); }
  }

  return { approved: approvedIds.length, skipped: ids.length - approvedIds.length, approvedIds };
}

// ── POST /api/sequences/drafts/approve  (bulk)
// Body { logIds: number[], sendAt?: ISO8601 }   (sendAt defaults to now)
router.post('/drafts/approve', async (req, res) => {
  const { logIds, sendAt } = req.body || {};
  if (!Array.isArray(logIds) || logIds.length === 0) {
    return res.status(400).json({ error: { message: 'logIds (non-empty array) required' } });
  }
  try {
    res.json(await approveDraftLogs(req.orgId, req.user.userId, logIds, sendAt));
  } catch (err) {
    if (err && err.needsReconnect) {
      return res.status(409).json({
        error: { message: err.message },
        needs_reconnect: true,
        senders: err.senders || [],
      });
    }
    console.error('POST /sequences/drafts/approve', err);
    res.status(500).json({ error: { message: 'Failed to approve drafts' } });
  }
});

// ── POST /api/sequences/drafts/:logId/approve  (single convenience wrapper)
router.post('/drafts/:logId/approve', async (req, res) => {
  try {
    res.json(await approveDraftLogs(req.orgId, req.user.userId, [req.params.logId], req.body?.sendAt));
  } catch (err) {
    if (err && err.needsReconnect) {
      return res.status(409).json({
        error: { message: err.message },
        needs_reconnect: true,
        senders: err.senders || [],
      });
    }
    console.error('POST /sequences/drafts/:logId/approve', err);
    res.status(500).json({ error: { message: 'Failed to approve draft' } });
  }
});

// ── DELETE /api/sequences/drafts/:logId
// Rep discards a draft — step is consumed and enrollment advances.
// ── POST /api/sequences/drafts/:logId/complete
// Mark a non-email step (LinkedIn, call, task) as completed manually.
// The rep did the action outside the CRM — this logs it as done and
// advances the enrollment to the next step, same as Send Now does for email.
router.post('/drafts/:logId/complete', async (req, res) => {
  const client = await pool.connect();
  try {
    // Load draft + enrollment context
    const draftRes = await client.query(
      `SELECT ssl.*, ss.step_order, ss.channel, ss.step_intent,
              se.enrolled_by, se.current_step,
              se.current_step_id, se.current_step_channel, se.steps_snapshot,
              s.id AS seq_id, s.name AS sequence_name
         FROM sequence_step_logs ssl
         JOIN sequence_steps ss       ON ss.id  = ssl.sequence_step_id
         JOIN sequence_enrollments se ON se.id  = ssl.enrollment_id
         JOIN sequences s             ON s.id   = se.sequence_id
        WHERE ssl.id=$1 AND ssl.org_id=$2 AND ssl.status='draft'`,
      [req.params.logId, req.orgId]
    );
    if (!draftRes.rows.length) {
      return res.status(404).json({ error: { message: 'Draft not found or already actioned' } });
    }
    const draft = draftRes.rows[0];

    if (draft.enrolled_by !== req.user.userId) {
      return res.status(403).json({ error: { message: 'Only the enrolling rep can complete this step' } });
    }

    // ── Channel guard — reject /complete for steps that are now email ─────
    // If the step is currently email, the rep should use Send Now so an
    // actual email goes out. Letting /complete through here would silently
    // close the step without sending anything.
    if (draft.channel === 'email') {
      return res.status(400).json({
        error: {
          message: 'This step is now an email step — use "Send Now" to dispatch it.',
          code: 'WRONG_CHANNEL',
        },
      });
    }

    await client.query('BEGIN');

    // ── 0. Reconcile any sibling rows for this (enrollment, step) ─────────
    // Moving this draft to 'completed' enters the uq_seq_step_logs_fired
    // predicate. If a sibling is already in that predicate the UPDATE would
    // raise "duplicate key ... uq_seq_step_logs_fired". For a MANUAL connection
    // request only 'completed'/'sent'/'replied' proves the request actually went
    // out; 'scheduled'/'sending' is queued-but-unconfirmed. Handle the two very
    // differently so we never double-contact and never drop a contact:
    const siblings = await client.query(
      `SELECT id, status FROM sequence_step_logs
        WHERE enrollment_id=$1 AND sequence_step_id=$2 AND id<>$3
          AND status IN ('scheduled','sending','sent','completed','replied')`,
      [draft.enrollment_id, draft.sequence_step_id, draft.id]
    );
    const reached = siblings.rows.some(r => ['completed','sent','replied'].includes(r.status));

    if (reached) {
      // The contact was already reached by an earlier row. This draft is a
      // redundant duplicate — completing it would be a SECOND touch. Quarantine
      // it, advance the enrollment, and report it as already done.
      await client.query(
        `UPDATE sequence_step_logs SET status='superseded_duplicate', fired_at=NOW() WHERE id=$1`,
        [draft.id]
      );
      const settings = await SendingSchedule.resolveSettings({ orgId: req.orgId, campaignId: null });
      await EnrollmentStepResolver.applyAdvance(client, {
        id:                   draft.enrollment_id,
        sequence_id:          draft.seq_id,
        current_step:         draft.current_step,
        current_step_id:      draft.current_step_id,
        current_step_channel: draft.current_step_channel,
        steps_snapshot:       draft.steps_snapshot,
      }, {
        computeDue: (s) => SendingSchedule.nextStepDue(s, settings),
      });
      await client.query(
        `UPDATE prospecting_actions
            SET status='completed', completed_at=CURRENT_TIMESTAMP,
                completed_by=$1, outcome='already_completed', updated_at=CURRENT_TIMESTAMP
          WHERE org_id=$2 AND source='sequence_draft'
            AND (metadata->>'draftLogId')::int=$3
            AND status != 'completed'`,
        [req.user.userId, req.orgId, draft.id]
      );
      await client.query('COMMIT');
      return res.json({ ok: true, alreadyCompleted: true });
    }

    // Only queued-but-unconfirmed sibling(s) exist. The rep did the real manual
    // send just now, so THEIR completion is the record of contact. Retire the
    // stale queued row(s) (they'd otherwise double-send via the extension), then
    // let this draft complete normally below — the contact is recorded once.
    if (siblings.rows.length) {
      await client.query(
        `UPDATE sequence_step_logs SET status='superseded_duplicate', fired_at=NOW()
          WHERE id = ANY($1::int[])`,
        [siblings.rows.map(r => r.id)]
      );
    }

    // ── 1. Mark step log as completed ─────────────────────────────────────
    await client.query(
      `UPDATE sequence_step_logs SET status='completed', fired_at=NOW() WHERE id=$1`,
      [draft.id]
    );

    // ── 2. Update prospect outreach tracking ──────────────────────────────
    await client.query(
      `UPDATE prospects
          SET outreach_count=outreach_count+1, last_outreach_at=CURRENT_TIMESTAMP,
              updated_at=CURRENT_TIMESTAMP
        WHERE id=$1`,
      [draft.prospect_id]
    );

    // Auto-advance prospect stage on first outreach
    const stageRes = await client.query(
      `SELECT stage, channel_data FROM prospects WHERE id=$1`,
      [draft.prospect_id]
    );
    const currentStage = stageRes.rows[0]?.stage;
    if (['target', 'research'].includes(currentStage)) {
      await client.query(
        `UPDATE prospects
            SET stage='outreach', stage_changed_at=CURRENT_TIMESTAMP,
                updated_at=CURRENT_TIMESTAMP
          WHERE id=$1`,
        [draft.prospect_id]
      );
    }

    // ── 2b. Sync LinkedIn channel_data if this is a LinkedIn step ────────────
    // So the LinkedIn funnel status updates when rep clicks Mark as Done,
    // without requiring a separate Save on the Chrome extension.
    if (draft.channel === 'linkedin') {
      const channelData = stageRes.rows[0]?.channel_data || {};
      const li          = channelData.linkedin || {};
      const STATUS_ORDER = [
        'connection_request_sent', 'connection_accepted',
        'message_sent', 'reply_received', 'meeting_booked',
      ];
      // Intent-aware (was: step_order === 1 — mislabeled a CR at step 2 in
      // email-first sequences as a message). Explicit step_intent wins, then
      // first-LinkedIn-step-in-sequence, with an already-connected guard.
      const liStatus = await resolveLinkedInLogStatus(client, {
        sequenceId:       draft.seq_id,
        stepId:           draft.sequence_step_id,
        stepIntent:       draft.step_intent || null,
        connectionStatus: li.connection_status || null,
      });
      const currentIdx = STATUS_ORDER.indexOf(li.connection_status || '');
      const newIdx     = STATUS_ORDER.indexOf(liStatus);
      if (newIdx > currentIdx) {
        li.connection_status = liStatus;
      }
      if (liStatus === 'connection_request_sent' && !li.request_sent_at) {
        li.request_sent_at = new Date().toISOString();
      } else if (liStatus === 'message_sent') {
        li.last_message_at = new Date().toISOString();
        li.message_count   = (li.message_count || 0) + 1;
      }
      channelData.linkedin = li;
      await client.query(
        `UPDATE prospects SET channel_data = $1::jsonb, updated_at = CURRENT_TIMESTAMP WHERE id = $2`,
        [JSON.stringify(channelData), draft.prospect_id]
      );
    }

    // ── 3. Advance enrollment to next step (identity-cursor, parity with firer) ──
    {
      const settings = await SendingSchedule.resolveSettings({ orgId: req.orgId, campaignId: null });
      await EnrollmentStepResolver.applyAdvance(client, {
        id:                   draft.enrollment_id,
        sequence_id:          draft.seq_id,
        current_step:         draft.current_step,
        current_step_id:      draft.current_step_id,
        current_step_channel: draft.current_step_channel,
        steps_snapshot:       draft.steps_snapshot,
      }, {
        computeDue: (s) => SendingSchedule.nextStepDue(s, settings),
      });
    }

    // ── 4. Mark any linked prospecting action completed ───────────────────
    await client.query(
      `UPDATE prospecting_actions
          SET status='completed', completed_at=CURRENT_TIMESTAMP,
              completed_by=$1, outcome='completed_manually', updated_at=CURRENT_TIMESTAMP
        WHERE org_id=$2 AND source='sequence_draft'
          AND (metadata->>'draftLogId')::int=$3
          AND status != 'completed'`,
      [req.user.userId, req.orgId, draft.id]
    );

    // ── 5. Write activity ─────────────────────────────────────────────────
    await client.query(
      `INSERT INTO prospecting_activities
         (org_id, prospect_id, user_id, activity_type, description, metadata)
       VALUES ($1, $2,$3,'sequence_step_completed',$4,$5)`,
      [req.orgId, 
        draft.prospect_id, req.user.userId,
        `${draft.channel} step completed — ${draft.sequence_name} step ${draft.step_order}`,
        JSON.stringify({
          enrollmentId: draft.enrollment_id,
          draftLogId:   draft.id,
          stepOrder:    draft.step_order,
          channel:      draft.channel,
        }),
      ]
    );

    await client.query('COMMIT');
    res.json({ ok: true });

  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    console.error('POST /sequences/drafts/:logId/complete', err);
    res.status(500).json({ error: { message: 'Failed to complete step: ' + err.message } });
  } finally {
    client.release();
  }
});

// ── discardDraftTx — skip ONE draft step + advance its enrollment ────────────
// Shared by DELETE /drafts/:logId (single) and POST /drafts/bulk-discard so the
// two paths can't drift. The CALLER owns the transaction (BEGIN/COMMIT/ROLLBACK).
// The draft row is locked (FOR UPDATE) so concurrent discards of the same step
// can't double-advance. Returns exactly one of:
//   { logId, notFound: true }   — no 'draft'-status row for this id in the org
//   { logId, forbidden: true }  — row exists but the caller isn't the enroller
//   { logId, discarded: true, prospectId, enrollmentId, enrollmentCompleted }
async function discardDraftTx(client, orgId, userId, logId) {
  const draftRes = await client.query(
    `SELECT ssl.*, ss.step_order, se.enrolled_by, se.current_step,
            se.current_step_id, se.current_step_channel, se.steps_snapshot,
            s.id AS seq_id, s.name AS sequence_name
       FROM sequence_step_logs ssl
       JOIN sequence_steps ss       ON ss.id  = ssl.sequence_step_id
       JOIN sequence_enrollments se ON se.id  = ssl.enrollment_id
       JOIN sequences s             ON s.id   = se.sequence_id
      WHERE ssl.id=$1 AND ssl.org_id=$2 AND ssl.status='draft'
      FOR UPDATE OF ssl`,
    [logId, orgId]
  );
  if (!draftRes.rows.length) return { logId: Number(logId), notFound: true };
  const draft = draftRes.rows[0];

  if (draft.enrolled_by !== userId) return { logId: Number(logId), forbidden: true };

  await client.query(
    `UPDATE sequence_step_logs SET status='skipped', fired_at=NOW() WHERE id=$1`,
    [draft.id]
  );

  let enrollmentCompleted = false;
  {
    const settings = await SendingSchedule.resolveSettings({ orgId, campaignId: null });
    const adv = await EnrollmentStepResolver.applyAdvance(client, {
      id:                   draft.enrollment_id,
      sequence_id:          draft.seq_id,
      current_step:         draft.current_step,
      current_step_id:      draft.current_step_id,
      current_step_channel: draft.current_step_channel,
      steps_snapshot:       draft.steps_snapshot,
    }, {
      computeDue: (s) => SendingSchedule.nextStepDue(s, settings),
    });
    enrollmentCompleted = adv.completed;
  }

  await client.query(
    `UPDATE prospecting_actions
        SET status='completed', completed_at=CURRENT_TIMESTAMP,
            completed_by=$1, outcome='skipped', updated_at=CURRENT_TIMESTAMP
      WHERE org_id=$2 AND source='sequence_draft'
        AND (metadata->>'draftLogId')::int=$3
        AND status != 'completed'`,
    [userId, orgId, draft.id]
  );

  await client.query(
    `INSERT INTO prospecting_activities
       (org_id, prospect_id, user_id, activity_type, description, metadata)
     VALUES ($1, $2,$3,'sequence_step_skipped',$4,$5)`,
    [orgId,
      draft.prospect_id, userId,
      `Draft discarded — ${draft.sequence_name} step ${draft.step_order}`,
      JSON.stringify({ enrollmentId: draft.enrollment_id, draftLogId: draft.id, stepOrder: draft.step_order }),
    ]
  );

  return {
    logId: Number(logId), discarded: true,
    prospectId: draft.prospect_id, enrollmentId: draft.enrollment_id,
    enrollmentCompleted,
  };
}

router.delete('/drafts/:logId', async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const r = await discardDraftTx(client, req.orgId, req.user.userId, req.params.logId);
    if (r.notFound) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: { message: 'Draft not found or already actioned' } });
    }
    if (r.forbidden) {
      await client.query('ROLLBACK');
      return res.status(403).json({ error: { message: 'Only the enrolling rep can discard this draft' } });
    }
    await client.query('COMMIT');
    res.json({ ok: true });
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    console.error('DELETE /sequences/drafts/:logId', err);
    res.status(500).json({ error: { message: 'Failed to discard draft: ' + err.message } });
  } finally {
    client.release();
  }
});

// ── POST /api/sequences/drafts/bulk-discard ──────────────────────────────────
// Bulk version of DELETE /drafts/:logId. Body: { logIds: [1,2,3] }. Each draft
// is skipped and its enrollment advanced using the SAME per-draft logic
// (discardDraftTx). All in ONE transaction — if any hard-fails, nothing commits
// (all-or-nothing), matching bulk-undo, so the rep never lands half-discarded.
// Drafts already actioned (notFound) or owned by another rep (forbidden) are
// reported, not errored. This advances each sequence; it does NOT stop the
// enrollment — that's what bulk-undo is for.
router.post('/drafts/bulk-discard', async (req, res) => {
  const { logIds } = req.body || {};
  if (!Array.isArray(logIds) || logIds.length === 0) {
    return res.status(400).json({ error: { message: 'logIds must be a non-empty array' } });
  }
  if (logIds.length > 500) {
    return res.status(400).json({ error: { message: 'Too many at once (max 500)' } });
  }
  const ids = [...new Set(logIds.map(n => parseInt(n, 10)).filter(Number.isFinite))];
  if (!ids.length) {
    return res.status(400).json({ error: { message: 'No valid logIds' } });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const results = [];
    for (const id of ids) {
      results.push(await discardDraftTx(client, req.orgId, req.user.userId, id));
    }
    await client.query('COMMIT');
    const discarded    = results.filter(r => r.discarded).length;
    const notFound     = results.filter(r => r.notFound).length;
    const forbidden    = results.filter(r => r.forbidden).length;
    const discardedIds = results.filter(r => r.discarded).map(r => r.logId);
    res.json({
      requested: ids.length,
      discarded,
      skipped: notFound + forbidden,
      notFound,
      forbidden,
      discardedIds,
      results,
    });
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    console.error('POST /sequences/drafts/bulk-discard', err);
    res.status(500).json({ error: { message: 'Bulk discard failed (nothing was changed): ' + err.message } });
  } finally {
    client.release();
  }
});

// SEQUENCES CRUD  — /:id routes last so literals above aren't shadowed
// ─────────────────────────────────────────────────────────────────────────────

// GET /api/sequences/:id
// NOTE: /health is declared BEFORE /:id so Express does not match
// GET /sequences/health against the '/:id' param route (which would
// try to cast 'health' to an integer id and 500). Keep it above /:id.

// ═════════════════════════════════════════════════════════════════════════════
// GET /api/sequences/health
// Sprint 4 (Group C). Per-sequence telemetry for the last 24h and 7d.
//
// Returns an array, one entry per active sequence in the org:
//   {
//     sequenceId, sequenceName,
//     last24h: { drafts, sent, replied, failed },
//     last7d:  { drafts, sent, replied, failed },
//     lastFiredAt,             // most recent log row's fired_at
//     topErrors,               // [{ message, count }] for the last 7d
//     stalledEnrollments,      // active enrollments with no log activity in 7d
//   }
//
// Health is computed against sequence_step_logs. A 'failed' row is written
// whenever SequenceStepFirer's per-step block throws. Without the Sprint-4
// migration that adds 'failed' to the status check constraint, this endpoint
// will return all-zero failed counts (correct, but uninformative).
// ═════════════════════════════════════════════════════════════════════════════
router.get('/health', async (req, res) => {
  try {
    // Window helpers
    const day  = `'24 hours'::interval`;
    const week = `'7 days'::interval`;

    // Deny-by-default scope: list only sequences visible to the viewer, and
    // count only activity from reps in their scope (member → self, manager →
    // team, admin → all). ?scope=mine / ?depth= drive the Mine/Team toggle.
    const explicitUserIds = req.query.scope === 'mine' ? [req.userId] : undefined;
    const { userIds } = await AccessPolicy.resolveScope(req, {
      depth: req.query.depth,
      explicitUserIds,
    });

    // Per-sequence aggregates over the last 7d, including last24h via FILTER.
    // Joining sequences ensures we list every active sequence even if it has
    // no recent logs (drafts=sent=failed=0).
    const aggRes = await pool.query(
      `SELECT
         s.id    AS sequence_id,
         s.name  AS sequence_name,
         COUNT(*) FILTER (WHERE ssl.fired_at >= NOW() - ${day}  AND ssl.status = 'draft')::int                              AS drafts_24h,
         COUNT(*) FILTER (WHERE ssl.fired_at >= NOW() - ${day}  AND ssl.status IN ('sent','completed'))::int                AS sent_24h,
         COUNT(*) FILTER (WHERE ssl.fired_at >= NOW() - ${day}  AND ssl.status = 'replied')::int                            AS replied_24h,
         COUNT(*) FILTER (WHERE ssl.fired_at >= NOW() - ${day}  AND ssl.status = 'failed')::int                             AS failed_24h,
         COUNT(*) FILTER (WHERE ssl.fired_at >= NOW() - ${week} AND ssl.status = 'draft')::int                              AS drafts_7d,
         COUNT(*) FILTER (WHERE ssl.fired_at >= NOW() - ${week} AND ssl.status IN ('sent','completed'))::int                AS sent_7d,
         COUNT(*) FILTER (WHERE ssl.fired_at >= NOW() - ${week} AND ssl.status = 'replied')::int                            AS replied_7d,
         COUNT(*) FILTER (WHERE ssl.fired_at >= NOW() - ${week} AND ssl.status = 'failed')::int                             AS failed_7d,
         MAX(ssl.fired_at) AS last_fired_at
       FROM sequences s
       LEFT JOIN sequence_step_logs ssl
              ON ssl.org_id = s.org_id
             AND EXISTS (
                   SELECT 1 FROM sequence_enrollments se2
                    WHERE se2.id = ssl.enrollment_id AND se2.sequence_id = s.id
                      AND se2.enrolled_by = ANY($2::int[])
                 )
      WHERE s.org_id = $1
        AND s.status = 'active'
        AND (s.visibility = 'shared' OR s.created_by = ANY($2::int[]))
      GROUP BY s.id, s.name
      ORDER BY s.id ASC`,
      [req.orgId, userIds]
    );

    // Top error messages over the last 7d, grouped per sequence. We collect
    // these once and stitch into the aggregate result so we don't run N+1
    // queries per sequence.
    const errRes = await pool.query(
      `SELECT se.sequence_id,
              ssl.error_message,
              COUNT(*)::int AS count
         FROM sequence_step_logs ssl
         JOIN sequence_enrollments se ON se.id = ssl.enrollment_id
        WHERE ssl.org_id = $1
          AND ssl.status = 'failed'
          AND ssl.fired_at >= NOW() - ${week}
          AND ssl.error_message IS NOT NULL
          AND se.enrolled_by = ANY($2::int[])
     GROUP BY se.sequence_id, ssl.error_message
     ORDER BY se.sequence_id, count DESC`,
      [req.orgId, userIds]
    );
    const errorsBySeq = {};
    for (const row of errRes.rows) {
      if (!errorsBySeq[row.sequence_id]) errorsBySeq[row.sequence_id] = [];
      if (errorsBySeq[row.sequence_id].length < 3) {
        errorsBySeq[row.sequence_id].push({ message: row.error_message, count: row.count });
      }
    }

    // Stalled enrollments per sequence: active enrollments whose last log
    // row (or enrolled_at if no log yet) is older than 7d. Indicates the
    // firer never ran for them, or they're stuck.
    const stalledRes = await pool.query(
      `SELECT se.sequence_id,
              COUNT(*)::int AS stalled
         FROM sequence_enrollments se
         LEFT JOIN LATERAL (
           SELECT MAX(fired_at) AS last_fired
             FROM sequence_step_logs
            WHERE enrollment_id = se.id
         ) ssl ON true
        WHERE se.org_id = $1
          AND se.status = 'active'
          AND COALESCE(ssl.last_fired, se.enrolled_at) < NOW() - ${week}
          AND se.enrolled_by = ANY($2::int[])
     GROUP BY se.sequence_id`,
      [req.orgId, userIds]
    );
    const stalledBySeq = {};
    for (const row of stalledRes.rows) stalledBySeq[row.sequence_id] = row.stalled;

    // Duplicate drafts per sequence: a 'draft' row for an (enrollment, step) that
    // ALSO has a sibling already in the uq_seq_step_logs_fired predicate. These
    // are the stragglers that make "Mark as Done" raise 23505 (see migration
    // 2026_48 / SequenceStepFirer guard). Surfacing the count here lets a straggler
    // show up on the dashboard before a rep ever clicks into the error.
    const dupRes = await pool.query(
      `SELECT se.sequence_id, COUNT(*)::int AS duplicate_drafts
         FROM sequence_step_logs d
         JOIN sequence_enrollments se ON se.id = d.enrollment_id
        WHERE d.org_id = $1
          AND d.status = 'draft'
          AND se.enrolled_by = ANY($2::int[])
          AND EXISTS (
            SELECT 1 FROM sequence_step_logs f
             WHERE f.enrollment_id    = d.enrollment_id
               AND f.sequence_step_id = d.sequence_step_id
               AND f.id <> d.id
               AND f.status IN ('scheduled','sending','sent','completed','replied')
          )
     GROUP BY se.sequence_id`,
      [req.orgId, userIds]
    );
    const dupBySeq = {};
    for (const row of dupRes.rows) dupBySeq[row.sequence_id] = row.duplicate_drafts;

    const health = aggRes.rows.map(r => ({
      sequenceId:   r.sequence_id,
      sequenceName: r.sequence_name,
      last24h: {
        drafts:  r.drafts_24h,
        sent:    r.sent_24h,
        replied: r.replied_24h,
        failed:  r.failed_24h,
      },
      last7d: {
        drafts:  r.drafts_7d,
        sent:    r.sent_7d,
        replied: r.replied_7d,
        failed:  r.failed_7d,
      },
      lastFiredAt:        r.last_fired_at,
      topErrors:          errorsBySeq[r.sequence_id] || [],
      stalledEnrollments: stalledBySeq[r.sequence_id] || 0,
      duplicateDrafts:    dupBySeq[r.sequence_id] || 0,
    }));

    res.json({ health });
  } catch (err) {
    console.error('sequence health error:', err);
    res.status(500).json({ error: { message: 'Failed to load sequence health' } });
  }
});

router.get('/:id', async (req, res) => {
  try {
    const seqRes = await pool.query(
      `SELECT s.*,
              cu.first_name AS creator_first_name,
              cu.last_name  AS creator_last_name,
              (SELECT COUNT(*)::int FROM sequence_enrollments se
                 WHERE se.sequence_id = s.id AND se.status = 'active'
              ) AS active_enrollment_count
         FROM sequences s
    LEFT JOIN users cu ON cu.id = s.created_by
        WHERE s.id = $1 AND s.org_id = $2`,
      [req.params.id, req.orgId]
    );
    if (!seqRes.rows.length) return res.status(404).json({ error: { message: 'Not found' } });

    const stepsRes = await pool.query(
      `SELECT * FROM sequence_steps WHERE sequence_id = $1 ORDER BY step_order`,
      [req.params.id]
    );
    res.json({ sequence: { ...seqRes.rows[0], steps: stepsRes.rows } });
  } catch (err) {
    console.error('sequences GET /:id', err);
    res.status(500).json({ error: { message: 'Failed to load sequence' } });
  }
});

// PUT /api/sequences/:id
router.put('/:id', async (req, res) => {
  const { name, description, require_approval, ai_enabled, personalize_config_default, visibility, allow_manager_edit, stop_on_connection_accept } = req.body;
  try {
    // Ownership gate — only the owner (or an admin, or a permitted manager) may
    // edit. Peers can view a shared sequence but not change it.
    const ownerRes = await pool.query(
      `SELECT created_by, allow_manager_edit FROM sequences WHERE id = $1 AND org_id = $2`,
      [req.params.id, req.orgId]
    );
    if (!ownerRes.rows.length) return res.status(404).json({ error: { message: 'Not found' } });
    if (!(await AccessPolicy.requireCanEdit(req, res, ownerRes.rows[0].created_by, {
      allowManagerEdit: ownerRes.rows[0].allow_manager_edit,
    }))) return;

    // personalize_config_default semantics:
    //   undefined → don't touch (COALESCE keeps existing)
    //   null      → explicitly clear (revert to user/system default in cascade)
    //   object    → set new override
    const pcdParam = personalize_config_default === undefined
      ? null
      : (personalize_config_default === null ? null : JSON.stringify(personalize_config_default));
    const pcdProvided = personalize_config_default !== undefined;

    // visibility: undefined → leave as-is; otherwise normalize to shared|private.
    const visProvided = visibility !== undefined;
    const visParam = visibility === 'private' ? 'private' : 'shared';

    // allow_manager_edit: undefined → leave as-is; otherwise set boolean.
    const ameProvided = allow_manager_edit !== undefined;
    const ameParam = allow_manager_edit === true;

    // stop_on_connection_accept: undefined → leave as-is; otherwise set boolean.
    const soaProvided = stop_on_connection_accept !== undefined;
    const soaParam = stop_on_connection_accept === true;

    const { rows } = await pool.query(
      `UPDATE sequences SET name=$1, description=$2,
        require_approval=COALESCE($3, require_approval),
        ai_enabled=COALESCE($4, ai_enabled),
        personalize_config_default = CASE WHEN $5::boolean THEN $6::jsonb ELSE personalize_config_default END,
        visibility = CASE WHEN $7::boolean THEN $8 ELSE visibility END,
        allow_manager_edit = CASE WHEN $9::boolean THEN $10::boolean ELSE allow_manager_edit END,
        stop_on_connection_accept = CASE WHEN $11::boolean THEN $12::boolean ELSE stop_on_connection_accept END,
        updated_at=NOW()
        WHERE id=$13 AND org_id=$14 RETURNING *`,
      [name, description || null,
       require_approval !== undefined ? require_approval : null,
       ai_enabled !== undefined ? ai_enabled : null,
       pcdProvided, pcdParam,
       visProvided, visParam,
       ameProvided, ameParam,
       soaProvided, soaParam,
       req.params.id, req.orgId]
    );
    if (!rows.length) return res.status(404).json({ error: { message: 'Not found' } });
    res.json({ sequence: rows[0] });
  } catch (err) {
    console.error('sequences PUT /:id', err);
    res.status(500).json({ error: { message: 'Failed to update sequence' } });
  }
});

// DELETE /api/sequences/:id  — soft archive
//
// Sequences remain org-shared (no ownership scoping), but archiving a
// sequence with active enrollments is a footgun: the firer skips archived
// sequences entirely, so in-flight enrollments silently stop advancing.
// Block non-admin archives in that state; allow admins to force-archive
// with ?force=true after they've acknowledged the consequence in the UI.
//
// The original message "Existing enrollments will not be affected" was
// factually wrong — they ARE affected (they stall). This change makes the
// real consequence visible.
router.delete('/:id', async (req, res) => {
  try {
    // Ownership gate — only the owner (or admin, or a permitted manager) may
    // archive. This runs before the active-enrollment safety check below.
    const ownerRes = await pool.query(
      `SELECT created_by, allow_manager_edit FROM sequences WHERE id = $1 AND org_id = $2`,
      [req.params.id, req.orgId]
    );
    if (!ownerRes.rows.length) return res.status(404).json({ error: { message: 'Not found' } });
    if (!(await AccessPolicy.requireCanEdit(req, res, ownerRes.rows[0].created_by, {
      allowManagerEdit: ownerRes.rows[0].allow_manager_edit,
    }))) return;

    // Count active enrollments first — if any, gate by role.
    const enrollRes = await pool.query(
      `SELECT COUNT(*)::int AS active_count
         FROM sequence_enrollments
        WHERE sequence_id = $1 AND org_id = $2 AND status = 'active'`,
      [req.params.id, req.orgId]
    );
    const activeCount = enrollRes.rows[0]?.active_count || 0;

    if (activeCount > 0) {
      // Look up caller's role (admin/owner can force; member cannot).
      const roleRes = await pool.query(
        `SELECT role FROM org_users
          WHERE user_id = $1 AND org_id = $2 AND is_active = TRUE`,
        [req.userId, req.orgId]
      );
      const role = roleRes.rows[0]?.role || null;
      const isAdmin = role === 'admin' || role === 'owner';
      const forced  = req.query.force === 'true' || req.query.force === '1';

      if (!isAdmin) {
        return res.status(403).json({ error: {
          message: `Cannot archive — sequence has ${activeCount} active enrollment${activeCount === 1 ? '' : 's'}. Stop them first, or ask an admin to force-archive.`,
        } });
      }
      if (!forced) {
        return res.status(409).json({ error: {
          message: `Sequence has ${activeCount} active enrollment${activeCount === 1 ? '' : 's'}. Their next steps will silently stop firing once archived. Re-send with ?force=true to confirm.`,
          activeEnrollmentCount: activeCount,
          requiresForce: true,
        } });
      }
      // Admin + force=true: fall through to archive.
    }

    const { rows } = await pool.query(
      `UPDATE sequences SET status='archived', updated_at=NOW()
        WHERE id=$1 AND org_id=$2 RETURNING id`,
      [req.params.id, req.orgId]
    );
    if (!rows.length) return res.status(404).json({ error: { message: 'Not found' } });
    res.json({ ok: true, archivedActiveEnrollments: activeCount });
  } catch (err) {
    console.error('sequences DELETE /:id', err);
    res.status(500).json({ error: { message: 'Failed to archive sequence' } });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// STEPS CRUD
// ─────────────────────────────────────────────────────────────────────────────

// POST /api/sequences/:id/steps
router.post('/:id/steps', async (req, res) => {
  const { channel, delay_days, delay_hours, subject_template, body_template, task_note,
          require_approval, personalize_config, step_intent } = req.body;
  if (!(await gateSequenceEdit(req, res, req.params.id))) return;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    // Freeze in-flight prospects first (freeze-mode orgs) so the new step never
    // appears in their pinned plan. No-op for 'live' orgs.
    await EnrollmentStepResolver.freezeIfConfigured(client, req.orgId, req.params.id);

    const maxRes = await client.query(
      `SELECT COALESCE(MAX(step_order), 0) AS max_order FROM sequence_steps WHERE sequence_id=$1`,
      [req.params.id]
    );
    const nextOrder = maxRes.rows[0].max_order + 1;

    const { rows } = await client.query(
      `INSERT INTO sequence_steps
         (sequence_id, org_id, step_order, channel, delay_days, delay_hours,
          subject_template, body_template, task_note, require_approval,
          personalize_config, step_intent)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING *`,
      [req.params.id, req.orgId, nextOrder, channel, delay_days ?? 0, delay_hours ?? 0,
       subject_template || null, body_template || null, task_note || null,
       require_approval !== undefined ? require_approval : null,
       personalize_config ? JSON.stringify(personalize_config) : null,
       step_intent || null]
    );
    await client.query('COMMIT');
    res.status(201).json({ step: rows[0] });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('sequences POST /:id/steps', err);
    res.status(500).json({ error: { message: 'Failed to add step' } });
  } finally {
    client.release();
  }
});

// PUT /api/sequences/:id/steps/:stepId
router.put('/:id/steps/:stepId', async (req, res) => {
  const { channel, delay_days, delay_hours, subject_template, body_template, task_note,
          require_approval, personalize_config, step_intent } = req.body;
  if (!(await gateSequenceEdit(req, res, req.params.id))) return;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    // Freeze in-flight prospects first (freeze-mode orgs) so this content edit
    // doesn't reach anyone already enrolled. No-op for 'live' orgs.
    await EnrollmentStepResolver.freezeIfConfigured(client, req.orgId, req.params.id);

    // personalize_config: undefined → don't touch; null → clear (inherit); obj → set
    const pcParam = personalize_config === undefined
      ? null
      : (personalize_config === null ? null : JSON.stringify(personalize_config));
    const pcProvided = personalize_config !== undefined;

    // step_intent semantics mirror personalize_config:
    //   undefined → don't touch
    //   null      → clear (auto-infer)
    //   string    → set explicit override
    const siProvided = step_intent !== undefined;
    const siParam = step_intent === undefined ? null : (step_intent || null);

    // require_approval semantics mirror the above (null = Inherit is a real value,
    // not "don't touch"). The old COALESCE swallowed an explicit null, so choosing
    // "Inherit" in the builder could never clear a prior true/false — fixed here
    // with a provided-flag so undefined=leave, null=set-inherit, bool=override.
    const raProvided = require_approval !== undefined;
    const raParam = require_approval === undefined ? null : require_approval; // null|true|false

    const { rows } = await client.query(
      `UPDATE sequence_steps
          SET channel=$1, delay_days=$2, delay_hours=$3, subject_template=$4,
              body_template=$5, task_note=$6,
              require_approval = CASE WHEN $14::boolean THEN $7::boolean ELSE require_approval END,
              personalize_config = CASE WHEN $8::boolean THEN $9::jsonb ELSE personalize_config END,
              step_intent = CASE WHEN $10::boolean THEN $11::text ELSE step_intent END,
              updated_at=NOW()
        WHERE id=$12 AND sequence_id=$13
        RETURNING *`,
      [channel, delay_days ?? 0, delay_hours ?? 0, subject_template || null,
       body_template || null, task_note || null,
       raParam,
       pcProvided, pcParam,
       siProvided, siParam,
       req.params.stepId, req.params.id,
       raProvided]
    );
    if (!rows.length) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: { message: 'Step not found' } });
    }

    // For 'live' (non-frozen) in-flight enrollments only:
    //   • invalidate any cached AI draft for this step (keyed by step id) so the
    //     next tick regenerates against the edited template.
    //   • re-sync the denormalized current_step_channel if this is the step the
    //     prospect is currently on and its channel changed.
    const stepId = Number(req.params.stepId);
    await client.query(
      `UPDATE sequence_enrollments
          SET personalised_steps = personalised_steps - $1::text
        WHERE sequence_id = $2 AND org_id = $3
          AND status = 'active'
          AND steps_snapshot IS NULL
          AND personalised_steps ? $1::text`,
      [String(stepId), req.params.id, req.orgId]
    );
    await client.query(
      `UPDATE sequence_enrollments
          SET current_step_channel = $1
        WHERE sequence_id = $2 AND org_id = $3
          AND status = 'active'
          AND steps_snapshot IS NULL
          AND current_step_id = $4`,
      [rows[0].channel, req.params.id, req.orgId, stepId]
    );

    await client.query('COMMIT');
    res.json({ step: rows[0] });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('sequences PUT /:id/steps/:stepId', err);
    res.status(500).json({ error: { message: 'Failed to update step' } });
  } finally {
    client.release();
  }
});

// DELETE /api/sequences/:id/steps/:stepId
router.delete('/:id/steps/:stepId', async (req, res) => {
  if (!(await gateSequenceEdit(req, res, req.params.id))) return;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    // Freeze in-flight prospects first (freeze-mode orgs) so a removed step is
    // preserved in their pinned plan. No-op for 'live' orgs. NOTE: a step still
    // referenced by sent/pending logs is protected by the sequence_step_logs FK
    // (ON DELETE RESTRICT) and the delete will fail — unchanged pre-existing
    // behaviour. current_step_id on enrollments is ON DELETE SET NULL, so a live
    // enrollment sitting on the deleted step re-anchors via the resolver.
    await EnrollmentStepResolver.freezeIfConfigured(client, req.orgId, req.params.id);

    const delRes = await client.query(
      `DELETE FROM sequence_steps WHERE id=$1 AND sequence_id=$2 RETURNING step_order`,
      [req.params.stepId, req.params.id]
    );
    if (!delRes.rows.length) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: { message: 'Step not found' } });
    }
    const deletedOrder = delRes.rows[0].step_order;
    // Re-number subsequent steps
    await client.query(
      `UPDATE sequence_steps SET step_order=step_order-1 WHERE sequence_id=$1 AND step_order>$2`,
      [req.params.id, deletedOrder]
    );
    await client.query('COMMIT');
    res.json({ ok: true });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('sequences DELETE /:id/steps/:stepId', err);
    res.status(500).json({ error: { message: 'Failed to delete step' } });
  } finally {
    client.release();
  }
});

// POST /api/sequences/:id/steps/reorder
router.post('/:id/steps/reorder', async (req, res) => {
  const { steps } = req.body; // [{ id, step_order }]
  if (!Array.isArray(steps)) return res.status(400).json({ error: { message: 'steps[] required' } });
  if (!(await gateSequenceEdit(req, res, req.params.id))) return;

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    // Pin in-flight prospects to the pre-edit plan if the org opted into
    // 'freeze' propagation. No-op for 'live' (default) orgs. Must run BEFORE the
    // renumber so the snapshot captures the current order.
    await EnrollmentStepResolver.freezeIfConfigured(client, req.orgId, req.params.id);

    // The per-row loop passes through a transiently-colliding step_order state;
    // the UNIQUE (sequence_id, step_order) constraint was made DEFERRABLE
    // INITIALLY DEFERRED (migration 2026_43) so it is validated once at COMMIT.
    for (const s of steps) {
      await client.query(
        `UPDATE sequence_steps SET step_order=$1 WHERE id=$2 AND sequence_id=$3`,
        [s.step_order, s.id, req.params.id]
      );
    }
    await client.query('COMMIT');
    const { rows } = await pool.query(
      `SELECT * FROM sequence_steps WHERE sequence_id=$1 ORDER BY step_order`,
      [req.params.id]
    );
    res.json({ steps: rows });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('sequences POST /:id/steps/reorder', err);
    res.status(500).json({ error: { message: 'Failed to reorder steps' } });
  } finally {
    client.release();
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// AI GENERATE STEPS
// POST /api/sequences/:id/ai-generate
// body: { prospectId }
// ─────────────────────────────────────────────────────────────────────────────
router.post('/:id/ai-generate', async (req, res) => {
  const { prospectId } = req.body;
  if (!prospectId) return res.status(400).json({ error: { message: 'prospectId is required' } });

  try {
    const seqRes = await pool.query(
      `SELECT * FROM sequences WHERE id=$1 AND org_id=$2`,
      [req.params.id, req.orgId]
    );
    if (!seqRes.rows.length) return res.status(404).json({ error: { message: 'Sequence not found' } });

    const stepsRes = await pool.query(
      `SELECT * FROM sequence_steps WHERE sequence_id=$1 ORDER BY step_order`,
      [req.params.id]
    );

    const prospectRes = await pool.query(
      `SELECT p.*, a.name AS account_name, a.domain AS account_domain,
              a.industry AS account_industry
         FROM prospects p
    LEFT JOIN accounts a ON a.id = p.account_id
        WHERE p.id=$1 AND p.org_id=$2`,
      [prospectId, req.orgId]
    );
    if (!prospectRes.rows.length) return res.status(404).json({ error: { message: 'Prospect not found' } });
    const prospect = prospectRes.rows[0];

    const systemPrompt = `You are an expert SDR copywriter. Personalise the following email sequence steps for the given prospect.
Return ONLY valid JSON — no markdown, no prose.`;

    const userPrompt = `Personalise these sequence steps for:
Name: ${prospect.first_name} ${prospect.last_name}
Title: ${prospect.title || 'unknown'}
Company: ${prospect.account_name || prospect.company_name || 'unknown'}
Industry: ${prospect.account_industry || 'unknown'}
${prospect.research_notes ? 'Research: ' + prospect.research_notes : ''}

STEPS:
${stepsRes.rows.map((s, i) => `Step ${i+1} (${s.channel}): subject="${s.subject_template||''}" body="${(s.body_template||'').slice(0,200)}"`).join('\n')}

Return JSON: { "steps": [{ "step_order": 1, "subject": "...", "body": "...", "task_note": "" }] }`;

    const { adapter, model, provider, keySource } =
      await AIClientResolver.resolve(req.orgId, req.user.userId, 'prospecting_sequence_generate');

    const aiRes = await adapter.complete({
      model,
      maxTokens: 2000,
      system:    systemPrompt,
      messages:  [{ role: 'user', content: userPrompt }],
    });

    try {
      await TokenTrackingService.log({
        orgId:    req.orgId,
        userId:   req.user.userId,
        callType: 'prospecting_sequence_generate',
        model,
        provider,
        keySource,
        usage:    aiRes.usage,
      });
    } catch (_) {}

    const raw   = aiRes.text || '{}';
    const clean = raw.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(clean);

    res.json({
      steps: (parsed.steps || []).map(s => ({
        step_order: s.step_order,
        subject:    s.subject    || '',
        body:       s.body       || '',
        task_note:  s.task_note  || '',
      })),
    });
  } catch (err) {
    console.error('ai-generate error:', err);
    res.status(500).json({ error: { message: 'AI generation failed: ' + err.message } });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// AI BUILD SEQUENCE
// POST /api/sequences/ai-build
// ─────────────────────────────────────────────────────────────────────────────
router.post('/ai-build', async (req, res) => {
  const { name, description, channelMix, steps: stepCount, tone, goal } = req.body;

  try {
    const systemPrompt = `You are an expert SDR sequence architect. Build a complete outreach sequence.
Return ONLY valid JSON — no markdown fences, no prose.`;

    const userPrompt = `Build an outreach sequence with these requirements:
Name: ${name || 'New Sequence'}
Goal: ${goal || 'Book a discovery call'}
Tone: ${tone || 'Professional, concise'}
Description: ${description || ''}
Number of steps: ${stepCount || 5}
Channel mix: ${channelMix || 'Mostly email with 1-2 LinkedIn touchpoints'}

For each step include: channel (email|linkedin|call|task), delay_days (days after previous step), delay_hours (0-23, optional sub-day offset added to delay_days — use for same-day follow-ups like "2 hours after the email"), subject_template (for email/linkedin), body_template (for email/linkedin), task_note (for call/task).
Use {{first_name}}, {{company}}, {{title}}, {{industry}} as personalisation tokens.

Return JSON:
{
  "name": "...",
  "description": "...",
  "steps": [
    {
      "step_order": 1,
      "channel": "email",
      "delay_days": 0,
      "delay_hours": 0,
      "subject_template": "...",
      "body_template": "...",
      "task_note": ""
    }
  ]
}`;

    const { adapter, model, provider, keySource } =
      await AIClientResolver.resolve(req.orgId, req.user.userId, 'prospecting_sequence_generate');

    const aiRes = await adapter.complete({
      model,
      maxTokens: 3000,
      system:    systemPrompt,
      messages:  [{ role: 'user', content: userPrompt }],
    });

    try {
      await TokenTrackingService.log({
        orgId:    req.orgId,
        userId:   req.user.userId,
        callType: 'prospecting_sequence_generate',
        model,
        provider,
        keySource,
        usage:    aiRes.usage,
      });
    } catch (_) {}

    const raw   = aiRes.text || '{}';
    const clean = raw.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(clean);

    res.json({
      name:        parsed.name        || '',
      description: parsed.description || '',
      steps:       (parsed.steps      || []).map((s, i) => ({ ...s, step_order: i + 1 })),
    });
  } catch (err) {
    console.error('ai-build error:', err);
    res.status(500).json({ error: { message: 'AI build failed: ' + err.message } });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// AI WRITE STEP
// POST /api/sequences/ai-write-step
// ─────────────────────────────────────────────────────────────────────────────
router.post('/ai-write-step', async (req, res) => {
  const { prompt, channel = 'email', stepNumber = 1, totalSteps = 1, previousSteps = [] } = req.body;
  if (!prompt?.trim()) return res.status(400).json({ error: { message: 'prompt is required' } });

  const hasContent = ['email', 'linkedin'].includes(channel);

  try {
    const systemPrompt = `You are an expert SDR copywriter writing outreach message templates.\nReturn ONLY valid JSON — no markdown fences, no prose.`;

    const context = previousSteps.length > 0
      ? `\nPREVIOUS STEPS IN THIS SEQUENCE:\n${previousSteps.map((s, i) =>
          `Step ${i + 1} (${s.channel}): ${s.subject_template || s.task_note || '(no subject)'}`
        ).join('\n')}\n`
      : '';

    const userPrompt = `Write step ${stepNumber} of ${totalSteps} in an outreach sequence.\n\nCHANNEL: ${channel}\nINSTRUCTION: ${prompt}\n${context}\nRules:\n- Use {{first_name}}, {{company}}, {{title}}, {{industry}} as personalisation tokens\n- Keep it human and concise — under 100 words for email body\n- This is a TEMPLATE, not a personalised message\n${hasContent
  ? '- Return subject_template and body_template; leave task_note as empty string'
  : '- This is a call/task step — return a brief task_note describing what to do; leave subject_template and body_template as empty strings'
}\n\nReturn JSON:\n{\n  "subject_template": "...",\n  "body_template": "...",\n  "task_note": ""\n}`;

    const { adapter, model, provider, keySource } =
      await AIClientResolver.resolve(req.orgId, req.user.userId, 'prospecting_sequence_generate');

    const aiRes = await adapter.complete({
      model,
      maxTokens: 800,
      system:    systemPrompt,
      messages:  [{ role: 'user', content: userPrompt }],
    });

    try {
      await TokenTrackingService.log({
        orgId:    req.orgId,
        userId:   req.user.userId,
        callType: 'prospecting_sequence_generate',
        model,
        provider,
        keySource,
        usage:    aiRes.usage,
      });
    } catch (_) {}

    const raw   = aiRes.text || '{}';
    const clean = raw.replace(/```json|```/g, '').trim();
    const parsed = JSON.parse(clean);

    res.json({
      subject_template: parsed.subject_template || '',
      body_template:    parsed.body_template    || '',
      task_note:        parsed.task_note        || '',
    });
  } catch (err) {
    console.error('ai-write-step error:', err);
    res.status(500).json({ error: { message: 'AI step write failed: ' + err.message } });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// SEQUENCE STATS
// GET /api/sequences/:id/stats
// ─────────────────────────────────────────────────────────────────────────────
// ─────────────────────────────────────────────────────────────────────────────
// GET /api/sequences/:id/stats
// ─────────────────────────────────────────────────────────────────────────────
//
// Per-sequence funnel stats. Original (Sprint-3) behavior is preserved when
// called with no Phase-3 query params — frontends like SequencesView keep
// working without any change.
//
// Phase 3 extensions (all optional, additive):
//   ?depth=direct|plus1|plus2|all   filter to a scope of enrolled_by users
//   ?userIds=1,2,3                   filter to a specific set (∩ with scope)
//   ?startDate=ISO  ?endDate=ISO     time window for the byUser block
//   ?windowDays=N                    alternative to start/end
//   ?groupBy=sequence|user|both      defaults to 'sequence' (current behavior).
//                                    'user' or 'both' add a byUser[] array.
//
// Important note on the time window (see SEQUENCE_REPORTING_DESIGN.md
// Appendix A.3 for context):
//   The original response fields (totalEnrolled, statusBreakdown, stepFunnel,
//   replyRate, avgReplyStep) remain ALL-TIME by default. They reflect the
//   current state of enrollments + cumulative log activity. Changing those
//   silently to "last 7 days" would break SequencesView's "Reply Rate" tile
//   (it would suddenly show only a fraction of the historical denominator).
//
//   The new byUser[] block is window-bound — it shows per-rep activity
//   within the supplied window. windowDays defaults to 7 in that block.
//
//   If a caller wants the original fields windowed too, they should pass
//   ?userIds= AND ?startDate=/?endDate= explicitly. In that mode the user
//   filter applies to the original state queries as well (the caller has
//   asked to slice). This compromise satisfies A.3's goal of bounding heavy
//   queries while preserving back-compat for the existing UI caller.
//
// Auth: when ?userIds or ?depth is set, results pass through
// ReportingScopeService.resolveReportingScope — out-of-scope IDs are
// silently dropped, never errored.
//
router.get('/:id/stats', async (req, res) => {
  try {
    const seqRes = await pool.query(
      `SELECT s.*, COUNT(ss.id) AS step_count
         FROM sequences s
    LEFT JOIN sequence_steps ss ON ss.sequence_id = s.id
        WHERE s.id = $1 AND s.org_id = $2
     GROUP BY s.id`,
      [req.params.id, req.orgId]
    );
    if (!seqRes.rows.length) return res.status(404).json({ error: { message: 'Not found' } });

    // ── Phase 3: parse optional filters ──────────────────────────────
    const groupBy = ['sequence', 'user', 'both'].includes(req.query.groupBy)
      ? req.query.groupBy
      : 'sequence';

    // Deny-by-default: ALWAYS resolve the viewer's scope and filter the state
    // queries by it (member → self, manager → team, admin → all), even when no
    // userIds/depth is passed. ?userIds= or ?scope=mine narrow within scope.
    const explicitUserIds = req.query.userIds !== undefined
      ? String(req.query.userIds).split(',').map(s => parseInt(s.trim(), 10)).filter(Number.isInteger)
      : (req.query.scope === 'mine' ? [req.user.userId] : null);
    const scope = await ReportingScopeService.resolveReportingScope(
      req.user.userId,
      req.orgId,
      { depth: req.query.depth, explicitUserIds }
    );
    const userFilterIds = scope.userIds;   // always non-null now

    // Rep-filter fragment for the state queries — always applied.
    const repFilterParam = userFilterIds;

    // ── Original (state) queries — params + rep filter ──────
    const stateParams = [req.params.id, req.orgId];
    let stateRepClause = '';
    if (repFilterParam) {
      stateParams.push(repFilterParam);
      stateRepClause = `AND se.enrolled_by = ANY($3::int[])`;
    }

    const statusRes = await pool.query(
      `SELECT status, COUNT(*) AS count
         FROM sequence_enrollments se
        WHERE se.sequence_id = $1 AND se.org_id = $2
              ${stateRepClause}
     GROUP BY status`,
      stateParams
    );
    const statusMap = {};
    statusRes.rows.forEach(r => { statusMap[r.status] = parseInt(r.count); });
    const totalEnrolled = Object.values(statusMap).reduce((a, b) => a + b, 0);
    const totalReplied  = statusMap['replied'] || 0;

    // 'sent' must count BOTH 'sent' (email) and 'completed' (LinkedIn/call/task
    // steps — /drafts/:logId/complete marks manual steps 'completed', not
    // 'sent'). Counting only 'sent' here under-reported every non-email step to
    // zero, so a LinkedIn-led sequence's funnel looked empty. This matches the
    // Health endpoint and the byUser block below, which both use IN
    // ('sent','completed').
    const stepFunnelRes = await pool.query(
      `SELECT
         ss.step_order,
         COUNT(*) FILTER (WHERE ssl.status IN ('sent','completed')) AS sent,
         COUNT(*) FILTER (WHERE ssl.status = 'skipped')             AS skipped,
         COUNT(*) FILTER (WHERE ssl.status = 'failed')              AS failed
       FROM sequence_step_logs ssl
       JOIN sequence_steps ss       ON ss.id = ssl.sequence_step_id
       JOIN sequence_enrollments se ON se.id = ssl.enrollment_id
      WHERE se.sequence_id = $1 AND se.org_id = $2
            ${stateRepClause}
   GROUP BY ss.step_order
   ORDER BY ss.step_order`,
      stateParams
    );

    const replyStepRes = await pool.query(
      `SELECT current_step, COUNT(*) AS reply_count
         FROM sequence_enrollments se
        WHERE se.sequence_id = $1 AND se.org_id = $2 AND se.status = 'replied'
              ${stateRepClause}
     GROUP BY current_step
     ORDER BY current_step`,
      stateParams
    );
    const replyByStep = {};
    replyStepRes.rows.forEach(r => { replyByStep[r.current_step] = parseInt(r.reply_count); });

    let avgReplyStep = null;
    if (totalReplied > 0) {
      const weightedSum = replyStepRes.rows.reduce((sum, r) => sum + r.current_step * parseInt(r.reply_count), 0);
      avgReplyStep = (weightedSum / totalReplied).toFixed(1);
    }

    const stepFunnel = stepFunnelRes.rows.map(row => ({
      step_order:  row.step_order,
      sent:        parseInt(row.sent),
      skipped:     parseInt(row.skipped),
      failed:      parseInt(row.failed),
      replied_here: replyByStep[row.step_order] || 0,
    }));

    const response = {
      sequence:      seqRes.rows[0],
      totalEnrolled,
      totalReplied,
      replyRate:     totalEnrolled > 0 ? ((totalReplied / totalEnrolled) * 100).toFixed(1) : '0.0',
      avgReplyStep,
      statusBreakdown: {
        active:    statusMap['active']    || 0,
        paused:    statusMap['paused']    || 0,
        completed: statusMap['completed'] || 0,
        stopped:   statusMap['stopped']   || 0,
        replied:   statusMap['replied']   || 0,
        // WS2: enrollments auto-stopped because the LinkedIn connection was
        // accepted (sequences.stop_on_connection_accept).
        connected: statusMap['connected'] || 0,
      },
      stepFunnel,
    };

    // ── Phase 3: byUser block (window-bound) ─────────────────────────
    if (groupBy === 'user' || groupBy === 'both') {
      const w = _parsePhase3Window(req.query);
      const buParams = [req.orgId, scope.userIds, req.params.id, w.startISO, w.endISO];

      const buRes = await pool.query(
        `WITH log_agg AS (
           SELECT
             se.enrolled_by AS user_id,
             COUNT(*) FILTER (WHERE ssl.status = 'draft')::int                              AS drafts,
             COUNT(*) FILTER (WHERE ssl.status IN ('sent','completed'))::int                AS sent,
             COUNT(*) FILTER (WHERE ssl.status = 'replied')::int                            AS replied,
             COUNT(*) FILTER (WHERE ssl.status = 'failed')::int                             AS failed,
             COUNT(*) FILTER (WHERE ssl.status = 'draft'    AND ssl.fired_at >= NOW() - INTERVAL '24 hours')::int               AS drafts_24h,
             COUNT(*) FILTER (WHERE ssl.status IN ('sent','completed') AND ssl.fired_at >= NOW() - INTERVAL '24 hours')::int    AS sent_24h,
             COUNT(*) FILTER (WHERE ssl.status = 'replied'  AND ssl.fired_at >= NOW() - INTERVAL '24 hours')::int               AS replied_24h,
             COUNT(*) FILTER (WHERE ssl.status = 'failed'   AND ssl.fired_at >= NOW() - INTERVAL '24 hours')::int               AS failed_24h,
             COUNT(*) FILTER (WHERE ssl.status = 'draft'    AND ssl.fired_at >= NOW() - INTERVAL '7 days')::int                 AS drafts_7d,
             COUNT(*) FILTER (WHERE ssl.status IN ('sent','completed') AND ssl.fired_at >= NOW() - INTERVAL '7 days')::int      AS sent_7d,
             COUNT(*) FILTER (WHERE ssl.status = 'replied'  AND ssl.fired_at >= NOW() - INTERVAL '7 days')::int                 AS replied_7d,
             COUNT(*) FILTER (WHERE ssl.status = 'failed'   AND ssl.fired_at >= NOW() - INTERVAL '7 days')::int                 AS failed_7d,
             MAX(ssl.fired_at) AS last_fired_at
           FROM sequence_step_logs ssl
           JOIN sequence_enrollments se ON se.id = ssl.enrollment_id
           WHERE ssl.org_id     = $1
             AND se.sequence_id = $3
             AND se.enrolled_by = ANY($2::int[])
             AND ssl.fired_at  >= $4::timestamptz
             AND ssl.fired_at  <= $5::timestamptz
           GROUP BY se.enrolled_by
         ),
         enroll_agg AS (
           SELECT
             se.enrolled_by AS user_id,
             COUNT(*)::int AS enrolled,
             COUNT(*) FILTER (WHERE se.status = 'active')::int AS active_enrollments
           FROM sequence_enrollments se
           WHERE se.org_id     = $1
             AND se.sequence_id = $3
             AND se.enrolled_by = ANY($2::int[])
             AND se.enrolled_at >= $4::timestamptz
             AND se.enrolled_at <= $5::timestamptz
           GROUP BY se.enrolled_by
         ),
         stalled_agg AS (
           SELECT
             se.enrolled_by AS user_id,
             COUNT(*)::int AS stalled
           FROM sequence_enrollments se
           LEFT JOIN LATERAL (
             SELECT MAX(fired_at) AS last_fired FROM sequence_step_logs
              WHERE enrollment_id = se.id
           ) sx ON true
           WHERE se.org_id     = $1
             AND se.sequence_id = $3
             AND se.enrolled_by = ANY($2::int[])
             AND se.status     = 'active'
             AND COALESCE(sx.last_fired, se.enrolled_at) < $5::timestamptz - INTERVAL '7 days'
           GROUP BY se.enrolled_by
         )
         SELECT
           u.id AS user_id, u.first_name, u.last_name, u.email,
           COALESCE(l.drafts, 0)    AS drafts,
           COALESCE(l.sent, 0)      AS sent,
           COALESCE(l.replied, 0)   AS replied,
           COALESCE(l.failed, 0)    AS failed,
           COALESCE(l.drafts_24h,  0) AS drafts_24h,
           COALESCE(l.sent_24h,    0) AS sent_24h,
           COALESCE(l.replied_24h, 0) AS replied_24h,
           COALESCE(l.failed_24h,  0) AS failed_24h,
           COALESCE(l.drafts_7d,   0) AS drafts_7d,
           COALESCE(l.sent_7d,     0) AS sent_7d,
           COALESCE(l.replied_7d,  0) AS replied_7d,
           COALESCE(l.failed_7d,   0) AS failed_7d,
           l.last_fired_at,
           COALESCE(e.enrolled, 0)            AS enrolled,
           COALESCE(e.active_enrollments, 0)  AS active_enrollments,
           COALESCE(st.stalled, 0)            AS stalled
         FROM users u
         LEFT JOIN log_agg     l  ON l.user_id  = u.id
         LEFT JOIN enroll_agg  e  ON e.user_id  = u.id
         LEFT JOIN stalled_agg st ON st.user_id = u.id
         WHERE u.id = ANY($2::int[])
         ORDER BY l.last_fired_at DESC NULLS LAST, u.first_name ASC`,
        buParams
      );

      const reportByUserId = new Map(scope.reports.map(r => [r.userId, r]));
      response.byUser = buRes.rows.map(r => {
        const name = [r.first_name, r.last_name].filter(Boolean).join(' ').trim() || r.email;
        const meta = reportByUserId.get(r.user_id);
        const isViewer = r.user_id === req.user.userId;
        return {
          userId:           r.user_id,
          name,
          email:            r.email,
          isDirect:         isViewer ? false : (meta?.isDirect ?? null),
          depthFromManager: isViewer ? 0     : (meta?.depthFromManager ?? null),
          enrolled:         r.enrolled,
          drafts:           r.drafts,
          sent:             r.sent,
          replied:          r.replied,
          failed:           r.failed,
          stalled:          r.stalled,
          drafts_24h:       r.drafts_24h,
          sent_24h:         r.sent_24h,
          replied_24h:      r.replied_24h,
          failed_24h:       r.failed_24h,
          drafts_7d:        r.drafts_7d,
          sent_7d:          r.sent_7d,
          replied_7d:       r.replied_7d,
          failed_7d:        r.failed_7d,
          lastFiredAt:      r.last_fired_at,
          activeEnrollments: r.active_enrollments,
        };
      });
      response.period = {
        startDate:   w.startISO,
        endDate:     w.endISO,
        description: w.isoIntervalDescription,
      };
      response.scope = scope;
    }

    res.json(response);
  } catch (err) {
    console.error('sequence stats error:', err);
    res.status(500).json({ error: { message: 'Failed to load stats: ' + err.message } });
  }
});

// Phase 3 helper — same semantics as parseTimeWindow in reporting.routes.js
// (duplicated here to avoid a circular import; both files own their own
// param-parsing surface). Default window: last 7 days. windowDays clamped
// to [1, 365].
function _parsePhase3Window(query) {
  const { startDate, endDate, windowDays } = query;
  if (startDate && endDate) {
    const s = new Date(startDate);
    const e = new Date(endDate);
    if (Number.isNaN(s.getTime()) || Number.isNaN(e.getTime())) {
      throw new Error('startDate and endDate must be valid ISO date strings');
    }
    return {
      startISO: s.toISOString(),
      endISO:   e.toISOString(),
      isoIntervalDescription: `${s.toISOString().slice(0, 10)} to ${e.toISOString().slice(0, 10)}`,
    };
  }
  const days = windowDays !== undefined
    ? Math.max(1, Math.min(365, parseInt(windowDays, 10) || 7))
    : 7;
  const end = new Date();
  const start = new Date(end.getTime() - days * 24 * 60 * 60 * 1000);
  return {
    startISO: start.toISOString(),
    endISO:   end.toISOString(),
    isoIntervalDescription: `last ${days} day${days === 1 ? '' : 's'}`,
  };
}


// ─────────────────────────────────────────────────────────────────────────────
// SLICE 4 — PREVIEW + STOP-AND-UNDO ENROLLMENT
// ─────────────────────────────────────────────────────────────────────────────

// ── POST /:id/preview — non-destructive personalisation for N prospects ─────
// Runs the dispatcher in-memory for each prospect and returns the full
// personalised steps as JSON. No DB writes to sequence_enrollments,
// sequence_step_logs, or prospects. The only side effect is skill_runs rows
// (each skill call persists for audit), which is acceptable — the rep
// triggered the run intentionally.
//
// Body:
//   { prospectIds: number[] }   // 1-5 prospect IDs
//
// Response:
//   {
//     sequenceId,
//     sequenceName,
//     previews: [{
//       prospectId,
//       prospectName,
//       prospectCompany,
//       steps: [{ step_order, channel, subject, body, task_note,
//                 personalize_sources, intent }],
//       dispatchSummary: { total, personalised, skipped, errored },
//       errors: [...]
//     }],
//     summary: { requested, succeeded, failed }
//   }
//
// HARD CAP: 5 prospects per preview to bound skill API cost (a 3-step
// sequence × 5 prospects = up to 15 Anthropic calls per preview).
//
// AI gating (mirrors bulk-activate in prospecting-campaigns.routes.js):
//   Body may include runSkill (default true) / skipPersonalisation. When AI is
//   OFF, the preview renders the sequence's subject_template / body_template
//   verbatim (same as the firer's fallback) WITHOUT calling any skill — so
//   previewing a non-AI campaign costs zero Anthropic tokens and writes no
//   skill_runs rows. This keeps Preview consistent with what activation will
//   actually do for the same toggle state.
router.post('/:id/preview', async (req, res) => {
  const { prospectIds, runSkill, skipPersonalisation } = req.body || {};
  // wantSkill is computed AFTER we load the sequence, so it can default to the
  // sequence's ai_enabled when the caller doesn't pass runSkill explicitly.
  if (!Array.isArray(prospectIds) || prospectIds.length === 0) {
    return res.status(400).json({ error: { message: 'prospectIds array is required' } });
  }
  if (prospectIds.length > 5) {
    return res.status(400).json({ error: {
      message: 'Maximum 5 prospects per preview (to bound Anthropic API cost).',
    } });
  }

  try {
    // Sequence existence + org scope
    const seqRes = await pool.query(
      `SELECT id, name, ai_enabled FROM sequences WHERE id = $1 AND org_id = $2`,
      [req.params.id, req.orgId]
    );
    if (!seqRes.rows.length) {
      return res.status(404).json({ error: { message: 'Sequence not found' } });
    }
    const sequence = seqRes.rows[0];

    // AI gating: explicit body flag wins; otherwise default to the sequence's
    // ai_enabled. skipPersonalisation is an explicit "force off" alias.
    const effectiveRunSkill = runSkill === undefined ? sequence.ai_enabled !== false : runSkill;
    const wantSkill = effectiveRunSkill !== false && skipPersonalisation !== true;

    // Validate prospects belong to this org
    const ids = prospectIds.map(x => parseInt(x, 10)).filter(Number.isFinite);
    if (ids.length === 0) {
      return res.status(400).json({ error: { message: 'No valid prospect IDs' } });
    }
    const pRes = await pool.query(
      `SELECT id, first_name, last_name, title, company_name,
              company_industry, company_domain
         FROM prospects
        WHERE id = ANY($1::int[]) AND org_id = $2 AND deleted_at IS NULL`,
      [ids, req.orgId]
    );
    if (pRes.rows.length === 0) {
      return res.status(404).json({ error: { message: 'No prospects found in this org' } });
    }
    const prospectsById = {};
    for (const p of pRes.rows) prospectsById[p.id] = p;

    // Sequence steps — needed to attach channel + intent to each preview step,
    // and (when AI is off) to render subject_template / body_template directly.
    const stepsRes = await pool.query(
      `SELECT id, step_order, channel, step_intent,
              subject_template, body_template, task_note
         FROM sequence_steps
        WHERE sequence_id = $1 AND org_id = $2
     ORDER BY step_order ASC`,
      [req.params.id, req.orgId]
    );
    const stepsByOrder = {};
    for (const s of stepsRes.rows) stepsByOrder[s.step_order] = s;

    // Resolve the executing user's default sender signature ONCE, so the modal
    // can offer a "Show with signature" preview that mirrors what the firer
    // appends at send. This is display-only; drafts stay signature-free
    // (Policy A — the model signs name-only, the platform appends at send).
    let senderSignature = null;
    try {
      const ssRows = await pool.query(
        `SELECT signature, linkedin_signature
           FROM prospecting_sender_accounts
          WHERE org_id    = $1
            AND user_id   = $2
            AND client_id IS NULL
            AND is_active = true
          ORDER BY
            (CASE WHEN last_reset_at < CURRENT_DATE THEN 0 ELSE emails_sent_today END) ASC,
            last_sent_at ASC NULLS FIRST
          LIMIT 1`,
        [req.orgId, req.user.userId]
      );
      if (ssRows.rows[0]) {
        senderSignature = {
          email_signature:    ssRows.rows[0].signature || null,
          linkedin_signature: ssRows.rows[0].linkedin_signature || null,
        };
      }
    } catch (_) { /* non-fatal — toggle simply has nothing to append */ }

    // Run dispatcher per prospect — sequentially to keep skill rate-limited.
    const previews = [];
    let succeeded = 0, failed = 0;

    for (const prospectId of ids) {
      const p = prospectsById[prospectId];
      if (!p) {
        previews.push({
          prospectId,
          prospectName: null,
          prospectCompany: null,
          error: 'Prospect not found or in another org',
          steps: [],
        });
        failed++;
        continue;
      }

      // AI OFF — render sequence templates verbatim, no skill calls, no
      // skill_runs rows, zero Anthropic tokens. This is what the firer would
      // send for this prospect when the enrollment has no personalised_steps.
      if (!wantSkill) {
        const steps = stepsRes.rows.map(s => ({
          step_order:          s.step_order,
          channel:             s.channel || null,
          subject:             renderPreviewTemplate(s.subject_template, p),
          body:                renderPreviewTemplate(s.body_template, p),
          task_note:           s.task_note || '',
          personalize_sources: { engine: 'template' },
          intent:              s.step_intent || null,
          intent_source:       s.step_intent ? 'override' : null,
        }));
        previews.push({
          prospectId,
          prospectName:    `${p.first_name || ''} ${p.last_name || ''}`.trim(),
          prospectCompany: p.company_name || null,
          steps,
          dispatchSummary: {
            total:        stepsRes.rows.length,
            personalised: 0,
            skipped:      stepsRes.rows.length,
            errored:      0,
          },
          errors: [],
        });
        succeeded++;
        continue;
      }

      try {

        // Run the dispatcher in-memory for this prospect. Mirrors the
        // bulk-activate call in prospecting-campaigns.routes.js, but the result
        // is only previewed — nothing is enrolled or sent.
        const dispatch = await PersonalizationDispatcher.personaliseEnrollment({
          orgId:      req.orgId,
          userId:     req.user.userId,
          sequenceId: req.params.id,
          prospectId,
        });

        // Flatten dispatcher's keyed map → array sorted by step_order, with
        // channel/intent metadata attached from sequence_steps for display.
        const stepOrders = Object.keys(dispatch.personalisedSteps || {})
          .map(k => parseInt(k, 10))
          .filter(Number.isFinite)
          .sort((a, b) => a - b);

        const steps = stepOrders.map(order => {
          const s = dispatch.personalisedSteps[String(order)] || {};
          const seqStep = stepsByOrder[order] || {};
          return {
            step_order:          order,
            channel:             seqStep.channel || null,
            subject:             s.subject   || '',
            body:                s.body      || '',
            task_note:           s.task_note || '',
            personalize_sources: s.personalize_sources || null,
            intent:              s.personalize_sources?.stepIntent || null,
            intent_source:       s.personalize_sources?.intentSource || null,
          };
        });

        previews.push({
          prospectId,
          prospectName:   `${p.first_name || ''} ${p.last_name || ''}`.trim(),
          prospectCompany: p.company_name || null,
          steps,
          dispatchSummary: dispatch.summary,
          errors:          dispatch.errors || [],
        });
        succeeded++;
      } catch (err) {
        console.error(`preview failed for prospect ${prospectId}:`, err);
        previews.push({
          prospectId,
          prospectName: `${p.first_name || ''} ${p.last_name || ''}`.trim(),
          prospectCompany: p.company_name || null,
          error: err.message,
          steps: [],
        });
        failed++;
      }
    }

    // ── Cost rollup ──────────────────────────────────────────────────────
    // Each personalised step carries the skill_runs id that produced it
    // (personalize_sources.runId). skill_runs already stores the authoritative
    // per-run cost_usd + token counts (SkillRunnerService.persistSkillRun), so
    // we sum those rather than re-deriving pricing here. AI-OFF previews have
    // no runIds and therefore cost exactly $0.
    const runIdByProspect = {};
    const allRunIds = [];
    for (const pv of previews) {
      for (const st of (pv.steps || [])) {
        // runId comes back as a STRING — skill_runs.id is a bigint and
        // node-postgres returns bigint columns as strings. So normalise to a
        // numeric string and validate (Number.isFinite('71') is false, which
        // is the bug this replaces). Keys are kept as strings throughout so the
        // costById lookup matches the (also-string) id the cost query returns.
        const raw = st.personalize_sources?.runId;
        if (raw == null) continue;
        const rid = String(raw).trim();
        if (!/^\d+$/.test(rid)) continue;
        allRunIds.push(rid);
        (runIdByProspect[pv.prospectId] = runIdByProspect[pv.prospectId] || []).push(rid);
      }
    }

    const costSummary = { totalCostUsd: 0, inputTokens: 0, outputTokens: 0, runCount: 0 };
    if (allRunIds.length > 0) {
      const costRes = await pool.query(
        `SELECT id, cost_usd, input_tokens, output_tokens
           FROM skill_runs
          WHERE id = ANY($1::bigint[]) AND org_id = $2`,
        [allRunIds, req.orgId]
      );
      const costById = {};
      for (const r of costRes.rows) costById[String(r.id)] = r;

      // Per-prospect rollup, attached to each preview entry.
      for (const pv of previews) {
        const rids = runIdByProspect[pv.prospectId] || [];
        let c = 0, it = 0, ot = 0;
        for (const rid of rids) {
          const row = costById[String(rid)];
          if (!row) continue;
          c  += Number(row.cost_usd)      || 0;
          it += Number(row.input_tokens)  || 0;
          ot += Number(row.output_tokens) || 0;
        }
        pv.cost = { costUsd: c, inputTokens: it, outputTokens: ot, runCount: rids.length };
      }

      // Org-wide totals for this whole preview.
      for (const row of costRes.rows) {
        costSummary.totalCostUsd += Number(row.cost_usd)      || 0;
        costSummary.inputTokens  += Number(row.input_tokens)  || 0;
        costSummary.outputTokens += Number(row.output_tokens) || 0;
      }
      costSummary.runCount = costRes.rows.length;
    }

    res.json({
      sequenceId:   parseInt(req.params.id, 10),
      sequenceName: sequence.name,
      previews,
      senderSignature,
      summary: {
        requested: ids.length,
        succeeded,
        failed,
      },
      costSummary,
    });
  } catch (err) {
    console.error('preview error:', err);
    res.status(500).json({ error: { message: 'Preview failed: ' + err.message } });
  }
});

// ── POST /enrollments/:enrollId/undo — stop AND clean up ────────────────────
// Differs from the existing /stop endpoint:
//   - /stop just sets status='stopped' (existing audit-friendly action)
//   - /undo sets status='stopped' AND discards unsent drafts AND reverts
//     prospect stage (the rep is saying "I made a mistake, undo")
//
// What gets undone:
//   - sequence_step_logs WHERE enrollment_id = X AND status IN ('draft','scheduled') → deleted
//   - prospects.stage reverts to 'research' (or 'target' if no research_notes)
//   - sequence_enrollments.status = 'stopped' with stop_reason = 'undone'
//
// What does NOT get undone:
//   - Already-sent emails (status='sent') — cannot recall outbound mail
//   - Already-logged LinkedIn touches (prospecting_activities rows)
//   - The enrollment row itself — kept for audit (status='stopped')
//
// The rep can re-enroll the prospect fresh after undo (the bulk-activate
// candidate query filters out 'active'/'paused' enrollments, so 'stopped'
// enrollments don't block re-enrollment).
// Per-enrollment undo, run inside an already-open transaction (caller owns
// BEGIN/COMMIT). Mirrors the single-undo behavior exactly so bulk and single
// can't drift: lock row, discard unsent drafts, stop enrollment (stop_reason=
// 'undone'), revert stage if still in 'outreach', log audit row. Returns a
// per-enrollment result. Throws on hard failure (caller rolls back).
async function undoEnrollmentTx(client, orgId, userId, enrollId) {
  const eRes = await client.query(
    `SELECT id, prospect_id, sequence_id, status
       FROM sequence_enrollments
      WHERE id = $1 AND org_id = $2
      FOR UPDATE`,
    [enrollId, orgId]
  );
  if (!eRes.rows.length) {
    return { enrollmentId: Number(enrollId), notFound: true };
  }
  const enrollment = eRes.rows[0];

  if (['stopped', 'completed'].includes(enrollment.status)) {
    return {
      enrollmentId: enrollment.id, wasAlreadyTerminal: true,
      status: enrollment.status, draftsDiscarded: 0, stageReverted: null,
    };
  }

  const draftRes = await client.query(
    `DELETE FROM sequence_step_logs
      WHERE enrollment_id = $1 AND org_id = $2 AND status IN ('draft','scheduled')
    RETURNING id`,
    [enrollment.id, orgId]
  );
  const draftsDiscarded = draftRes.rowCount;

  await client.query(
    `UPDATE sequence_enrollments
        SET status = 'stopped', stopped_at = NOW(), stop_reason = 'undone'
      WHERE id = $1 AND org_id = $2`,
    [enrollment.id, orgId]
  );

  const pRes = await client.query(
    `SELECT id, stage, research_notes, research_meta
       FROM prospects WHERE id = $1 AND org_id = $2`,
    [enrollment.prospect_id, orgId]
  );
  let stageReverted = null;
  if (pRes.rows.length && pRes.rows[0].stage === 'outreach') {
    const hadResearch = !!(
      pRes.rows[0].research_notes ||
      (pRes.rows[0].research_meta && (
        pRes.rows[0].research_meta.signal_summary ||
        pRes.rows[0].research_meta.researchBullets
      ))
    );
    const newStage = hadResearch ? 'research' : 'target';
    await client.query(
      `UPDATE prospects
          SET stage = $3, stage_changed_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
        WHERE id = $1 AND org_id = $2`,
      [enrollment.prospect_id, orgId, newStage]
    );
    stageReverted = newStage;
  }

  try {
    await client.query(
      `INSERT INTO prospecting_activities
                   (org_id, prospect_id, user_id, activity_type, description, metadata)
            VALUES ($1, $2, $3, 'enrollment_undone', $4, $5::jsonb)`,
      [
        orgId, enrollment.prospect_id, userId,
        `Enrollment undone — ${draftsDiscarded} draft(s) discarded` +
          (stageReverted ? `, stage reverted to '${stageReverted}'` : ''),
        JSON.stringify({
          enrollmentId: enrollment.id, sequenceId: enrollment.sequence_id,
          draftsDiscarded, stageReverted,
        }),
      ]
    );
  } catch (actErr) {
    console.warn('undo: activity log failed:', actErr.message);
  }

  return {
    enrollmentId: enrollment.id, wasAlreadyTerminal: false,
    status: 'stopped', draftsDiscarded, stageReverted,
  };
}

router.post('/enrollments/:enrollId/undo', async (req, res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await undoEnrollmentTx(client, req.orgId, req.user.userId, req.params.enrollId);
    if (result.notFound) {
      await client.query('ROLLBACK');
      return res.status(404).json({ error: { message: 'Enrollment not found' } });
    }
    await client.query('COMMIT');
    res.json(result);
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('enrollment undo error:', err);
    res.status(500).json({ error: { message: 'Undo failed: ' + err.message } });
  } finally {
    client.release();
  }
});

// ── POST /enrollments/bulk-undo ──────────────────────────────────────────────
// Bulk version of /undo. Body: { enrollmentIds: [1,2,3] }. Each is undone with
// the SAME per-enrollment logic. All in ONE transaction — if any hard-fails,
// nothing commits (all-or-nothing), so the rep never lands in a half-undone
// state. Already-terminal enrollments are skipped (reported, not errored).
router.post('/enrollments/bulk-undo', async (req, res) => {
  const { enrollmentIds } = req.body;
  if (!Array.isArray(enrollmentIds) || enrollmentIds.length === 0) {
    return res.status(400).json({ error: { message: 'enrollmentIds must be a non-empty array' } });
  }
  if (enrollmentIds.length > 500) {
    return res.status(400).json({ error: { message: 'Too many at once (max 500)' } });
  }
  const ids = [...new Set(enrollmentIds.map(n => parseInt(n, 10)).filter(Number.isFinite))];
  if (!ids.length) {
    return res.status(400).json({ error: { message: 'No valid enrollmentIds' } });
  }

  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const results = [];
    for (const id of ids) {
      results.push(await undoEnrollmentTx(client, req.orgId, req.user.userId, id));
    }
    await client.query('COMMIT');
    const undone          = results.filter(r => !r.notFound && !r.wasAlreadyTerminal).length;
    const skipped         = results.filter(r => r.wasAlreadyTerminal).length;
    const notFound        = results.filter(r => r.notFound).length;
    const draftsDiscarded = results.reduce((a, r) => a + (r.draftsDiscarded || 0), 0);
    res.json({
      requested: ids.length, undone, skippedAlreadyTerminal: skipped, notFound,
      draftsDiscarded, results,
    });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error('bulk-undo error:', err);
    res.status(500).json({ error: { message: 'Bulk undo failed (nothing was changed): ' + err.message } });
  } finally {
    client.release();
  }
});


module.exports = router;
