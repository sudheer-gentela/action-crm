const express = require('express');
const router = express.Router();
const db = require('../config/database');
const authenticateToken = require('../middleware/auth.middleware');
const { orgContext } = require('../middleware/orgContext.middleware');
const { workflowRulesMiddleware } = require('../middleware/workflowRules.middleware');

router.use(authenticateToken);
router.use(orgContext);

// ── GET / — list contacts ─────────────────────────────────────
// Supports ?scope=mine|team|org (default: mine)
//   mine — contacts on accounts owned by the current user
//   team — contacts on accounts owned by user + subordinates
//   org  — all contacts in the org
// OLD isolation: WHERE acc.owner_id = $1 (broken — contacts can
//   exist on accounts owned by other users in the same org)
// NEW isolation: WHERE c.org_id = $1 (correct org-level scope)
router.get('/', async (req, res) => {
  try {
    const { roleType, engagementLevel, scope = 'mine' } = req.query;

    let query = `
      SELECT
        c.*,
        acc.name as account_name,
        acc.id   as account_id,
        json_agg(
          json_build_object('id', d.id, 'name', d.name, 'value', d.value, 'stage', d.stage)
        ) FILTER (WHERE d.id IS NOT NULL) as deals
      FROM contacts c
      LEFT JOIN accounts acc ON c.account_id = acc.id
      LEFT JOIN deal_contacts dc ON c.id = dc.contact_id
      LEFT JOIN deals d ON dc.deal_id = d.id AND d.org_id = $1
      WHERE c.org_id = $1 AND c.deleted_at IS NULL
    `;

    const params = [req.orgId];

    // Scope filtering via account ownership
    if (scope === 'team' && req.subordinateIds?.length > 0) {
      const teamIds = [req.user.userId, ...req.subordinateIds];
      query += ` AND (c.account_id IS NULL OR c.account_id IN (SELECT id FROM accounts WHERE org_id = $1 AND owner_id = ANY($${params.length + 1}::int[])))`;
      params.push(teamIds);
    } else if (scope === 'org') {
      // No additional filter — all contacts in org
    } else {
      // Default: mine — contacts on my accounts + unassigned contacts
      query += ` AND (c.account_id IS NULL OR c.account_id IN (SELECT id FROM accounts WHERE org_id = $1 AND owner_id = $${params.length + 1}))`;
      params.push(req.user.userId);
    }

    if (roleType) {
      query += ` AND c.role_type = $${params.length + 1}`;
      params.push(roleType);
    }

    if (engagementLevel) {
      query += ` AND c.engagement_level = $${params.length + 1}`;
      params.push(engagementLevel);
    }

    query += ' GROUP BY c.id, acc.id ORDER BY c.last_contact_date DESC NULLS LAST';

    const result = await db.query(query, params);

    res.json({
      contacts: result.rows.map(row => ({
        ...row,
        account: { id: row.account_id, name: row.account_name },
        deals:   row.deals || []
      }))
    });
  } catch (error) {
    console.error('Get contacts error:', error);
    res.status(500).json({ error: { message: 'Failed to fetch contacts' } });
  }
});

// ── GET /duplicates — find duplicate contact groups in this org ────────────────
// NOTE: Must be registered BEFORE /:id so Express doesn't treat "duplicates" as an id
router.get('/duplicates', async (req, res) => {
  try {
    // ── Read org-level duplicate detection settings ──────────
    const orgRes = await db.query(`SELECT settings FROM organizations WHERE id = $1`, [req.orgId]);
    const settings = orgRes.rows[0]?.settings || {};
    const dedupConfig = settings.duplicate_detection || {};

    // Enabled rules (default: all on)
    const emailMatchEnabled       = dedupConfig.contact_email_match !== false;
    const nameAccountMatchEnabled = dedupConfig.contact_name_account_match !== false;

    // Visibility: 'org' (default) = all contacts in org; 'own' = only user's contacts
    const visibility = dedupConfig.contact_visibility || 'org';

    // Build the scope filter
    let scopeFilter = `c.org_id = $1 AND c.deleted_at IS NULL`;
    const scopeParams = [req.orgId];
    if (visibility === 'own') {
      // contacts don't have owner_id — scope via account ownership
      scopeFilter += ` AND c.account_id IN (SELECT id FROM accounts WHERE owner_id = $${scopeParams.length + 1} AND org_id = $1)`;
      scopeParams.push(req.user.userId);
    }

    const groups = [];
    const seenPairs = new Set();

    // Group 1: Same email (case-insensitive)
    if (emailMatchEnabled) {
      const emailDupes = await db.query(
        `SELECT LOWER(email) AS match_key, 'email' AS match_type,
                json_agg(
                  json_build_object(
                    'id', c.id, 'first_name', c.first_name, 'last_name', c.last_name,
                    'email', c.email, 'phone', c.phone, 'title', c.title,
                    'role_type', c.role_type, 'engagement_level', c.engagement_level,
                    'location', c.location, 'linkedin_url', c.linkedin_url,
                    'notes', c.notes, 'account_id', c.account_id,
                    'account_name', acc.name, 'last_contact_date', c.last_contact_date,
                    'created_at', c.created_at
                  ) ORDER BY c.created_at ASC
                ) AS contacts
         FROM contacts c
         LEFT JOIN accounts acc ON acc.id = c.account_id
         WHERE ${scopeFilter}
           AND c.email IS NOT NULL AND c.email != ''
         GROUP BY LOWER(c.email)
         HAVING COUNT(*) > 1`,
        scopeParams
      );
      for (const row of emailDupes.rows) {
        const ids = row.contacts.map(c => c.id).sort().join(',');
        if (!seenPairs.has(ids)) {
          seenPairs.add(ids);
          groups.push({ matchType: row.match_type, matchKey: row.match_key, contacts: row.contacts });
        }
      }
    }

    // Group 2: Same first+last name on same account
    if (nameAccountMatchEnabled) {
      const nameDupes = await db.query(
        `SELECT LOWER(c.first_name) || '|' || LOWER(c.last_name) || '|' || c.account_id AS match_key,
                'name_account' AS match_type,
                json_agg(
                  json_build_object(
                    'id', c.id, 'first_name', c.first_name, 'last_name', c.last_name,
                    'email', c.email, 'phone', c.phone, 'title', c.title,
                    'role_type', c.role_type, 'engagement_level', c.engagement_level,
                    'location', c.location, 'linkedin_url', c.linkedin_url,
                    'notes', c.notes, 'account_id', c.account_id,
                    'account_name', acc.name, 'last_contact_date', c.last_contact_date,
                    'created_at', c.created_at
                  ) ORDER BY c.created_at ASC
                ) AS contacts
         FROM contacts c
         LEFT JOIN accounts acc ON acc.id = c.account_id
         WHERE ${scopeFilter}
           AND c.account_id IS NOT NULL
         GROUP BY LOWER(c.first_name), LOWER(c.last_name), c.account_id
         HAVING COUNT(*) > 1`,
        scopeParams
      );
      for (const row of nameDupes.rows) {
        const ids = row.contacts.map(c => c.id).sort().join(',');
        if (!seenPairs.has(ids)) {
          seenPairs.add(ids);
          groups.push({ matchType: row.match_type, matchKey: row.match_key, contacts: row.contacts });
        }
      }
    }

    res.json({ duplicateGroups: groups, totalGroups: groups.length });
  } catch (error) {
    console.error('Get duplicates error:', error);
    res.status(500).json({ error: { message: 'Failed to find duplicates' } });
  }
});

// ── POST /merge — merge two contacts ──────────────────────────────────────────
// NOTE: Must be registered BEFORE /:id
router.post('/merge', async (req, res) => {
  const client = await (db.pool ? db.pool.connect() : db.connect());
  try {
    const { fieldOverrides = {} } = req.body;
    // Coerce to integers up front. The IN ($1,$2) query matches even when the
    // client sends "12" (pg casts), but the later rows.find(r => r.id === keepId)
    // strict-compares a DB integer against the raw client type — a string id
    // makes find() return undefined and the next line throws a 500. Parsing
    // here also makes the self-merge guard reliable.
    const keepId   = parseInt(req.body.keepId, 10);
    const removeId = parseInt(req.body.removeId, 10);
    if (!Number.isInteger(keepId) || !Number.isInteger(removeId)) {
      return res.status(400).json({ error: { message: 'keepId and removeId are required' } });
    }
    if (keepId === removeId) {
      return res.status(400).json({ error: { message: 'Cannot merge a contact with itself' } });
    }

    const bothRes = await client.query(
      `SELECT id, first_name, last_name, email, phone, title, role_type,
              engagement_level, location, linkedin_url, notes, account_id, org_id
       FROM contacts WHERE id IN ($1, $2) AND org_id = $3 AND deleted_at IS NULL`,
      [keepId, removeId, req.orgId]
    );
    if (bothRes.rows.length !== 2) {
      return res.status(404).json({ error: { message: 'One or both contacts not found in this org' } });
    }
    const keepContact   = bothRes.rows.find(r => r.id === keepId);
    const removeContact = bothRes.rows.find(r => r.id === removeId);

    // Double-check org_id on both
    if (keepContact.org_id !== req.orgId || removeContact.org_id !== req.orgId) {
      return res.status(403).json({ error: { message: 'Cannot merge contacts from different organisations' } });
    }

    await client.query('BEGIN');

    // 0. Archive removed contact for recovery
    await client.query(`
      CREATE TABLE IF NOT EXISTS merged_contacts_archive (
        id              SERIAL PRIMARY KEY,
        original_id     INTEGER NOT NULL,
        merged_into_id  INTEGER NOT NULL,
        org_id          INTEGER NOT NULL,
        contact_data    JSONB NOT NULL,
        merged_by       INTEGER,
        field_overrides JSONB DEFAULT '{}',
        merged_at       TIMESTAMPTZ DEFAULT NOW()
      )
    `);
    await client.query(`
      INSERT INTO merged_contacts_archive (original_id, merged_into_id, org_id, contact_data, merged_by, field_overrides)
      VALUES ($1, $2, $3, $4, $5, $6)
    `, [removeId, keepId, req.orgId, JSON.stringify(removeContact), req.user.userId, JSON.stringify(fieldOverrides)]);

    const overridableFields = [
      'first_name', 'last_name', 'email', 'phone', 'title', 'role_type',
      'engagement_level', 'location', 'linkedin_url', 'notes', 'account_id'
    ];
    const updates = [];
    const values  = [];
    let paramIdx  = 1;

    for (const field of overridableFields) {
      if (fieldOverrides[field] === 'from_remove' && removeContact[field]) {
        updates.push(`${field} = $${paramIdx}`);
        values.push(removeContact[field]);
        paramIdx++;
      }
    }

    if (updates.length > 0) {
      values.push(keepId, req.orgId);
      await client.query(
        `UPDATE contacts SET ${updates.join(', ')}, updated_at = CURRENT_TIMESTAMP
         WHERE id = $${paramIdx} AND org_id = $${paramIdx + 1}`,
        values
      );
    }

    // Move deal_contacts — scoped via deal org_id
    await client.query(
      `INSERT INTO deal_contacts (deal_id, contact_id, role)
       SELECT dc.deal_id, $1, dc.role FROM deal_contacts dc
       JOIN deals d ON d.id = dc.deal_id AND d.org_id = $3
       WHERE dc.contact_id = $2
         AND dc.deal_id NOT IN (SELECT deal_id FROM deal_contacts WHERE contact_id = $1)
       ON CONFLICT (deal_id, contact_id) DO NOTHING`,
      [keepId, removeId, req.orgId]
    );

    // Move emails — scoped to org
    await client.query(
      `UPDATE emails SET contact_id = $1 WHERE contact_id = $2 AND org_id = $3`,
      [keepId, removeId, req.orgId]
    );

    // Move meeting_attendees — scoped via meeting org
    await client.query(
      `UPDATE meeting_attendees SET contact_id = $1
       WHERE contact_id = $2
         AND meeting_id IN (SELECT id FROM meetings WHERE org_id = $3)
         AND meeting_id NOT IN (SELECT meeting_id FROM meeting_attendees WHERE contact_id = $1)`,
      [keepId, removeId, req.orgId]
    );
    await client.query(
      `DELETE FROM meeting_attendees WHERE contact_id = $1
       AND meeting_id IN (SELECT id FROM meetings WHERE org_id = $2)`,
      [removeId, req.orgId]
    );

    // Move contact_activities — scoped via contact org check (contact already verified)
    await client.query(`UPDATE contact_activities SET contact_id = $1 WHERE contact_id = $2`, [keepId, removeId]);

    // Move conversation_starters
    await client.query(`UPDATE conversation_starters SET contact_id = $1 WHERE contact_id = $2`, [keepId, removeId]);

    // Move actions — scoped to org
    await client.query(
      `UPDATE actions SET contact_id = $1 WHERE contact_id = $2 AND org_id = $3`,
      [keepId, removeId, req.orgId]
    );

    // Move economic_buyer references on deals — scoped to org
    await client.query(
      `UPDATE deals SET economic_buyer_contact_id = $1 WHERE economic_buyer_contact_id = $2 AND org_id = $3`,
      [keepId, removeId, req.orgId]
    );

    // Move storage_files — scoped to org
    await client.query(
      `UPDATE storage_files SET contact_id = $1 WHERE contact_id = $2 AND org_id = $3`,
      [keepId, removeId, req.orgId]
    );

    // Clean up remaining deal_contacts for removed contact (org-scoped)
    await client.query(
      `DELETE FROM deal_contacts WHERE contact_id = $1
       AND deal_id IN (SELECT id FROM deals WHERE org_id = $2)`,
      [removeId, req.orgId]
    );

    // Soft-delete the removed contact
    await client.query(
      `UPDATE contacts SET deleted_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
       WHERE id = $1 AND org_id = $2`,
      [removeId, req.orgId]
    );

    await client.query('COMMIT');

    console.log(`🔗 Contact merge: kept #${keepId}, removed #${removeId} (org ${req.orgId}). Archived for recovery.`);

    const updatedRes = await db.query(
      `SELECT c.*, acc.name as account_name FROM contacts c
       LEFT JOIN accounts acc ON acc.id = c.account_id WHERE c.id = $1`,
      [keepId]
    );

    res.json({ success: true, mergedContact: updatedRes.rows[0], removedId: removeId });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('Merge contacts error:', error);
    res.status(500).json({ error: { message: 'Failed to merge contacts' } });
  } finally {
    client.release();
  }
});

// ── POST /bulk — bulk-create contacts from CSV import ────────────────────────
// Body: { rows: [{ firstName, lastName, email, phone?, title?, roleType?, location?, linkedinUrl?, notes?, accountId? }] }
// Returns: { imported: number, contacts: [], errors: [{ row, message }] }
router.post('/bulk', async (req, res) => {
  try {
    const { rows } = req.body;
    if (!Array.isArray(rows) || rows.length === 0) {
      return res.status(400).json({ error: { message: 'rows array is required' } });
    }

    const MAX_ROWS = 500;
    if (rows.length > MAX_ROWS) {
      return res.status(400).json({ error: { message: `Maximum ${MAX_ROWS} rows per import` } });
    }

    const imported = [];
    const errors = [];

    for (let i = 0; i < rows.length; i++) {
      const row = rows[i];
      const rowNum = i + 2;
      try {
        if (!row.firstName?.trim() || !row.lastName?.trim()) {
          errors.push({ row: rowNum, message: 'First name and last name are required' });
          continue;
        }
        if (!row.email?.trim()) {
          errors.push({ row: rowNum, message: 'Email is required' });
          continue;
        }

        const result = await db.query(
          `INSERT INTO contacts
             (org_id, account_id, first_name, last_name, email, phone, title, role_type, location, linkedin_url, notes)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) RETURNING *`,
          [req.orgId, row.accountId || null, row.firstName.trim(), row.lastName.trim(),
           row.email.trim(), row.phone || null, row.title || null, row.roleType || null,
           row.location || null, row.linkedinUrl || null, row.notes || null]
        );
        imported.push(result.rows[0]);
      } catch (err) {
        if (err.code === '23505') {
          errors.push({ row: rowNum, message: `Duplicate contact: ${row.email}` });
        } else if (err.code === '23503') {
          errors.push({ row: rowNum, message: `Invalid account ID: ${row.accountId}` });
        } else {
          errors.push({ row: rowNum, message: err.message });
        }
      }
    }

    console.log(`📥 Bulk contact import: ${imported.length} imported, ${errors.length} errors (org ${req.orgId})`);
    res.json({ imported: imported.length, contacts: imported, errors });
  } catch (error) {
    console.error('Bulk contact import error:', error);
    res.status(500).json({ error: { message: 'Failed to bulk import contacts' } });
  }
});

// ── GET /:id ──────────────────────────────────────────────────
router.get('/:id', async (req, res) => {
  try {
    const contactQuery = await db.query(
      `SELECT c.*, acc.name as account_name, acc.id as account_id
       FROM contacts c
       LEFT JOIN accounts acc ON c.account_id = acc.id
       WHERE c.id = $1 AND c.org_id = $2`,
      [req.params.id, req.orgId]
    );

    if (contactQuery.rows.length === 0) {
      return res.status(404).json({ error: { message: 'Contact not found' } });
    }

    const contact = contactQuery.rows[0];

    const [activitiesQuery, startersQuery] = await Promise.all([
      db.query(
        `SELECT id, activity_type, description, metadata, created_at, 'crm' AS source
         FROM contact_activities
         WHERE contact_id = $1
         UNION ALL
         SELECT pa.id, pa.activity_type, pa.description,
                pa.metadata || jsonb_build_object('source', 'prospecting', 'prospect_id', pa.prospect_id) AS metadata,
                pa.created_at, 'prospecting' AS source
         FROM prospecting_activities pa
         JOIN contacts c ON c.converted_from_prospect_id = pa.prospect_id
         WHERE c.id = $1
           AND pa.activity_type IN (
             'outreach_sent', 'response_received', 'stage_change',
             'call_completed', 'meeting_booked', 'converted',
             'email_sent', 'linkedin_sent', 'note_added'
           )
         ORDER BY created_at DESC
         LIMIT 50`,
        [req.params.id]
      ),
      db.query(
        `SELECT * FROM conversation_starters
         WHERE contact_id = $1 AND (expires_at IS NULL OR expires_at > CURRENT_TIMESTAMP)
         ORDER BY relevance_score DESC LIMIT 5`,
        [req.params.id]
      ),
    ]);

    res.json({
      contact: {
        ...contact,
        account:              { id: contact.account_id, name: contact.account_name },
        activities:           activitiesQuery.rows,
        conversationStarters: startersQuery.rows
      }
    });
  } catch (error) {
    console.error('Get contact error:', error);
    res.status(500).json({ error: { message: 'Failed to fetch contact' } });
  }
});

// ── POST / — create contact ───────────────────────────────────
router.post('/', workflowRulesMiddleware('contact', 'create'), async (req, res) => {
  try {
    const p = req.mutatedPayload || req.body;
    const { accountId, firstName, lastName, email, phone, title, roleType, location, linkedinUrl, notes } = p;

    // ── Duplicate prevention ────────────────────────────────────
    // Check 1: same email in this org
    if (email) {
      const emailDup = await db.query(
        `SELECT id, first_name, last_name, email FROM contacts
         WHERE org_id = $1 AND LOWER(email) = LOWER($2)`,
        [req.orgId, email]
      );
      if (emailDup.rows.length > 0) {
        const dup = emailDup.rows[0];
        return res.status(409).json({
          error: {
            message: `A contact with email "${email}" already exists: ${dup.first_name} ${dup.last_name} (ID ${dup.id})`,
            code: 'DUPLICATE_EMAIL',
            existingContactId: dup.id,
          }
        });
      }
    }
    // Check 2: same first+last name on the same account
    if (firstName && lastName && accountId) {
      const nameDup = await db.query(
        `SELECT id, first_name, last_name, email FROM contacts
         WHERE org_id = $1
           AND LOWER(first_name) = LOWER($2)
           AND LOWER(last_name)  = LOWER($3)
           AND account_id = $4`,
        [req.orgId, firstName, lastName, accountId]
      );
      if (nameDup.rows.length > 0) {
        const dup = nameDup.rows[0];
        return res.status(409).json({
          error: {
            message: `A contact named "${firstName} ${lastName}" already exists on this account: ${dup.email || 'no email'} (ID ${dup.id})`,
            code: 'DUPLICATE_NAME_ACCOUNT',
            existingContactId: dup.id,
          }
        });
      }
    }

    const result = await db.query(
      `INSERT INTO contacts
         (org_id, account_id, first_name, last_name, email, phone, title, role_type, location, linkedin_url, notes)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) RETURNING *`,
      [req.orgId, accountId, firstName, lastName, email, phone, title, roleType, location, linkedinUrl, notes]
    );

    const response = { contact: result.rows[0] };
    if (req.ruleWarnings?.length > 0) response.warnings = req.ruleWarnings;
    res.status(201).json(response);
  } catch (error) {
    console.error('Create contact error:', error);
    res.status(500).json({ error: { message: 'Failed to create contact' } });
  }
});

// ── PUT /:id — update contact ─────────────────────────────────
router.put('/:id', workflowRulesMiddleware('contact', 'update'), async (req, res) => {
  try {
    const p = req.mutatedPayload || req.body;
    const { firstName, lastName, email, phone, title, roleType, engagementLevel, location, linkedinUrl, notes, accountId } = p;

    // Convert empty strings to null so COALESCE can fall back to the existing value.
    // To actually clear a field, the frontend should send null explicitly.
    const toParam = (v) => (v === undefined ? undefined : (v === '' ? null : v));

    // Build dynamic SET clause — only include fields that were actually sent
    const fields = [];
    const values = [];
    let idx = 1;

    const maybeSet = (col, val) => {
      if (val !== undefined) {
        fields.push(`${col} = $${idx++}`);
        values.push(val);
      }
    };

    maybeSet('first_name',       firstName);
    maybeSet('last_name',        lastName);
    maybeSet('email',            email);
    maybeSet('phone',            toParam(phone));
    maybeSet('title',            toParam(title));
    maybeSet('role_type',        toParam(roleType));
    maybeSet('engagement_level', toParam(engagementLevel));
    maybeSet('location',         toParam(location));
    maybeSet('linkedin_url',     toParam(linkedinUrl));
    maybeSet('notes',            toParam(notes));
    maybeSet('account_id',       accountId || undefined);

    if (fields.length === 0) {
      return res.status(400).json({ error: { message: 'No fields to update' } });
    }

    fields.push('updated_at = CURRENT_TIMESTAMP');

    values.push(req.params.id, req.orgId);
    const whereClause = `WHERE id = $${idx++} AND org_id = $${idx}`;

    const result = await db.query(
      `UPDATE contacts SET ${fields.join(', ')} ${whereClause} RETURNING *`,
      values
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: { message: 'Contact not found' } });
    }

    const putResponse = { contact: result.rows[0] };
    if (req.ruleWarnings?.length > 0) putResponse.warnings = req.ruleWarnings;
    res.json(putResponse);
  } catch (error) {
    console.error('Update contact error:', error);
    res.status(500).json({ error: { message: 'Failed to update contact' } });
  }
});

// ── POST /:id/activities — log activity ───────────────────────
router.post('/:id/activities', async (req, res) => {
  try {
    const { activityType, description, metadata } = req.body;

    // Verify contact belongs to this org before logging
    const check = await db.query(
      'SELECT id FROM contacts WHERE id = $1 AND org_id = $2',
      [req.params.id, req.orgId]
    );
    if (check.rows.length === 0) {
      return res.status(404).json({ error: { message: 'Contact not found' } });
    }

    await db.query(
      `INSERT INTO contact_activities (contact_id, user_id, activity_type, description, metadata)
       VALUES ($1, $2, $3, $4, $5)`,
      [req.params.id, req.user.userId, activityType, description, metadata]
    );

    await db.query(
      'UPDATE contacts SET last_contact_date = CURRENT_TIMESTAMP WHERE id = $1',
      [req.params.id]
    );

    res.status(201).json({ message: 'Activity logged' });
  } catch (error) {
    console.error('Log activity error:', error);
    res.status(500).json({ error: { message: 'Failed to log activity' } });
  }
});

// ── POST /:id/snooze-email — snooze email tagging for this contact ────────────
// Emails from this contact won't appear in the untagged email tagging prompts.
router.post('/:id/snooze-email', async (req, res) => {
  try {
    const { reason } = req.body;

    const result = await db.query(
      `UPDATE contacts
       SET email_snoozed       = true,
           email_snoozed_at    = CURRENT_TIMESTAMP,
           email_snoozed_by    = $1,
           email_snooze_reason = $2,
           updated_at          = CURRENT_TIMESTAMP
       WHERE id = $3 AND org_id = $4
       RETURNING id, first_name, last_name, email_snoozed, email_snooze_reason`,
      [req.user.userId, reason || null, req.params.id, req.orgId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: { message: 'Contact not found' } });
    }

    res.json({ contact: result.rows[0] });
  } catch (err) {
    console.error('Snooze contact email error:', err);
    res.status(500).json({ error: { message: 'Failed to snooze contact' } });
  }
});

// ── POST /:id/unsnooze-email — remove email snooze from contact ───────────────
router.post('/:id/unsnooze-email', async (req, res) => {
  try {
    const result = await db.query(
      `UPDATE contacts
       SET email_snoozed       = false,
           email_snoozed_at    = NULL,
           email_snoozed_by    = NULL,
           email_snooze_reason = NULL,
           updated_at          = CURRENT_TIMESTAMP
       WHERE id = $1 AND org_id = $2
       RETURNING id, first_name, last_name, email_snoozed`,
      [req.params.id, req.orgId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: { message: 'Contact not found' } });
    }

    res.json({ contact: result.rows[0] });
  } catch (err) {
    console.error('Unsnooze contact email error:', err);
    res.status(500).json({ error: { message: 'Failed to unsnooze contact' } });
  }
});

// ── DELETE /:id — soft-delete contact ────────────────────────
router.delete('/:id', async (req, res) => {
  try {
    const result = await db.query(
      `UPDATE contacts SET deleted_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
       WHERE id = $1 AND org_id = $2 AND deleted_at IS NULL
       RETURNING id`,
      [req.params.id, req.orgId]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: { message: 'Contact not found' } });
    }

    res.json({ message: 'Contact deleted' });
  } catch (error) {
    console.error('Delete contact error:', error);
    res.status(500).json({ error: { message: 'Failed to delete contact' } });
  }
});

module.exports = router;
