// ─────────────────────────────────────────────────────────────────────────────
// superAdmin.routes.js
//
// Mount in server.js:
//   app.use('/api/super', require('./routes/superAdmin.routes'));
//
// All routes require: authenticateToken + requireSuperAdmin
// ─────────────────────────────────────────────────────────────────────────────

const express = require('express');
const router  = express.Router();
const bcrypt  = require('bcryptjs');
const crypto  = require('crypto');
const jwt     = require('jsonwebtoken');
const { pool } = require('../config/database');
const authenticateToken = require('../middleware/auth.middleware');
const { requireSuperAdmin, auditLog } = require('../middleware/superAdmin.middleware');
const { seedOrg } = require('../services/orgSeed.service');

// Apply auth + super admin guard to ALL routes in this file
router.use(authenticateToken, requireSuperAdmin);

// ═════════════════════════════════════════════════════════════════════════════
// PLATFORM STATS (dashboard overview)
// ═════════════════════════════════════════════════════════════════════════════

router.get('/stats', async (req, res) => {
  try {
    const [orgStats, userStats, activityStats] = await Promise.all([
      pool.query(`
        SELECT
          COUNT(*)                                            AS total_orgs,
          COUNT(*) FILTER (WHERE status = 'active')          AS active_orgs,
          COUNT(*) FILTER (WHERE status = 'suspended')       AS suspended_orgs,
          COUNT(*) FILTER (WHERE status = 'trial')           AS trial_orgs,
          COUNT(*) FILTER (WHERE created_at > now() - interval '30 days') AS new_orgs_30d
        FROM organizations
      `),
      pool.query(`
        SELECT
          COUNT(*)                                                       AS total_users,
          COUNT(*) FILTER (WHERE ou.is_active = TRUE)                   AS active_users,
          COUNT(DISTINCT ou.user_id) FILTER (WHERE ou.joined_at > now() - interval '30 days') AS new_users_30d
        FROM org_users ou
      `),
      pool.query(`
        SELECT
          COUNT(*) FILTER (WHERE created_at > now() - interval '24 hours') AS actions_24h,
          COUNT(*) FILTER (WHERE created_at > now() - interval '7 days')   AS actions_7d
        FROM actions
      `),
    ]);

    res.json({
      orgs:     orgStats.rows[0],
      users:    userStats.rows[0],
      activity: activityStats.rows[0],
    });
  } catch (err) {
    console.error('GET /super/stats error:', err);
    res.status(500).json({ error: { message: err.message } });
  }
});

// ═════════════════════════════════════════════════════════════════════════════
// ORGANISATIONS — CRUD
// ═════════════════════════════════════════════════════════════════════════════

// List all orgs with member count
router.get('/orgs', async (req, res) => {
  try {
    const { search = '', status = '', plan = '', page = 1, limit = 25 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);

    const conditions = ['1=1'];
    const params     = [];
    let   p          = 1;

    if (search) {
      conditions.push(`o.name ILIKE $${p++}`);
      params.push(`%${search}%`);
    }
    if (status) {
      conditions.push(`o.status = $${p++}`);
      params.push(status);
    }
    if (plan) {
      conditions.push(`o.plan = $${p++}`);
      params.push(plan);
    }

    const where = conditions.join(' AND ');

    const [rows, countRow] = await Promise.all([
      pool.query(`
        SELECT
          o.id, o.name, o.status, o.plan, o.max_users,
          o.notes, o.created_at, o.suspended_at,
          COUNT(ou.user_id) FILTER (WHERE ou.is_active = TRUE) AS member_count,
          MAX(CASE WHEN ou.role = 'owner' THEN u.email END)    AS owner_email
        FROM organizations o
        LEFT JOIN org_users ou ON ou.org_id = o.id
        LEFT JOIN users u      ON u.id = ou.user_id AND ou.role = 'owner'
        WHERE ${where}
        GROUP BY o.id
        ORDER BY o.created_at DESC
        LIMIT $${p++} OFFSET $${p++}
      `, [...params, parseInt(limit), offset]),

      pool.query(`
        SELECT COUNT(*) AS total FROM organizations o WHERE ${where}
      `, params),
    ]);

    res.json({
      orgs:  rows.rows,
      total: parseInt(countRow.rows[0].total),
      page:  parseInt(page),
      limit: parseInt(limit),
    });
  } catch (err) {
    console.error('GET /super/orgs error:', err);
    res.status(500).json({ error: { message: err.message } });
  }
});

// Get single org with full detail
router.get('/orgs/:orgId', async (req, res) => {
  try {
    const { orgId } = req.params;

    // org_integrations may not exist yet — query gracefully
    let integrations = { rows: [] };
    try {
      integrations = await pool.query(`
        SELECT * FROM org_integrations WHERE org_id = $1
      `, [orgId]);
    } catch (_) { /* table may not exist yet */ }

    const [org, members] = await Promise.all([
      pool.query(`
        SELECT o.*, u.email AS suspended_by_email
        FROM   organizations o
        LEFT JOIN users u ON u.id = o.suspended_by
        WHERE  o.id = $1
      `, [orgId]),

      pool.query(`
        SELECT ou.user_id, ou.role, ou.is_active, ou.joined_at,
               u.email, u.first_name || ' ' || u.last_name AS name
        FROM   org_users ou
        JOIN   users u ON u.id = ou.user_id
        WHERE  ou.org_id = $1
        ORDER  BY ou.role, u.first_name
      `, [orgId]),
    ]);

    if (org.rows.length === 0) {
      return res.status(404).json({ error: { message: 'Organisation not found' } });
    }

    res.json({ org: org.rows[0], members: members.rows, integrations: integrations.rows });
  } catch (err) {
    console.error(`GET /super/orgs/${req.params.orgId} error:`, err);
    res.status(500).json({ error: { message: err.message } });
  }
});

// Create a new org
router.post('/orgs', async (req, res) => {
  try {
    const { name, plan = 'free', max_users = 10, notes = '' } = req.body;
    if (!name?.trim()) {
      return res.status(400).json({ error: { message: 'Organisation name is required' } });
    }

    const slug = name.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

    const result = await pool.query(`
      INSERT INTO organizations (name, slug, plan, max_users, notes, status, created_at)
      VALUES ($1, $2, $3, $4, $5, 'active', now())
      RETURNING *
    `, [name.trim(), slug, plan, max_users, notes]);

    await auditLog(req, 'create_org', 'org', result.rows[0].id, { name, plan });

    // Seed default stages, playbooks, etc.
    await seedOrg(result.rows[0].id);

    res.status(201).json({ org: result.rows[0] });
  } catch (err) {
    console.error('POST /super/orgs error:', err);
    res.status(500).json({ error: { message: err.message } });
  }
});

// Update org details
router.patch('/orgs/:orgId', async (req, res) => {
  try {
    const { orgId } = req.params;
    const { name, plan, max_users, notes, status } = req.body;

    const result = await pool.query(`
      UPDATE organizations
      SET
        name      = COALESCE($1, name),
        plan      = COALESCE($2, plan),
        max_users = COALESCE($3, max_users),
        notes     = COALESCE($4, notes),
        status    = COALESCE($5, status)
      WHERE id = $6
      RETURNING *
    `, [name, plan, max_users, notes, status, orgId]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: { message: 'Organisation not found' } });
    }

    await auditLog(req, 'update_org', 'org', parseInt(orgId), req.body);
    res.json({ org: result.rows[0] });
  } catch (err) {
    console.error(`PATCH /super/orgs/${req.params.orgId} error:`, err);
    res.status(500).json({ error: { message: err.message } });
  }
});

// Delete org (hard delete — cascades to all org data)
router.delete('/orgs/:orgId', async (req, res) => {
  const client = await pool.connect();
  try {
    const { orgId } = req.params;

    const existing = await client.query(
      `SELECT id, name FROM organizations WHERE id = $1`,
      [orgId]
    );
    if (existing.rows.length === 0) {
      return res.status(404).json({ error: { message: 'Organisation not found' } });
    }

    const orgName = existing.rows[0].name;

    await client.query('BEGIN');

    // ── Step 1: collect user IDs that belong ONLY to this org ──────────────
    // Users who are in multiple orgs must NOT be deleted.
    const userRows = await client.query(
      `SELECT id FROM users
       WHERE org_id = $1
         AND id NOT IN (
           SELECT DISTINCT user_id FROM org_users WHERE org_id != $1
         )`,
      [orgId]
    );
    const userIds = userRows.rows.map(r => r.id);

    // ── Step 2: clear plain FK references on users that block deletion ──────
    // These are non-cascade FKs pointing at users(id) that we must null out
    // before we can delete the user rows.
    if (userIds.length > 0) {
      const ids = userIds;
      // organizations.suspended_by
      await client.query(`UPDATE organizations SET suspended_by = NULL WHERE suspended_by = ANY($1) AND id = $2`, [ids, orgId]);
      // accounts
      await client.query(`UPDATE accounts SET owner_id = NULL WHERE owner_id = ANY($1) AND org_id = $2`, [ids, orgId]);
      // deals
      await client.query(`UPDATE deals SET owner_id = NULL WHERE owner_id = ANY($1) AND org_id = $2`, [ids, orgId]);
      await client.query(`UPDATE deals SET user_id = NULL WHERE user_id = ANY($1) AND org_id = $2`, [ids, orgId]);
      // contacts
      await client.query(`UPDATE contacts SET user_id = NULL WHERE user_id = ANY($1) AND org_id = $2`, [ids, orgId]);
      await client.query(`UPDATE contacts SET email_snoozed_by = NULL WHERE email_snoozed_by = ANY($1)`, [ids]);
      // contracts
      await client.query(`UPDATE contracts SET owner_id = NULL WHERE owner_id = ANY($1) AND org_id = $2`, [ids, orgId]);
      await client.query(`UPDATE contracts SET created_by = NULL WHERE created_by = ANY($1) AND org_id = $2`, [ids, orgId]);
      // actions
      await client.query(`UPDATE actions SET completed_by = NULL WHERE completed_by = ANY($1) AND org_id = $2`, [ids, orgId]);
      // prospecting
      await client.query(`UPDATE prospects SET owner_id = NULL WHERE owner_id = ANY($1) AND org_id = $2`, [ids, orgId]);
      await client.query(`UPDATE prospecting_actions SET completed_by = NULL WHERE completed_by = ANY($1)`, [ids]);
      await client.query(`UPDATE prospecting_actions SET user_id = NULL WHERE user_id = ANY($1)`, [ids]);
      await client.query(`UPDATE prospecting_activities SET user_id = NULL WHERE user_id = ANY($1)`, [ids]);
      // prospecting_sender_accounts has a check constraint preventing user_id = NULL — delete the rows instead
      await client.query(`DELETE FROM prospecting_sender_accounts WHERE user_id = ANY($1)`, [ids]);
      // straps
      await client.query(`UPDATE straps SET created_by = NULL WHERE created_by = ANY($1)`, [ids]);
      await client.query(`UPDATE straps SET override_by = NULL WHERE override_by = ANY($1)`, [ids]);
      await client.query(`UPDATE straps SET resolved_by = NULL WHERE resolved_by = ANY($1)`, [ids]);
      // playbooks
      await client.query(`UPDATE playbooks SET created_by = NULL WHERE created_by = ANY($1) AND org_id = $2`, [ids, orgId]);
      await client.query(`UPDATE playbooks SET archived_by = NULL WHERE archived_by = ANY($1) AND org_id = $2`, [ids, orgId]);
      await client.query(`UPDATE playbook_plays SET created_by = NULL WHERE created_by = ANY($1)`, [ids]);
      await client.query(`UPDATE playbook_versions SET created_by = NULL WHERE created_by = ANY($1)`, [ids]);
      await client.query(`UPDATE playbook_versions SET approved_by = NULL WHERE approved_by = ANY($1)`, [ids]);
      await client.query(`UPDATE playbook_registrations SET submitter_id = NULL WHERE submitter_id = ANY($1)`, [ids]);
      await client.query(`UPDATE playbook_registrations SET reviewer_id = NULL WHERE reviewer_id = ANY($1)`, [ids]);
      await client.query(`UPDATE playbook_registrations SET approved_by = NULL WHERE approved_by = ANY($1)`, [ids]);
      // handovers
      await client.query(`UPDATE sales_handovers SET assigned_service_owner_id = NULL WHERE assigned_service_owner_id = ANY($1)`, [ids]);
      await client.query(`UPDATE sales_handover_commitments SET created_by = NULL WHERE created_by = ANY($1)`, [ids]);
      // agent proposals
      await client.query(`UPDATE agent_proposals SET reviewed_by = NULL WHERE reviewed_by = ANY($1)`, [ids]);
      await client.query(`UPDATE agent_proposals SET user_id = NULL WHERE user_id = ANY($1)`, [ids]);
      // deal value history
      await client.query(`UPDATE deal_value_history SET user_id = NULL WHERE user_id = ANY($1)`, [ids]);
      // deal play instances
      await client.query(`UPDATE deal_play_instances SET completed_by = NULL WHERE completed_by = ANY($1)`, [ids]);
      await client.query(`UPDATE deal_play_instances SET overridden_by = NULL WHERE overridden_by = ANY($1)`, [ids]);
      // contract play instances
      await client.query(`UPDATE contract_play_instances SET completed_by = NULL WHERE completed_by = ANY($1)`, [ids]);
      // contract document versions
      await client.query(`UPDATE contract_document_versions SET uploaded_by = NULL WHERE uploaded_by = ANY($1)`, [ids]);
      // contract approvals
      await client.query(`UPDATE contract_approvals SET approver_user_id = NULL WHERE approver_user_id = ANY($1)`, [ids]);
      await client.query(`UPDATE contract_approval_config SET approver_user_id = NULL WHERE approver_user_id = ANY($1)`, [ids]);
      // contract events
      await client.query(`UPDATE contract_events SET actor_id = NULL WHERE actor_id = ANY($1)`, [ids]);
      // contract plays
      await client.query(`UPDATE contract_plays SET assigned_to = NULL WHERE assigned_to = ANY($1)`, [ids]);
      await client.query(`UPDATE contract_plays SET completed_by = NULL WHERE completed_by = ANY($1)`, [ids]);
      // contract templates
      await client.query(`UPDATE contract_templates SET uploaded_by = NULL WHERE uploaded_by = ANY($1)`, [ids]);
      // cases
      await client.query(`UPDATE cases SET assigned_to = NULL WHERE assigned_to = ANY($1)`, [ids]);
      await client.query(`UPDATE cases SET created_by = NULL WHERE created_by = ANY($1)`, [ids]);
      await client.query(`UPDATE case_notes SET author_id = NULL WHERE author_id = ANY($1)`, [ids]);
      await client.query(`UPDATE case_plays SET assigned_to = NULL WHERE assigned_to = ANY($1)`, [ids]);
      await client.query(`UPDATE case_status_history SET changed_by = NULL WHERE changed_by = ANY($1)`, [ids]);
      // emails
      await client.query(`UPDATE emails SET tagged_by = NULL WHERE tagged_by = ANY($1)`, [ids]);
      // contact activities
      await client.query(`UPDATE contact_activities SET user_id = NULL WHERE user_id = ANY($1)`, [ids]);
      // deal activities
      await client.query(`UPDATE deal_activities SET user_id = NULL WHERE user_id = ANY($1)`, [ids]);
      // deal team members
      await client.query(`UPDATE deal_team_members SET added_by = NULL WHERE added_by = ANY($1)`, [ids]);
      // deal play assignees
      await client.query(`UPDATE deal_play_assignees SET assigned_by = NULL WHERE assigned_by = ANY($1)`, [ids]);
      // account teams / hierarchy
      await client.query(`UPDATE account_teams SET created_by = NULL WHERE created_by = ANY($1)`, [ids]);
      await client.query(`UPDATE account_hierarchy SET created_by = NULL WHERE created_by = ANY($1)`, [ids]);
      // teams / workflows
      await client.query(`UPDATE teams SET created_by = NULL WHERE created_by = ANY($1)`, [ids]);
      await client.query(`UPDATE workflows SET created_by = NULL WHERE created_by = ANY($1)`, [ids]);
      await client.query(`UPDATE workflow_rules SET created_by = NULL WHERE created_by = ANY($1)`, [ids]);
      await client.query(`UPDATE workflow_executions SET triggered_by = NULL WHERE triggered_by = ANY($1)`, [ids]);
      // org invitations / invites
      await client.query(`UPDATE org_invitations SET invited_by = NULL WHERE invited_by = ANY($1)`, [ids]);
      await client.query(`UPDATE org_invites SET invited_by = NULL WHERE invited_by = ANY($1)`, [ids]);
      await client.query(`UPDATE org_users SET invited_by = NULL WHERE invited_by = ANY($1)`, [ids]);
      // org action config / hierarchy
      await client.query(`UPDATE org_action_config SET updated_by = NULL WHERE updated_by = ANY($1)`, [ids]);
      await client.query(`UPDATE org_hierarchy SET reports_to = NULL WHERE reports_to = ANY($1)`, [ids]);
      // clients
      await client.query(`UPDATE clients SET created_by = NULL WHERE created_by = ANY($1)`, [ids]);
      await client.query(`UPDATE client_activities SET user_id = NULL WHERE user_id = ANY($1)`, [ids]);
      await client.query(`UPDATE client_team_members SET assigned_by = NULL WHERE assigned_by = ANY($1)`, [ids]);
      // ai token usage
      await client.query(`UPDATE ai_token_usage SET user_id = NULL WHERE user_id = ANY($1)`, [ids]);
      // platform / super admin
      await client.query(`UPDATE platform_settings SET updated_by = NULL WHERE updated_by = ANY($1)`, [ids]);
      await client.query(`UPDATE super_admins SET granted_by = NULL WHERE granted_by = ANY($1)`, [ids]);
      // super admin audit log — keep the log rows but null the user ref
      await client.query(`UPDATE super_admin_audit_log SET super_admin_id = NULL WHERE super_admin_id = ANY($1)`, [ids]);
    }

    // ── Step 3: delete the org-only users BEFORE deleting the org ───────────
    // users.org_id is NOT NULL with no cascade, so users must be deleted
    // before the org row, after all FK references to them have been nulled out.
    if (userIds.length > 0) {
      await client.query(`DELETE FROM users WHERE id = ANY($1)`, [userIds]);
    }

    // ── Step 4: delete the org (cascades everything with ON DELETE CASCADE) ─
    await client.query(`DELETE FROM organizations WHERE id = $1`, [orgId]);

    await client.query('COMMIT');

    await auditLog(req, 'delete_org', 'org', parseInt(orgId), { name: orgName });
    console.log(`🗑️  Org ${orgId} (${orgName}) permanently deleted by super admin`);

    res.json({ message: `Organisation "${orgName}" permanently deleted.` });
  } catch (err) {
    await client.query('ROLLBACK');
    console.error(`DELETE /super/orgs/${req.params.orgId} error:`, err);
    res.status(500).json({ error: { message: err.message } });
  } finally {
    client.release();
  }
});

// Suspend / unsuspend org
router.post('/orgs/:orgId/suspend', async (req, res) => {
  try {
    const { orgId } = req.params;
    const { suspend, reason } = req.body; // suspend: true|false

    const result = await pool.query(`
      UPDATE organizations
      SET
        status       = $1,
        suspended_at = $2,
        suspended_by = $3,
        notes        = CASE WHEN $4::text IS NOT NULL THEN $4 ELSE notes END
      WHERE id = $5
      RETURNING *
    `, [
      suspend ? 'suspended' : 'active',
      suspend ? new Date() : null,
      suspend ? req.userId : null,
      reason || null,
      orgId,
    ]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: { message: 'Organisation not found' } });
    }

    await auditLog(req, suspend ? 'suspend_org' : 'unsuspend_org', 'org', parseInt(orgId), { reason });
    res.json({ org: result.rows[0] });
  } catch (err) {
    console.error(`POST /super/orgs/${req.params.orgId}/suspend error:`, err);
    res.status(500).json({ error: { message: err.message } });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// PATCH: Add this block to superAdmin.routes.js
//
// Paste it immediately after the existing suspend/unsuspend route block
// (after the closing brace of router.post('/orgs/:orgId/suspend', ...)),
// before the USERS WITHIN AN ORG section.
//
// This adds one new endpoint:
//   PATCH /super/orgs/:orgId/modules
//
// Body: { modules: { prospecting: true, contracts: false, ... } }
//
// Sets the `allowed` flag for each module in organizations.settings.modules.
// The org admin can still independently control the `enabled` flag, but they
// cannot enable a module that is not allowed by the platform.
//
// Modules not mentioned in the request body are left unchanged.
// ─────────────────────────────────────────────────────────────────────────────

const MODULE_KEYS = ['prospecting', 'contracts', 'handovers', 'service', 'agency'];

// ═════════════════════════════════════════════════════════════════════════════
// MODULE PROVISIONING — super admin controls which modules an org may use
// ═════════════════════════════════════════════════════════════════════════════

/**
 * GET /super/orgs/:orgId/modules
 * Read the current allowed/enabled state for all modules of an org.
 * Used to populate the module toggles in SAOrgDetail.
 */
router.get('/orgs/:orgId/modules', async (req, res) => {
  try {
    const { orgId } = req.params;

    const result = await pool.query(
      `SELECT settings->'modules' AS modules FROM organizations WHERE id = $1`,
      [orgId]
    );

    if (!result.rows.length) {
      return res.status(404).json({ error: { message: 'Organisation not found' } });
    }

    const rawModules = result.rows[0]?.modules || {};
    const modules = {};

    for (const key of MODULE_KEYS) {
      const raw = rawModules[key];
      if (raw === null || raw === undefined) {
        modules[key] = { allowed: false, enabled: false };
      } else if (typeof raw === 'object') {
        modules[key] = { allowed: !!raw.allowed, enabled: !!raw.enabled };
      } else {
        // Legacy scalar — treat existing true as allowed+enabled
        const b = raw === true || raw === 'true';
        modules[key] = { allowed: b, enabled: b };
      }
    }

    res.json({ modules });
  } catch (err) {
    console.error(`GET /super/orgs/${req.params.orgId}/modules error:`, err);
    res.status(500).json({ error: { message: err.message } });
  }
});

/**
 * PATCH /super/orgs/:orgId/modules
 * Set the `allowed` flag for one or more modules.
 *
 * Body: { modules: { prospecting: true, contracts: false, agency: true } }
 *
 * When a module is disallowed (allowed: false), its enabled flag is also
 * forced to false so org admins cannot have it active while it's not provisioned.
 *
 * Modules not mentioned in the request body are left completely unchanged.
 */
router.patch('/orgs/:orgId/modules', async (req, res) => {
  try {
    const { orgId } = req.params;
    const { modules: incoming } = req.body;

    if (!incoming || typeof incoming !== 'object') {
      return res.status(400).json({ error: { message: 'modules object is required' } });
    }

    // Validate keys
    const unknownKeys = Object.keys(incoming).filter(k => !MODULE_KEYS.includes(k));
    if (unknownKeys.length) {
      return res.status(400).json({ error: { message: `Unknown module(s): ${unknownKeys.join(', ')}` } });
    }

    // Load current settings so we can merge cleanly
    const current = await pool.query(
      `SELECT settings FROM organizations WHERE id = $1`,
      [orgId]
    );
    if (!current.rows.length) {
      return res.status(404).json({ error: { message: 'Organisation not found' } });
    }

    const settings    = current.rows[0].settings || {};
    const rawModules  = settings.modules || {};

    // Build merged module map
    const merged = { ...rawModules };

    for (const [moduleName, allowedValue] of Object.entries(incoming)) {
      const allowed = allowedValue === true || allowedValue === 'true';

      // Read existing object shape or legacy scalar
      const existing = merged[moduleName];
      let currentEnabled = false;
      if (existing !== null && existing !== undefined) {
        if (typeof existing === 'object') {
          currentEnabled = !!existing.enabled;
        } else {
          currentEnabled = existing === true || existing === 'true';
        }
      }

      // If revoking access, force enabled to false too
      const newEnabled = allowed ? currentEnabled : false;

      merged[moduleName] = { allowed, enabled: newEnabled };
    }

    // Write back using jsonb_set on the modules sub-key
    await pool.query(
      `UPDATE organizations
          SET settings   = jsonb_set(COALESCE(settings, '{}'::jsonb), '{modules}', $2::jsonb, true),
              updated_at = NOW()
        WHERE id = $1`,
      [orgId, JSON.stringify(merged)]
    );

    // Invalidate the requireModule cache for every changed module
    const requireModule = require('../middleware/requireModule.middleware');
    for (const moduleName of Object.keys(incoming)) {
      requireModule.invalidate(orgId, moduleName);
    }

    await auditLog(req, 'update_org_modules', 'org', parseInt(orgId), {
      changes: Object.entries(incoming).map(([k, v]) => `${k}=${v}`).join(', '),
    });

    // Return the full resolved module state
    const finalModules = {};
    for (const key of MODULE_KEYS) {
      const v = merged[key];
      if (!v || typeof v !== 'object') {
        const b = v === true || v === 'true';
        finalModules[key] = { allowed: b, enabled: b };
      } else {
        finalModules[key] = { allowed: !!v.allowed, enabled: !!v.enabled };
      }
    }

    res.json({ modules: finalModules });
  } catch (err) {
    console.error(`PATCH /super/orgs/${req.params.orgId}/modules error:`, err);
    res.status(500).json({ error: { message: err.message } });
  }
});


// ============================================================================
// ENTITLEMENTS — super admin controls which PAID capabilities an org has.
//
// Storage: organizations.settings.entitlements = { ai: bool, calling: bool }.
// This is the platform "allowed" axis; the org's own switches (ai_enabled,
// org_twilio_accounts.status) are the "enabled" axis. A capability is usable
// only when both are on. See services/entitlements.service.js.
// ============================================================================

const ENTITLEMENT_KEYS = require('../services/entitlements.service').ENTITLEMENT_KEYS;

/**
 * GET /super/orgs/:orgId/entitlements
 * Read the current entitlement flags for an org. Default-off: missing keys
 * report false.
 */
router.get('/orgs/:orgId/entitlements', async (req, res) => {
  try {
    const { orgId } = req.params;
    const result = await pool.query(
      `SELECT settings->'entitlements' AS entitlements FROM organizations WHERE id = $1`,
      [orgId]
    );
    if (!result.rows.length) {
      return res.status(404).json({ error: { message: 'Organisation not found' } });
    }
    const raw = result.rows[0]?.entitlements || {};
    const entitlements = {};
    for (const key of ENTITLEMENT_KEYS) entitlements[key] = raw[key] === true;
    res.json({ entitlements });
  } catch (err) {
    console.error(`GET /super/orgs/${req.params.orgId}/entitlements error:`, err);
    res.status(500).json({ error: { message: err.message } });
  }
});

/**
 * PATCH /super/orgs/:orgId/entitlements
 * Set one or more entitlement flags.
 *
 * Body: { entitlements: { ai: true, calling: false } }
 *
 * Keys not mentioned are left unchanged. Each value is coerced to a strict
 * boolean (true | "true" → true; everything else → false).
 *
 * Note: revoking 'calling' here does NOT suspend an existing Twilio subaccount
 * or release DIDs — it only stops NEW token mints / provisioning. To stop an
 * org mid-flight, also call twilioAccounts.suspendSubaccount(orgId). Likewise
 * revoking 'ai' does not delete history; it stops new generation.
 */
router.patch('/orgs/:orgId/entitlements', async (req, res) => {
  try {
    const { orgId } = req.params;
    const { entitlements: incoming } = req.body;

    if (!incoming || typeof incoming !== 'object' || Array.isArray(incoming)) {
      return res.status(400).json({ error: { message: 'entitlements object is required' } });
    }

    const unknownKeys = Object.keys(incoming).filter(k => !ENTITLEMENT_KEYS.includes(k));
    if (unknownKeys.length) {
      return res.status(400).json({ error: { message: `Unknown entitlement(s): ${unknownKeys.join(', ')}` } });
    }

    const current = await pool.query(
      `SELECT settings FROM organizations WHERE id = $1`,
      [orgId]
    );
    if (!current.rows.length) {
      return res.status(404).json({ error: { message: 'Organisation not found' } });
    }

    const settings = current.rows[0].settings || {};
    const merged   = { ...(settings.entitlements || {}) };

    for (const [key, value] of Object.entries(incoming)) {
      merged[key] = value === true || value === 'true';
    }

    await pool.query(
      `UPDATE organizations
          SET settings   = jsonb_set(COALESCE(settings, '{}'::jsonb), '{entitlements}', $2::jsonb, true),
              updated_at = NOW()
        WHERE id = $1`,
      [orgId, JSON.stringify(merged)]
    );

    // Drop the cached entitlements so the change takes effect immediately.
    require('../services/entitlements.service').invalidate(orgId);

    await auditLog(req, 'update_org_entitlements', 'org', parseInt(orgId), {
      changes: Object.entries(incoming).map(([k, v]) => `${k}=${v}`).join(', '),
    });

    const finalEntitlements = {};
    for (const key of ENTITLEMENT_KEYS) finalEntitlements[key] = merged[key] === true;
    res.json({ entitlements: finalEntitlements });
  } catch (err) {
    console.error(`PATCH /super/orgs/${req.params.orgId}/entitlements error:`, err);
    res.status(500).json({ error: { message: err.message } });
  }
});



// ═════════════════════════════════════════════════════════════════════════════
// USERS WITHIN AN ORG (super admin view — can add users to any org)
// ═════════════════════════════════════════════════════════════════════════════

// Add existing user to org
router.post('/orgs/:orgId/users', async (req, res) => {
  try {
    const { orgId } = req.params;
    const { email, role = 'member' } = req.body;

    const userResult = await pool.query(
      'SELECT id, email, first_name, last_name FROM users WHERE email = $1', [email]
    );
    if (userResult.rows.length === 0) {
      return res.status(404).json({ error: { message: 'User not found. They must register first.' } });
    }

    const user = userResult.rows[0];

    // Check seat limit
    const [countRow, orgRow] = await Promise.all([
      pool.query('SELECT COUNT(*) FROM org_users WHERE org_id = $1 AND is_active = TRUE', [orgId]),
      pool.query('SELECT max_users FROM organizations WHERE id = $1', [orgId]),
    ]);
    if (parseInt(countRow.rows[0].count) >= parseInt(orgRow.rows[0].max_users)) {
      return res.status(400).json({ error: { message: 'Org has reached its user seat limit' } });
    }

    await pool.query(`
      INSERT INTO org_users (org_id, user_id, role, is_active, joined_at)
      VALUES ($1, $2, $3, TRUE, now())
      ON CONFLICT (org_id, user_id) DO UPDATE
        SET role = $3, is_active = TRUE
    `, [orgId, user.id, role]);

    await auditLog(req, 'add_user_to_org', 'user', user.id, { orgId, role });
    res.status(201).json({ message: 'User added', user: { ...user, role } });
  } catch (err) {
    console.error(`POST /super/orgs/${req.params.orgId}/users error:`, err);
    res.status(500).json({ error: { message: err.message } });
  }
});

// Update a user's role in an org
router.patch('/orgs/:orgId/users/:userId', async (req, res) => {
  try {
    const { orgId, userId } = req.params;
    const { role, is_active } = req.body;

    // Prevent removing the last owner
    if (role && role !== 'owner') {
      const ownerCheck = await pool.query(
        `SELECT COUNT(*) FROM org_users WHERE org_id = $1 AND role = 'owner' AND is_active = TRUE AND user_id != $2`,
        [orgId, userId]
      );
      const currentRole = await pool.query(
        `SELECT role FROM org_users WHERE org_id = $1 AND user_id = $2`, [orgId, userId]
      );
      if (currentRole.rows[0]?.role === 'owner' && parseInt(ownerCheck.rows[0].count) === 0) {
        return res.status(400).json({ error: { message: 'Cannot change role of the last owner. Promote another user to owner first.' } });
      }
    }

    const result = await pool.query(`
      UPDATE org_users
      SET
        role      = COALESCE($1, role),
        is_active = COALESCE($2, is_active)
      WHERE org_id = $3 AND user_id = $4
      RETURNING *
    `, [role, is_active, orgId, userId]);

    await auditLog(req, 'update_user_in_org', 'user', parseInt(userId), { orgId, role, is_active });
    res.json({ membership: result.rows[0] });
  } catch (err) {
    console.error(`PATCH /super/orgs/${req.params.orgId}/users/${req.params.userId} error:`, err);
    res.status(500).json({ error: { message: err.message } });
  }
});

// Remove user from org
router.delete('/orgs/:orgId/users/:userId', async (req, res) => {
  try {
    const { orgId, userId } = req.params;

    await pool.query(
      `UPDATE org_users SET is_active = FALSE WHERE org_id = $1 AND user_id = $2`,
      [orgId, userId]
    );

    await auditLog(req, 'remove_user_from_org', 'user', parseInt(userId), { orgId });
    res.json({ message: 'User removed from org' });
  } catch (err) {
    console.error(`DELETE /super/orgs/${req.params.orgId}/users/${req.params.userId} error:`, err);
    res.status(500).json({ error: { message: err.message } });
  }
});

// ═════════════════════════════════════════════════════════════════════════════
// CREATE USER + ADD TO ORG (super admin creates account directly)
// ═════════════════════════════════════════════════════════════════════════════

router.post('/orgs/:orgId/users/create', async (req, res) => {
  try {
    const { orgId } = req.params;
    const { email, first_name, last_name, password, role = 'member' } = req.body;

    if (!email?.trim()) return res.status(400).json({ error: { message: 'Email is required' } });
    if (!first_name?.trim()) return res.status(400).json({ error: { message: 'First name is required' } });
    if (!last_name?.trim()) return res.status(400).json({ error: { message: 'Last name is required' } });
    if (!password || password.length < 8) return res.status(400).json({ error: { message: 'Password must be at least 8 characters' } });

    // Check if user already exists
    const existing = await pool.query('SELECT id FROM users WHERE email = $1', [email.trim().toLowerCase()]);
    if (existing.rows.length > 0) {
      return res.status(409).json({ error: { message: 'A user with this email already exists. Use "Add Existing User" instead.' } });
    }

    // Check seat limit
    const [countRow, orgRow] = await Promise.all([
      pool.query('SELECT COUNT(*) FROM org_users WHERE org_id = $1 AND is_active = TRUE', [orgId]),
      pool.query('SELECT max_users FROM organizations WHERE id = $1', [orgId]),
    ]);
    if (parseInt(countRow.rows[0].count) >= parseInt(orgRow.rows[0].max_users)) {
      return res.status(400).json({ error: { message: 'Org has reached its user seat limit' } });
    }

    // Hash password and create user
    const password_hash = await bcrypt.hash(password, 12);
    const userResult = await pool.query(`
      INSERT INTO users (email, password_hash, first_name, last_name, org_id, created_at)
      VALUES ($1, $2, $3, $4, $5, now())
      RETURNING id, email, first_name, last_name
    `, [email.trim().toLowerCase(), password_hash, first_name.trim(), last_name.trim(), orgId]);

    const user = userResult.rows[0];

    // Add to org
    await pool.query(`
      INSERT INTO org_users (org_id, user_id, role, is_active, joined_at)
      VALUES ($1, $2, $3, TRUE, now())
    `, [orgId, user.id, role]);

    await auditLog(req, 'create_user_for_org', 'user', user.id, { orgId, role, email });
    res.status(201).json({ message: 'User created and added to org', user: { ...user, role } });
  } catch (err) {
    console.error(`POST /super/orgs/${req.params.orgId}/users/create error:`, err);
    res.status(500).json({ error: { message: err.message } });
  }
});

// ═════════════════════════════════════════════════════════════════════════════
// INVITE FLOW — generate invite link, list pending invites
// ═════════════════════════════════════════════════════════════════════════════


// Create invite
router.post('/orgs/:orgId/invites', async (req, res) => {
  try {
    const { orgId } = req.params;
    const { email, role = 'member' } = req.body;

    if (!email?.trim()) return res.status(400).json({ error: { message: 'Email is required' } });

    // Check if user already in org
    const existingUser = await pool.query(
      `SELECT u.id FROM users u JOIN org_users ou ON ou.user_id = u.id
       WHERE u.email = $1 AND ou.org_id = $2 AND ou.is_active = TRUE`,
      [email.trim().toLowerCase(), orgId]
    );
    if (existingUser.rows.length > 0) {
      return res.status(409).json({ error: { message: 'This user is already a member of this org' } });
    }

    // Check for existing pending invite
    const existingInvite = await pool.query(
      `SELECT id FROM org_invites WHERE email = $1 AND org_id = $2 AND accepted_at IS NULL AND expires_at > now()`,
      [email.trim().toLowerCase(), orgId]
    );
    if (existingInvite.rows.length > 0) {
      return res.status(409).json({ error: { message: 'An active invite already exists for this email' } });
    }

    // Check seat limit
    const [countRow, orgRow] = await Promise.all([
      pool.query('SELECT COUNT(*) FROM org_users WHERE org_id = $1 AND is_active = TRUE', [orgId]),
      pool.query('SELECT max_users, name FROM organizations WHERE id = $1', [orgId]),
    ]);
    if (parseInt(countRow.rows[0].count) >= parseInt(orgRow.rows[0].max_users)) {
      return res.status(400).json({ error: { message: 'Org has reached its user seat limit' } });
    }

    const token = crypto.randomBytes(32).toString('hex');
    const expires_at = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000); // 7 days

    const result = await pool.query(`
      INSERT INTO org_invites (org_id, email, role, token, invited_by, expires_at)
      VALUES ($1, $2, $3, $4, $5, $6)
      RETURNING *
    `, [orgId, email.trim().toLowerCase(), role, token, req.userId, expires_at]);

    // Build invite URL (frontend registration page with token)
    const appUrl = process.env.APP_URL || process.env.REACT_APP_URL || 'http://localhost:3000';
    const inviteUrl = `${appUrl}/register?invite=${token}`;

    // TODO: Send email with inviteUrl when email service is configured
    // e.g. await sendEmail({ to: email, subject: `You're invited to ${orgRow.rows[0].name}`, body: `...${inviteUrl}...` });
    console.log(`📧 Invite created for ${email} → ${inviteUrl}`);

    await auditLog(req, 'invite_user_to_org', 'org', parseInt(orgId), { email, role });
    res.status(201).json({
      invite: result.rows[0],
      inviteUrl,
      message: 'Invite created. Share the invite URL with the user.',
    });
  } catch (err) {
    console.error(`POST /super/orgs/${req.params.orgId}/invites error:`, err);
    res.status(500).json({ error: { message: err.message } });
  }
});

// List pending invites for an org
router.get('/orgs/:orgId/invites', async (req, res) => {
  try {
    const { orgId } = req.params;
    const result = await pool.query(`
      SELECT oi.*, u.email AS invited_by_email
      FROM   org_invites oi
      LEFT JOIN users u ON u.id = oi.invited_by
      WHERE  oi.org_id = $1
      ORDER  BY oi.created_at DESC
    `, [orgId]);
    res.json({ invites: result.rows });
  } catch (err) {
    res.status(500).json({ error: { message: err.message } });
  }
});

// Revoke/cancel an invite
router.delete('/orgs/:orgId/invites/:inviteId', async (req, res) => {
  try {
    await pool.query('DELETE FROM org_invites WHERE id = $1 AND org_id = $2', [req.params.inviteId, req.params.orgId]);
    res.json({ message: 'Invite cancelled' });
  } catch (err) {
    res.status(500).json({ error: { message: err.message } });
  }
});

// ═════════════════════════════════════════════════════════════════════════════
// IMPERSONATION — super admin borrows org context for support
// ═════════════════════════════════════════════════════════════════════════════

router.post('/orgs/:orgId/impersonate', async (req, res) => {
  try {
    const { orgId } = req.params;

    const orgResult = await pool.query(
      'SELECT id, name, status FROM organizations WHERE id = $1', [orgId]
    );
    if (orgResult.rows.length === 0) {
      return res.status(404).json({ error: { message: 'Organisation not found' } });
    }

    await auditLog(req, 'impersonate_org', 'org', parseInt(orgId), {});

    // Return a support context token (the frontend stores this separately
    // and sends it as X-Support-Org-Id header — handled in orgContext middleware)
    res.json({
      message:         `Now supporting org: ${orgResult.rows[0].name}`,
      supportOrgId:    orgResult.rows[0].id,
      supportOrgName:  orgResult.rows[0].name,
    });
  } catch (err) {
    console.error(`POST /super/orgs/${req.params.orgId}/impersonate error:`, err);
    res.status(500).json({ error: { message: err.message } });
  }
});

// ─────────────────────────────────────────────────────────────────────────────
// USER-LEVEL IMPERSONATION (read-only)
//
// POST /api/super/users/:userId/impersonate
//
// Mints a SHORT-LIVED JWT that carries the target user's identity, so the whole
// app transparently renders as that user (authenticateToken + orgContext both
// read identity/org straight from the token). The token is stamped `imp: true`,
// which:
//   • flips the app into read-only mode via blockImpersonatedWrites, and
//   • makes the session identifiable everywhere (refresh refuses to extend it).
//
// The token also carries impersonator_id / impersonator_email so a future,
// narrowly-scoped write path could attribute the true actor into an audit
// overlay without changing per-row ownership. For now writes are blocked.
//
// Guard rails:
//   • target must exist and have an active org membership
//   • cannot impersonate yourself (pointless)
//   • cannot impersonate another super admin (privilege-safety)
//
// Response shape mirrors /api/auth/login so the frontend can swap it in:
//   { token, user }
// ─────────────────────────────────────────────────────────────────────────────

const IMPERSONATION_TTL = process.env.IMPERSONATION_TTL || '30m';

// ═════════════════════════════════════════════════════════════════════════════
// USERS — platform-wide user list (all orgs), for the Users tab
// ═════════════════════════════════════════════════════════════════════════════

// GET /super/users?search=&active=&new_30d=&page=&limit=
router.get('/users', async (req, res) => {
  try {
    const page   = Math.max(parseInt(req.query.page, 10)  || 1, 1);
    const limit  = Math.min(Math.max(parseInt(req.query.limit, 10) || 20, 1), 100);
    const offset = (page - 1) * limit;

    const where  = [];
    const params = [];

    if (req.query.search) {
      params.push(`%${req.query.search.trim()}%`);
      where.push(`(
        u.email ILIKE $${params.length}
        OR (u.first_name || ' ' || u.last_name) ILIKE $${params.length}
        OR EXISTS (
          SELECT 1 FROM org_users oux
          JOIN organizations ox ON ox.id = oux.org_id
          WHERE oux.user_id = u.id AND ox.name ILIKE $${params.length}
        )
      )`);
    }
    if (req.query.active === 'true') {
      where.push(`EXISTS (SELECT 1 FROM org_users oua WHERE oua.user_id = u.id AND oua.is_active = TRUE)`);
    }
    if (req.query.new_30d === 'true') {
      where.push(`EXISTS (SELECT 1 FROM org_users oun WHERE oun.user_id = u.id AND oun.joined_at > now() - interval '30 days')`);
    }

    const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';

    const [listRes, countRes] = await Promise.all([
      pool.query(
        `SELECT u.id AS user_id,
                u.email,
                u.first_name || ' ' || u.last_name AS name,
                MIN(ou.joined_at)                  AS joined_at,
                COALESCE(BOOL_OR(ou.is_active), FALSE) AS is_active,
                COALESCE(
                  json_agg(
                    json_build_object('org_id', o.id, 'org_name', o.name, 'role', ou.role)
                    ORDER BY ou.joined_at
                  ) FILTER (WHERE o.id IS NOT NULL),
                  '[]'
                ) AS orgs,
                EXISTS (
                  SELECT 1 FROM super_admins sa
                  WHERE sa.user_id = u.id AND sa.revoked_at IS NULL
                ) AS is_super_admin
         FROM users u
         LEFT JOIN org_users ou     ON ou.user_id = u.id
         LEFT JOIN organizations o  ON o.id = ou.org_id
         ${whereSql}
         GROUP BY u.id
         ORDER BY MIN(ou.joined_at) DESC NULLS LAST, u.id DESC
         LIMIT ${limit} OFFSET ${offset}`,
        params
      ),
      pool.query(
        `SELECT COUNT(DISTINCT u.id) AS total
         FROM users u
         LEFT JOIN org_users ou    ON ou.user_id = u.id
         LEFT JOIN organizations o ON o.id = ou.org_id
         ${whereSql}`,
        params
      ),
    ]);

    res.json({
      users: listRes.rows,
      total: parseInt(countRes.rows[0].total, 10),
      page,
      limit,
    });
  } catch (err) {
    console.error('GET /super/users error:', err);
    res.status(500).json({ error: { message: err.message } });
  }
});

router.post('/users/:userId/impersonate', async (req, res) => {
  try {
    const targetUserId = parseInt(req.params.userId, 10);
    if (!Number.isInteger(targetUserId)) {
      return res.status(400).json({ error: { message: 'Invalid user id' } });
    }

    // Can't impersonate yourself.
    if (targetUserId === req.userId) {
      return res.status(400).json({ error: { message: 'You cannot impersonate yourself' } });
    }

    // Target must exist.
    const userRes = await pool.query(
      `SELECT id, email, first_name, last_name, timezone
         FROM users WHERE id = $1`,
      [targetUserId]
    );
    if (userRes.rows.length === 0) {
      return res.status(404).json({ error: { message: 'User not found' } });
    }
    const target = userRes.rows[0];

    // Cannot impersonate another (active) super admin.
    const saRes = await pool.query(
      `SELECT 1 FROM super_admins WHERE user_id = $1 AND revoked_at IS NULL`,
      [targetUserId]
    );
    if (saRes.rows.length > 0) {
      return res.status(403).json({ error: { message: 'Cannot impersonate a super admin' } });
    }

    // Resolve the target's active org context (mirrors auth.routes getOrgPayload).
    const orgRes = await pool.query(
      `SELECT ou.org_id, ou.role, o.name AS org_name, o.slug AS org_slug
         FROM org_users ou
         LEFT JOIN organizations o ON o.id = ou.org_id
        WHERE ou.user_id = $1 AND ou.is_active = TRUE
        ORDER BY ou.joined_at ASC
        LIMIT 1`,
      [targetUserId]
    );
    if (orgRes.rows.length === 0 || !orgRes.rows[0].org_id) {
      return res.status(400).json({
        error: { message: 'Target user has no active organisation context to impersonate' },
      });
    }
    const org = orgRes.rows[0];

    // Mint the short-lived impersonation token.
    const token = jwt.sign(
      {
        userId:             target.id,          // identity the whole app renders as
        email:              target.email,
        org_id:             org.org_id,
        role:               org.role,
        imp:                true,               // impersonation marker (read-only + refresh-guard)
        impersonator_id:    req.userId,         // real super admin (for audit / future write path)
        impersonator_email: req.user?.email || null,
      },
      process.env.JWT_SECRET,
      { expiresIn: IMPERSONATION_TTL }
    );

    // Audit the start of the session.
    await auditLog(req, 'impersonate_user', 'user', target.id, {
      org_id:   org.org_id,
      ttl:      IMPERSONATION_TTL,
      readonly: true,
    });

    return res.json({
      token,
      user: {
        id:             target.id,
        email:          target.email,
        firstName:      target.first_name,
        lastName:       target.last_name,
        role:           org.role,
        timezone:       target.timezone,
        org_id:         org.org_id,
        org_role:       org.role,
        org_name:       org.org_name,
        org_slug:       org.org_slug,
        is_super_admin: false,               // the impersonated user is NOT a super admin
        impersonation: {
          active:             true,
          readonly:           true,
          impersonator_id:    req.userId,
          impersonator_email: req.user?.email || null,
          expires_in:         IMPERSONATION_TTL,
        },
      },
    });
  } catch (err) {
    console.error(`POST /super/users/${req.params.userId}/impersonate error:`, err);
    return res.status(500).json({ error: { message: err.message } });
  }
});

// ═════════════════════════════════════════════════════════════════════════════
// SUPER ADMINS — manage who has platform-level access
// ═════════════════════════════════════════════════════════════════════════════

router.get('/admins', async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT sa.id, sa.user_id, sa.granted_at, sa.revoked_at, sa.notes,
             u.email, u.first_name || ' ' || u.last_name AS name,
             g.email AS granted_by_email
      FROM   super_admins sa
      JOIN   users u  ON u.id  = sa.user_id
      LEFT JOIN users g ON g.id = sa.granted_by
      ORDER  BY sa.granted_at DESC
    `);
    res.json({ admins: result.rows });
  } catch (err) {
    res.status(500).json({ error: { message: err.message } });
  }
});

router.post('/admins', async (req, res) => {
  try {
    const { email, notes = '' } = req.body;
    const userResult = await pool.query('SELECT id FROM users WHERE email = $1', [email]);
    if (userResult.rows.length === 0) {
      return res.status(404).json({ error: { message: 'User not found' } });
    }

    const result = await pool.query(`
      INSERT INTO super_admins (user_id, granted_by, notes)
      VALUES ($1, $2, $3)
      ON CONFLICT (user_id) DO UPDATE SET revoked_at = NULL, granted_by = $2, notes = $3
      RETURNING *
    `, [userResult.rows[0].id, req.userId, notes]);

    await auditLog(req, 'grant_super_admin', 'user', userResult.rows[0].id, { email });
    res.status(201).json({ admin: result.rows[0] });
  } catch (err) {
    res.status(500).json({ error: { message: err.message } });
  }
});

router.delete('/admins/:userId', async (req, res) => {
  try {
    if (parseInt(req.params.userId) === req.userId) {
      return res.status(400).json({ error: { message: 'Cannot revoke your own super admin access' } });
    }

    await pool.query(
      `UPDATE super_admins SET revoked_at = now() WHERE user_id = $1`,
      [req.params.userId]
    );

    await auditLog(req, 'revoke_super_admin', 'user', parseInt(req.params.userId), {});
    res.json({ message: 'Super admin access revoked' });
  } catch (err) {
    res.status(500).json({ error: { message: err.message } });
  }
});

// ═════════════════════════════════════════════════════════════════════════════
// AUDIT LOG
// ═════════════════════════════════════════════════════════════════════════════

router.get('/audit', async (req, res) => {
  try {
    const { page = 1, limit = 50, admin_id, action } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(limit);
    const conditions = ['1=1'];
    const params = [];
    let p = 1;

    if (admin_id) { conditions.push(`sal.super_admin_id = $${p++}`); params.push(admin_id); }
    if (action)   { conditions.push(`sal.action = $${p++}`);         params.push(action); }

    const where = conditions.join(' AND ');

    const result = await pool.query(`
      SELECT sal.*, u.email AS admin_email, u.first_name || ' ' || u.last_name AS admin_name
      FROM   super_admin_audit_log sal
      JOIN   users u ON u.id = sal.super_admin_id
      WHERE  ${where}
      ORDER  BY sal.created_at DESC
      LIMIT  $${p++} OFFSET $${p++}
    `, [...params, parseInt(limit), offset]);

    res.json({ logs: result.rows });
  } catch (err) {
    res.status(500).json({ error: { message: err.message } });
  }
});



// ── Platform Settings ─────────────────────────────────────────────────────────
// Reads and writes platform_settings table rows.
// Each row is a named config key (e.g. 'email_filter') with a JSONB value.

/**
 * GET /super/platform-settings/:key
 * Read a platform setting by key.
 */
router.get('/platform-settings/:key', requireSuperAdmin, async (req, res) => {
  try {
    const { key } = req.params;
    const result = await pool.query(
      `SELECT key, value, updated_by, updated_at FROM platform_settings WHERE key = $1`,
      [key]
    );
    if (result.rows.length === 0) {
      // Return empty value rather than 404 — caller treats missing as blank
      return res.json({ key, value: {}, updated_by: null, updated_at: null });
    }
    res.json(result.rows[0]);
  } catch (err) {
    console.error(`GET /super/platform-settings/${req.params.key} error:`, err);
    res.status(500).json({ error: { message: 'Failed to load platform setting' } });
  }
});

/**
 * PATCH /super/platform-settings/:key
 * Write (upsert) a platform setting by key.
 * Body: { value: <any JSONB-serialisable object> }
 */
router.patch('/platform-settings/:key', requireSuperAdmin, async (req, res) => {
  try {
    const { key } = req.params;
    const { value } = req.body;

    if (value === undefined || value === null) {
      return res.status(400).json({ error: { message: 'value is required' } });
    }

    const result = await pool.query(
      `INSERT INTO platform_settings (key, value, updated_by, updated_at)
       VALUES ($1, $2::jsonb, $3, NOW())
       ON CONFLICT (key) DO UPDATE
         SET value      = $2::jsonb,
             updated_by = $3,
             updated_at = NOW()
       RETURNING key, value, updated_by, updated_at`,
      [key, JSON.stringify(value), req.user?.userId || null]
    );

    console.log(`🛠️ Platform setting '${key}' updated by user ${req.user?.userId}`);
    res.json(result.rows[0]);
  } catch (err) {
    console.error(`PATCH /super/platform-settings/${req.params.key} error:`, err);
    res.status(500).json({ error: { message: 'Failed to save platform setting' } });
  }
});


// ═════════════════════════════════════════════════════════════════════════════
// Enrichment Usage — SuperAdmin (Sprint 3, Group E)
// ═════════════════════════════════════════════════════════════════════════════

/**
 * GET /super/enrichment-usage?month=YYYY-MM
 *
 * Cross-org breakdown of enrichment credit usage for a month. Used by the
 * SuperAdmin dashboard to see who's spending what and which providers are
 * being hit hardest.
 *
 * Response:
 *   {
 *     month,
 *     total,                        // overall credits across all orgs
 *     by_org_provider: [{ org_id, org_name, provider, credits, calls }],
 *   }
 */
router.get('/enrichment-usage', requireSuperAdmin, async (req, res) => {
  try {
    const month = req.query.month || new Date().toISOString().slice(0, 7);
    if (!/^\d{4}-\d{2}$/.test(month)) {
      return res.status(400).json({ error: { message: 'month must be YYYY-MM' } });
    }
    const enrichmentCreditLog = require('../services/enrichment/creditLog');
    const rows = await enrichmentCreditLog.crossOrgBreakdown({ month });
    const total = rows.reduce((sum, r) => sum + (r.credits || 0), 0);
    res.json({ month, total, by_org_provider: rows });
  } catch (err) {
    console.error('GET /super/enrichment-usage error:', err);
    res.status(500).json({ error: { message: 'Failed to load enrichment usage' } });
  }
});

// ═════════════════════════════════════════════════════════════════════════════
// LINKEDIN SEATS — view / reassign / unbind user_linkedin_seats per org
//
// Seats are normally created LAZILY by the Chrome extension (bindSeat in
// LinkedInConnectionSyncService) the first time a user runs a connection sync
// while logged into a LinkedIn account. There is deliberately no "create"
// route here — a superadmin cannot invent a binding the extension hasn't
// verified. This panel exists for the two operational cases:
//
//   1. Wrong binding — a user synced while logged into a shared / company /
//      someone else's LinkedIn account. Fix: DELETE, then have the user
//      re-sync from the correct account.
//   2. Handover — a departed rep's LinkedIn account (e.g. a company page
//      admin seat) is being taken over by another user. Fix: PATCH reassign,
//      which preserves the slug binding and avoids a SEAT_CONFLICT when the
//      new owner syncs.
//
// NOTE ON DELETE SEMANTICS: deleting a seat only removes the binding. If the
// same LinkedIn account runs a sync again, the seat re-creates lazily and
// binds to WHOEVER ran that sync. Historical rows keyed by the slug
// (sequence_step_logs.claimed_by_seat, linkedin_message_events.seat) are
// intentionally left untouched — they are an activity ledger, not ownership.
// ═════════════════════════════════════════════════════════════════════════════

// List seats for an org, joined to their bound user, with in-flight
// auto-send lease counts so the superadmin can see if a seat is "hot".
router.get('/orgs/:orgId/linkedin-seats', async (req, res) => {
  try {
    const { orgId } = req.params;

    const r = await pool.query(`
      SELECT s.id, s.user_id, s.public_identifier, s.display_name,
             s.member_urn, s.first_seen_at, s.last_seen_at,
             u.email                                    AS user_email,
             TRIM(u.first_name || ' ' || u.last_name)   AS user_name,
             ou.is_active                               AS user_is_active,
             COALESCE(l.active_leases, 0)               AS active_leases
      FROM   user_linkedin_seats s
      LEFT JOIN users u      ON u.id = s.user_id
      LEFT JOIN org_users ou ON ou.org_id = s.org_id AND ou.user_id = s.user_id
      LEFT JOIN LATERAL (
        SELECT COUNT(*) AS active_leases
        FROM   sequence_step_logs ssl
        WHERE  ssl.org_id = s.org_id
          AND  ssl.channel = 'linkedin'
          AND  ssl.status  = 'sending'
          AND  lower(ssl.claimed_by_seat) = lower(s.public_identifier)
          AND  ssl.lease_expires_at > now()
      ) l ON TRUE
      WHERE  s.org_id = $1
      ORDER  BY s.last_seen_at DESC
    `, [orgId]);

    res.json({ seats: r.rows });
  } catch (err) {
    console.error(`GET /super/orgs/${req.params.orgId}/linkedin-seats error:`, err);
    res.status(500).json({ error: { message: err.message } });
  }
});

// Reassign a seat to a different user in the same org.
router.patch('/orgs/:orgId/linkedin-seats/:seatId', async (req, res) => {
  try {
    const { orgId, seatId } = req.params;
    const newUserId = parseInt(req.body.user_id, 10);
    if (!Number.isInteger(newUserId)) {
      return res.status(400).json({ error: { message: 'user_id (integer) is required' } });
    }

    // Target user must be an active member of this org.
    const member = await pool.query(`
      SELECT 1 FROM org_users
      WHERE  org_id = $1 AND user_id = $2 AND is_active = TRUE
    `, [orgId, newUserId]);
    if (member.rows.length === 0) {
      return res.status(422).json({ error: { message: 'Target user is not an active member of this org' } });
    }

    const upd = await pool.query(`
      UPDATE user_linkedin_seats
         SET user_id = $3
       WHERE id = $2 AND org_id = $1
       RETURNING id, user_id, public_identifier
    `, [orgId, seatId, newUserId]);
    if (upd.rows.length === 0) {
      return res.status(404).json({ error: { message: 'Seat not found in this org' } });
    }

    await auditLog(req, 'reassign_linkedin_seat', 'linkedin_seat', seatId, {
      orgId, newUserId, publicIdentifier: upd.rows[0].public_identifier,
    });
    res.json({ message: 'Seat reassigned', seat: upd.rows[0] });
  } catch (err) {
    console.error(`PATCH /super/orgs/${req.params.orgId}/linkedin-seats/${req.params.seatId} error:`, err);
    res.status(500).json({ error: { message: err.message } });
  }
});

// Unbind (delete) a seat. Refuses while auto-send leases are in flight so we
// never strand a claimed sequence_step_logs row without its seat context —
// pass ?force=true to override after the caller has acknowledged the warning.
router.delete('/orgs/:orgId/linkedin-seats/:seatId', async (req, res) => {
  try {
    const { orgId, seatId } = req.params;
    const force = req.query.force === 'true';

    const seat = await pool.query(`
      SELECT id, user_id, public_identifier FROM user_linkedin_seats
      WHERE  id = $2 AND org_id = $1
    `, [orgId, seatId]);
    if (seat.rows.length === 0) {
      return res.status(404).json({ error: { message: 'Seat not found in this org' } });
    }

    if (!force) {
      const leases = await pool.query(`
        SELECT COUNT(*) AS n FROM sequence_step_logs
        WHERE  org_id = $1
          AND  channel = 'linkedin'
          AND  status  = 'sending'
          AND  lower(claimed_by_seat) = lower($2)
          AND  lease_expires_at > now()
      `, [orgId, seat.rows[0].public_identifier]);
      const n = parseInt(leases.rows[0].n, 10);
      if (n > 0) {
        return res.status(409).json({
          error: {
            code: 'SEAT_HAS_ACTIVE_LEASES',
            message: `Seat has ${n} in-flight auto-send lease(s). Retry with force=true to unbind anyway.`,
            activeLeases: n,
          },
        });
      }
    }

    await pool.query(`
      DELETE FROM user_linkedin_seats WHERE id = $2 AND org_id = $1
    `, [orgId, seatId]);

    await auditLog(req, 'delete_linkedin_seat', 'linkedin_seat', seatId, {
      orgId,
      userId: seat.rows[0].user_id,
      publicIdentifier: seat.rows[0].public_identifier,
      forced: force,
    });
    res.json({ message: 'Seat unbound', seat: seat.rows[0] });
  } catch (err) {
    console.error(`DELETE /super/orgs/${req.params.orgId}/linkedin-seats/${req.params.seatId} error:`, err);
    res.status(500).json({ error: { message: err.message } });
  }
});


module.exports = router;
