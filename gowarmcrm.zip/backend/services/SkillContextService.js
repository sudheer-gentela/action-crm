// ============================================================================
// services/SkillContextService.js
//
// Builds the canonical prospect payload for the Skills Runner PoC.
// One file, one responsibility: turn (prospectId, orgId, asUserId?) into the
// shape defined by skills/outreach-personalization/schema/gowarm-prospect.json.
//
// Called from routes/skill-context.routes.js.
//
// ─── Canonical sources (no fallbacks, no dual-writes) ────────────────────────
//
//   prospect.name       ← prospects.first_name + last_name
//   prospect.title      ← linkedin_profiles current role; prospects.title only
//                          if no profile capture exists yet
//   prospect.company    ← linkedin_profiles current role; accounts.name only
//                          if no profile capture exists yet
//   prospect.headline   ← linkedin_profiles.headline
//   prospect.about      ← linkedin_profiles.about
//   prospect.experience ← linkedin_profiles.experience
//   prospect.education  ← linkedin_profiles.education
//   prospect.email      ← prospects.email (set on import / extension)
//   prospect.linkedin_url ← prospects.linkedin_url
//   prospect.tenure_in_role_months ← computed from experience[current].start_date
//
//   account.industry/size/website/one_line_description
//                       ← accounts row (filled by enrichmentService apply rules)
//   account.tech_stack  ← accounts.research_meta.<provider>.normalized.tech_stack
//   account.growth_stage ← derived from research_meta.<provider>.normalized
//                           (last_round.type and founded_year)
//
//   signals.account_events
//                       ← synthesized from
//                          accounts.research_meta.<provider>.normalized.last_round
//   signals.linkedin_activity
//                       ← linkedin_profiles.activity, split by kind
// ============================================================================

const { pool } = require('../config/database');
const FitGate  = require('./FitGate');

// ─────────────────────────────────────────────────────────────────────────────
// Config resolvers for the org-configurable enforcement surfaces. Precedence is
// campaign > user > org > built-in default. These read the RAW stored configs
// (already loaded in buildProspectSkillContext) and produce the resolved shapes
// the runner / validator consume. Absent layers are skipped so a zero-config
// org behaves exactly as the built-in defaults.
// ─────────────────────────────────────────────────────────────────────────────
function _tc(c) { return (c && typeof c.title_classifier === 'object' && c.title_classifier) ? c.title_classifier : {}; }
function _arr(v) { return Array.isArray(v) ? v : []; }

// Title classifier: additive stack. function_rules / seniority_rules are
// concatenated campaign→user→org (first match wins downstream, so the more
// specific layer's keywords win). decision_maker is the union across layers
// (empty union => classifier falls back to its built-in definition).
function resolveTitleClassifierConfig(orgC, userC, campC) {
  const o = _tc(orgC), u = _tc(userC), k = _tc(campC);
  const function_rules  = [..._arr(k.function_rules),  ..._arr(u.function_rules),  ..._arr(o.function_rules)];
  const seniority_rules = [..._arr(k.seniority_rules), ..._arr(u.seniority_rules), ..._arr(o.seniority_rules)];
  const unionField = (field) => {
    const set = new Set();
    for (const x of [k, u, o]) {
      const dm = (x && typeof x.decision_maker === 'object') ? x.decision_maker : {};
      for (const v of _arr(dm[field])) set.add(v);
    }
    return [...set];
  };
  const decision_maker = { seniorities: unionField('seniorities'), functions: unionField('functions') };
  if (!function_rules.length && !seniority_rules.length &&
      !decision_maker.seniorities.length && !decision_maker.functions.length) {
    return null;   // nothing configured -> pure built-in classifier
  }
  return { function_rules, seniority_rules, decision_maker };
}

// Fit rules: layered keyed-merge (default -> org -> user -> campaign), later
// layers override by (field+requirement) and add new. Always returns a
// non-empty resolved set (defaults included).
function resolveFitRulesConfig(orgC, userC, campC) {
  const fr = (c) => (c && Array.isArray(c.fit_rules)) ? c.fit_rules : [];
  return FitGate.resolveFitRules([FitGate.DEFAULT_FIT_RULES, fr(orgC), fr(userC), fr(campC)]);
}

// Outreach caps: deep-ish merge org < user < campaign. email caps merge per
// intent (word fields); linkedin caps replace per intent (single number).
function resolveOutreachCapsConfig(orgC, userC, campC) {
  const pick = (c) => (c && typeof c.outreach_caps === 'object' && c.outreach_caps) ? c.outreach_caps : {};
  const email = {}; const linkedin = {};
  for (const L of [pick(orgC), pick(userC), pick(campC)]) {
    if (L.email && typeof L.email === 'object') {
      for (const [intent, caps] of Object.entries(L.email)) {
        if (caps && typeof caps === 'object') email[intent] = { ...(email[intent] || {}), ...caps };
      }
    }
    if (L.linkedin && typeof L.linkedin === 'object') {
      for (const [intent, n] of Object.entries(L.linkedin)) {
        if (Number.isFinite(Number(n))) linkedin[intent] = Number(n);
      }
    }
  }
  if (!Object.keys(email).length && !Object.keys(linkedin).length) return null;
  return { email, linkedin };
}

// Hook recency days: campaign ?? user ?? org ?? null (null => splitLinkedIn
// activity uses the built-in POST_RECENCY_DAYS).
function resolveRecencyDays(orgC, userC, campC) {
  for (const c of [campC, userC, orgC]) {
    if (c && Number.isInteger(c.hook_recency_days) && c.hook_recency_days > 0) return c.hook_recency_days;
  }
  return null;
}

// ─────────────────────────────────────────────────────────────────────────────
// safeQuery — only for queries against tables that may legitimately be absent
// for a given prospect (specifically: linkedin_profiles, sequence_enrollments,
// prospecting_activities). For required tables (prospects, accounts, users,
// organizations) errors propagate.
// ─────────────────────────────────────────────────────────────────────────────
async function safeQuery(client, sql, params) {
  try {
    const r = await client.query(sql, params);
    return r.rows;
  } catch (err) {
    if (err.code === '42P01' || err.code === '42703') {
      console.warn('[skill-context] Optional query skipped:', err.message);
      return [];
    }
    throw err;
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Title-based seniority and function inference.
// Naïve but stable — runs against the captured LinkedIn current-role title.
// ─────────────────────────────────────────────────────────────────────────────
function inferSeniority(title) {
  if (!title) return null;
  const t = title.toLowerCase();
  if (/\b(founder|co-founder|ceo|coo|cfo|cto|cmo|cro|cpo|cio|chief)\b/.test(t)) return 'c_level';
  if (/\b(vp|vice president|svp|evp)\b/.test(t)) return 'vp';
  if (/\b(director|head of)\b/.test(t)) return 'director';
  if (/\b(manager|lead)\b/.test(t)) return 'manager';
  return 'ic';
}

function inferFunction(title) {
  if (!title) return null;
  const t = title.toLowerCase();
  if (/\b(sales|account exec|ae|sdr|bdr|revenue)\b/.test(t)) return 'sales';
  if (/\b(revops|rev ops|sales ops|sales operations)\b/.test(t)) return 'revops';
  if (/\b(marketing|growth|demand gen|brand)\b/.test(t)) return 'marketing';
  if (/\b(engineer|developer|architect|cto|technical)\b/.test(t)) return 'engineering';
  if (/\b(product|pm|product manager)\b/.test(t)) return 'product';
  if (/\b(finance|cfo|controller)\b/.test(t)) return 'finance';
  if (/\b(people|hr|talent|recruiting)\b/.test(t)) return 'people';
  if (/\b(operations|coo|ops)\b/.test(t)) return 'operations';
  return null;
}

// ─────────────────────────────────────────────────────────────────────────────
// Pick the prospect's current role from the captured experience array.
//
// "Current" = end_date is null/empty/"present" (case-insensitive). LinkedIn
// lists current roles at the top, so the first match is reliable. Falls back
// to experience[0] if nothing matches; returns null on an empty array.
// ─────────────────────────────────────────────────────────────────────────────
function pickCurrentRole(experience) {
  if (!Array.isArray(experience) || experience.length === 0) return null;
  const isCurrent = (e) => {
    const ed = e?.end_date;
    if (ed == null) return true;
    const s = String(ed).trim().toLowerCase();
    return s === '' || s === 'present';
  };
  return experience.find(isCurrent) || experience[0];
}

// ─────────────────────────────────────────────────────────────────────────────
// Compute tenure-in-role months from the current role's start_date.
//
// LinkedIn-captured start_date can be 'YYYY-MM-DD', 'YYYY-MM', or 'YYYY';
// the JS Date constructor handles the first two; 'YYYY' alone parses to Jan 1.
// Returns null if we can't get a positive integer answer.
// ─────────────────────────────────────────────────────────────────────────────
function computeTenureMonths(currentRole) {
  if (!currentRole?.start_date) return null;
  const start = new Date(currentRole.start_date);
  if (Number.isNaN(start.getTime())) return null;
  const now = new Date();
  const months = (now.getUTCFullYear() - start.getUTCFullYear()) * 12
               + (now.getUTCMonth() - start.getUTCMonth());
  return months >= 0 ? months : null;
}

// ─────────────────────────────────────────────────────────────────────────────
// Eligibility for a post to be used as a personalization hook.
//
// Outreach must anchor on what the PROSPECT THEMSELVES recently said — not on
// things they commented on or merely reacted to, and not on stale activity.
// Two rules, both enforced here at the source so the skill physically cannot
// reach for ineligible activity regardless of prompt wording:
//
//   1. Authorship — only the prospect's own posts. action='posted' (original)
//      and action='quoted_repost' (their own commentary on someone else's post)
//      both contain the prospect's words and qualify. action='reposted' (a
//      plain share with no commentary) is someone else's content and is
//      EXCLUDED. action=null is a legacy capture (pre extension v2) where
//      authorship cannot be confirmed, so it is also EXCLUDED — we require an
//      explicit own-post action rather than assuming originality.
//
//   2. Recency — posted within the last POST_RECENCY_DAYS. A post whose
//      occurred_at is missing or unparseable cannot be proven recent, so it is
//      EXCLUDED (strict: when in doubt, leave it out).
// ─────────────────────────────────────────────────────────────────────────────
const POST_RECENCY_DAYS  = 14;
const OWN_POST_ACTIONS   = new Set(['posted', 'quoted_repost']);

function isOwnAuthoredPost(action) {
  return OWN_POST_ACTIONS.has(action);
}

function isRecentPost(occurredAt, recencyDays) {
  if (!occurredAt) return false;
  const t = new Date(occurredAt).getTime();
  if (!Number.isFinite(t)) return false;
  const ageMs = Date.now() - t;
  if (ageMs < 0) return true;   // future-dated (clock skew) — treat as recent
  const days = Number.isInteger(recencyDays) && recencyDays > 0 ? recencyDays : POST_RECENCY_DAYS;
  return ageMs <= days * 24 * 60 * 60 * 1000;
}

// ─────────────────────────────────────────────────────────────────────────────
// Build the prospect's LinkedIn activity for hook selection.
//
// Each raw item is {id, kind, occurred_at, text, ...}. We surface ONLY the
// prospect's own recent posts. comments and reactions are deliberately dropped
// (returned empty) — they are never valid hook material. The keys are kept for
// schema stability (gowarm-prospect.json still lists comments/reactions).
// ─────────────────────────────────────────────────────────────────────────────
function splitLinkedInActivity(activity, recencyDays) {
  const out = { posts: [], comments: [], reactions: [] };
  if (!Array.isArray(activity)) return out;

  for (const item of activity) {
    if (!item || item.kind !== 'post') continue;       // drop comments + reactions
    if (!isOwnAuthoredPost(item.action)) continue;     // drop plain reposts
    if (!isRecentPost(item.occurred_at, recencyDays)) continue;  // drop stale posts

    out.posts.push({
      id: item.id,
      posted_at: item.occurred_at,
      text: item.text,
      engagement_count: item.engagement_count ?? null,
      topic_tags: item.topic_tags || [],
      // action is one of 'posted' | 'quoted_repost' after filtering.
      action: item.action ?? null,
      // For quoted reposts: the prospect's own commentary above the embedded
      // original. Use this as the personalization hook — their actual words.
      commentary: item.commentary ?? null,
      // The body of the embedded original post being amplified. Do NOT cite
      // this as the prospect's own words.
      quoted_text: item.quoted_text ?? null,
      // The author of the embedded original post, for correct attribution
      // ("saw you share Satyajeet's take on...").
      quoted_author: item.quoted_author ?? null,
    });
  }

  out.posts.sort((a, b) => new Date(b.posted_at) - new Date(a.posted_at));

  return out;
}

// ─────────────────────────────────────────────────────────────────────────────
// Org-config + user-config merge. Union with explicit exclusion across
// products, value props, target personas, case studies, and competitors.
// User additions can never re-add what user exclusions removed.
// ─────────────────────────────────────────────────────────────────────────────
// Optional provenance: when `sink` (an array) is supplied, each surviving item
// is also pushed as { value, source }, with `baseSource` for org/campaign items
// and `addSource` for user additions. `displayFn` maps an item to a readable
// value (defaults to the item itself). Omitting these args preserves the exact
// original behaviour and return shape (used by all non-explain callers + tests).
function mergeAndExclude({
  orgItems, userAdditions, userExclusions, keyFn,
  baseSource, addSource, sink, displayFn,
}) {
  const orgArr = Array.isArray(orgItems) ? orgItems : [];
  const addArr = Array.isArray(userAdditions) ? userAdditions : [];
  const exclArr = Array.isArray(userExclusions) ? userExclusions : [];
  const recordsTo = Array.isArray(sink) ? sink : null;
  const display = typeof displayFn === 'function' ? displayFn : (x => x);

  const normKey = (item) => {
    const k = keyFn(item);
    if (k == null) return { primary: null, all: [] };
    if (typeof k === 'string') return { primary: k, all: [k] };
    return { primary: k.primary, all: k.all || (k.primary ? [k.primary] : []) };
  };

  const excludedKeys = new Set();
  for (const e of exclArr) {
    const wrapped = typeof e === 'string' ? { _str: e } : e;
    const { all } = normKey(wrapped);
    for (const k of all) excludedKeys.add(k);
  }
  const isExcluded = (allKeys) => allKeys.some(k => excludedKeys.has(k));

  const merged = [];
  const seenPrimary = new Set();

  for (const item of orgArr) {
    const { primary, all } = normKey(item);
    if (!primary || seenPrimary.has(primary) || isExcluded(all)) continue;
    merged.push(item);
    seenPrimary.add(primary);
    if (recordsTo) recordsTo.push({ value: display(item), source: baseSource || 'org' });
  }
  for (const item of addArr) {
    const { primary, all } = normKey(item);
    if (!primary || seenPrimary.has(primary) || isExcluded(all)) continue;
    merged.push(item);
    seenPrimary.add(primary);
    if (recordsTo) recordsTo.push({ value: display(item), source: addSource || 'user' });
  }
  return merged;
}

// Key functions — all normalize to lowercased trimmed strings.
const stringKey = (item) => {
  if (typeof item === 'string') return item.trim().toLowerCase();
  if (item?._str)               return String(item._str).trim().toLowerCase();
  if (item?.name)               return String(item.name).trim().toLowerCase();
  return null;
};
const productKey = stringKey;
// Case studies can be excluded by id OR by customer name.
const caseKey = (item) => {
  if (!item) return null;
  if (typeof item === 'string') {
    const s = item.trim().toLowerCase();
    return { primary: s, all: [s] };
  }
  if (item._str) {
    const s = String(item._str).trim().toLowerCase();
    return { primary: s, all: [s] };
  }
  const id  = item.id       ? String(item.id).trim().toLowerCase() : null;
  const cus = item.customer ? String(item.customer).trim().toLowerCase() : null;
  if (!id && !cus) return null;
  return { primary: id || cus, all: [id, cus].filter(Boolean) };
};

// ─────────────────────────────────────────────────────────────────────────────
// buildOrgContext — assembles the rep-side context block.
//
// Resolution cascade (Slice 1):
//   org_baseline → campaign_override → user_layer (add/exclude)
//
// Per-field rules:
//   pitch            : campaign REPLACES org (if non-empty); no user layer
//   products         : campaign REPLACES org (if non-empty) → + user add/exclude
//   value_props      : campaign REPLACES org (if non-empty) → + user add/exclude
//   target_personas  : campaign REPLACES org (if non-empty) → + user add/exclude
//   case_studies     : campaign REPLACES org (if non-empty) → + user add/exclude
//   hook_preferences : user > campaign > org   (user is per-rep standing pref;
//                      per-run picker in runProspectSkill still wins above all)
//   competitors      : competitors-table ∪ user.custom_competitors − user.excluded_competitors
//                      (campaign layer not applied — competitor list is org-wide)
//   rep              : user prospecting_config + users-table fallback
//   voice            : user only
//   guardrails       : org ∪ campaign ∪ user (additive — campaigns can ADD
//                      restrictions, never loosen them)
// ─────────────────────────────────────────────────────────────────────────────
// Slice 1: campaign override layer. For products / value_props /
// target_personas / case_studies / hook_preferences, a non-empty array on the
// campaign override REPLACES the org array. For banned_phrasings and
// required_disclaimers, the campaign array is UNIONED with org — campaigns
// can add restrictions, never loosen them.
//
// Semantics rationale: when a rep configures a campaign with its own value
// props, they mean "use these *instead of* the org defaults" — a merge would
// mix old and new pitches and defeat the point. Guardrails differ because
// loosening them is never desired; campaigns are additive there.
//
// "Empty array on campaign override = inherit from org" is the rule. To
// explicitly clear a field for a campaign (e.g. no products at all), delete
// the entire campaign override via the DELETE endpoint — a deliberate
// simplicity tradeoff for Slice 1.
function resolveCampaignReplacement(orgItems, campaignItems) {
  const c = Array.isArray(campaignItems) ? campaignItems : [];
  if (c.length > 0) return c;
  return Array.isArray(orgItems) ? orgItems : [];
}

function buildOrgContext({
  orgConfig, campaignConfig, userConfig, repUser, competitors, campaignSender, userSender,
  // Piece 5: when an operator runs a campaign AS a client (client-owned sender),
  // user-level custom_* ADDITIONS are suppressed for the four campaign-controlled
  // fields. Exclusions still apply. Self-serve (clientRun=false) is UNCHANGED.
  clientRun = false,
  // Piece 6b: when explain is set, populate provenanceOut (a mutable object) with
  // per-item { value, source } for the four merged fields + rep. Does NOT change
  // the return shape — provenance is written out-of-band.
  explain = false,
  campaignId = null,
  userId = null,
  provenanceOut = null,
}) {
  const oc = orgConfig      || {};
  const cc = campaignConfig || {};
  const uc = userConfig     || {};

  // Per-field base layer source label: 'campaign:<id>' when the campaign array
  // replaced org for that field, else 'org'. User additions are 'user:<id>'.
  const collect = explain && provenanceOut && typeof provenanceOut === 'object';
  const addSource = `user:${userId != null ? userId : '?'}`;
  const baseSrc = (campaignArr) =>
    (Array.isArray(campaignArr) && campaignArr.length > 0)
      ? `campaign:${campaignId != null ? campaignId : '?'}`
      : 'org';
  const strDisplay  = (it) => (typeof it === 'string' ? it : (it && it.name) ? it.name : String(it));
  const caseDisplay = (it) => {
    if (typeof it === 'string') return it;
    if (it && (it.customer || it.id)) return it.customer || it.id;
    return String(it);
  };

  // ── Replacement layer: campaign overrides org for these fields ────────────
  // Pitch is a scalar string: non-empty campaign value replaces org, empty
  // inherits. There is no user layer for pitch — it is a campaign/org concern.
  const ocPitch = (typeof oc.pitch === 'string') ? oc.pitch.trim() : '';
  const ccPitch = (typeof cc.pitch === 'string') ? cc.pitch.trim() : '';
  const effectivePitch = ccPitch || ocPitch || null;
  if (collect) {
    provenanceOut.pitch = effectivePitch
      ? [{ value: effectivePitch, source: ccPitch ? `campaign:${campaignId != null ? campaignId : '?'}` : 'org' }]
      : [];
  }

  const effectiveProducts        = resolveCampaignReplacement(oc.products, cc.products);
  const effectiveValueProps      = resolveCampaignReplacement(oc.default_value_props,          cc.default_value_props);
  const effectivePersonas        = resolveCampaignReplacement(oc.default_target_personas,      cc.default_target_personas);
  const effectiveCaseStudies     = resolveCampaignReplacement(oc.default_case_study_summaries, cc.default_case_study_summaries);

  // Hook preferences: campaign array replaces org array when non-empty. We
  // pass the resolved categories into the returned context — the skill reads
  // org_context.hook_preferences.preferred_categories at run time.
  const orgHookCats      = Array.isArray(oc.hook_preferences?.preferred_categories) ? oc.hook_preferences.preferred_categories : [];
  const campaignHookCats = Array.isArray(cc.hook_preferences?.preferred_categories) ? cc.hook_preferences.preferred_categories : [];
  const effectiveHookCats = campaignHookCats.length > 0 ? campaignHookCats : orgHookCats;

  // ── User add/exclude applies AFTER campaign replacement ───────────────────
  // Piece 5: under clientRun, the user-layer ADDITIONS are dropped for these
  // four campaign-controlled merges (exclusions retained).
  const products = mergeAndExclude({
    orgItems:       effectiveProducts,
    userAdditions:  clientRun ? [] : uc.custom_products,
    userExclusions: uc.excluded_products,
    keyFn:          productKey,
    baseSource:     baseSrc(cc.products),
    addSource,
    displayFn:      strDisplay,
    sink:           collect ? (provenanceOut.products = []) : null,
  });

  const valueProps = mergeAndExclude({
    orgItems:       effectiveValueProps,
    userAdditions:  clientRun ? [] : uc.custom_value_props,
    userExclusions: uc.excluded_value_props,
    keyFn:          stringKey,
    baseSource:     baseSrc(cc.default_value_props),
    addSource,
    displayFn:      strDisplay,
    sink:           collect ? (provenanceOut.value_props = []) : null,
  });

  const targetPersonas = mergeAndExclude({
    orgItems:       effectivePersonas,
    userAdditions:  clientRun ? [] : uc.custom_target_personas,
    userExclusions: uc.excluded_target_personas,
    keyFn:          stringKey,
    baseSource:     baseSrc(cc.default_target_personas),
    addSource,
    displayFn:      strDisplay,
    sink:           collect ? (provenanceOut.target_personas = []) : null,
  });

  const caseStudies = mergeAndExclude({
    orgItems:       effectiveCaseStudies,
    userAdditions:  clientRun ? [] : uc.custom_case_studies,
    userExclusions: uc.excluded_case_studies,
    keyFn:          caseKey,
    baseSource:     baseSrc(cc.default_case_study_summaries),
    addSource,
    displayFn:      caseDisplay,
    sink:           collect ? (provenanceOut.case_studies = []) : null,
  });

  const competitorObjs = mergeAndExclude({
    orgItems:       competitors,
    userAdditions:  (uc.custom_competitors || []).map(s =>
      typeof s === 'string' ? { name: s } : s
    ),
    userExclusions: uc.excluded_competitors,
    keyFn:          stringKey,
  });
  const competitorNames = competitorObjs.map(c => c.name).filter(Boolean);

  // Rep / sender identity. Priority:
  //   1. Campaign-pinned sender account (explicit per-campaign identity override)
  //   2. The executing user's own connected sender account (My Preferences) —
  //      the same row the firer signs with, so draft == sent identity
  //   3. Fallback: the user's My Outreach Style signature (prospecting_config.rep)
  //      — only when no sender account is connected
  //   4. Last resort: the user's name from the users table, no signature
  // Note (Policy A): the model signs off NAME-ONLY; the full signature is
  // appended at send by SequenceStepFirer. email_signature/linkedin_signature
  // are surfaced here for the preview ("Show with signature") and lint only.
  let rep;
  if (campaignSender) {
    rep = {
      name: campaignSender.display_name
            || campaignSender.label
            || campaignSender.email
            || 'Sales rep',
      title: null,                                  // signature text is self-contained
      email_signature: campaignSender.signature || null,
      linkedin_signature: campaignSender.linkedin_signature || null,
    };
  } else if (userSender) {
    rep = {
      name: userSender.display_name
            || userSender.label
            || userSender.email
            || 'Sales rep',
      title: null,
      email_signature: userSender.signature || null,
      linkedin_signature: userSender.linkedin_signature || null,   // fixes the prior null
    };
  } else {
    const repFromUser = uc.rep || {};
    const fallbackName = repUser
      ? [repUser.first_name, repUser.last_name].filter(Boolean).join(' ')
      : '';
    rep = {
      name: fallbackName || 'Sales rep',
      title: repFromUser.title_for_signature || null,
      email_signature: repFromUser.email_signature_block || null,
      linkedin_signature: null,
    };
  }

  if (collect) {
    provenanceOut.rep = {
      source: campaignSender ? 'campaign_sender'
            : (userSender ? 'user_sender_account' : 'executing_user'),
      sender_account_id: campaignSender ? campaignSender.id
                       : (userSender ? userSender.id : null),
      client_run: !!clientRun,
    };
  }

  // ── Guardrails: additive across org, campaign, and user ───────────────────
  const orgBanned      = Array.isArray(oc.guardrails?.banned_phrasings) ? oc.guardrails.banned_phrasings : [];
  const campaignBanned = Array.isArray(cc.guardrails?.banned_phrasings) ? cc.guardrails.banned_phrasings : [];
  const userAvoid      = Array.isArray(uc.voice?.avoid_phrases)         ? uc.voice.avoid_phrases         : [];

  const orgDisc      = Array.isArray(oc.guardrails?.required_disclaimers) ? oc.guardrails.required_disclaimers : [];
  const campaignDisc = Array.isArray(cc.guardrails?.required_disclaimers) ? cc.guardrails.required_disclaimers : [];

  const guardrailsExtra = {
    banned_phrasings:     [...new Set([...orgBanned, ...campaignBanned, ...userAvoid])],
    required_disclaimers: [...new Set([...orgDisc,   ...campaignDisc])],
  };

  // hook_preferences: prefer user's per-rep override when present, else the
  // effective (campaign-or-org) categories. The skill's per-run picker
  // (passed via runProspectSkill's hookPreferences arg) still wins over this
  // — that path injects directly into org_context.hook_preferences.
  const userHookCats = Array.isArray(uc.hook_preferences?.preferred_categories) ? uc.hook_preferences.preferred_categories : [];
  const resolvedHookPrefs = userHookCats.length > 0
    ? { preferred_categories: userHookCats }
    : (effectiveHookCats.length > 0 ? { preferred_categories: effectiveHookCats } : null);

  return {
    rep,
    pitch: effectivePitch,
    products,
    value_props: valueProps,
    target_personas: targetPersonas,
    case_study_summaries: caseStudies,
    competitors: competitorNames,
    voice: uc.voice || null,
    hook_preferences: resolvedHookPrefs,
    guardrails_extra: guardrailsExtra,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// pickEnrichmentNormalized — provider-agnostic reader of accounts.research_meta.
//
// research_meta is shaped like:
//   { coresignal: { status: 'ok', enriched_at, normalized: {...}, raw: {...} },
//     <other_provider>: { ... } }
//
// We pick the first entry with status='ok' and a normalized object. When
// ENRICHMENT_PROVIDER changes in env, this reader keeps working unchanged.
// ─────────────────────────────────────────────────────────────────────────────
function pickEnrichmentNormalized(researchMeta) {
  if (!researchMeta || typeof researchMeta !== 'object') return null;
  for (const key of Object.keys(researchMeta)) {
    const block = researchMeta[key];
    if (
      block &&
      typeof block === 'object' &&
      block.status === 'ok' &&
      block.normalized &&
      typeof block.normalized === 'object'
    ) {
      return { provider: key, normalized: block.normalized };
    }
  }
  return null;
}

// ─────────────────────────────────────────────────────────────────────────────
// deriveGrowthStage — only emit a value when the signal is strong.
//
// Rules:
//   - Series C+ or growth/late-stage/pre-IPO → 'mature'
//   - Pre-seed / Seed / Series A / B → 'growth'
//   - founded_year < 7 years ago AND no funding info → 'early'
//   - otherwise → null  (the schema allows null and a guess is worse than absence)
//
// We do NOT infer 'public' — CoreSignal's normalized shape doesn't reliably
// expose a public-company flag, and other inferences are too noisy.
// ─────────────────────────────────────────────────────────────────────────────
function deriveGrowthStage(normalized) {
  if (!normalized) return null;

  const round = normalized.last_round;
  const roundType = round?.type ? String(round.type).toLowerCase() : null;

  if (roundType) {
    if (/series\s+(c|d|e|f|g|h)\b/.test(roundType) ||
        /\b(growth|late stage|pre[- ]?ipo)\b/.test(roundType)) {
      return 'mature';
    }
    if (/\b(pre[- ]?seed|seed|series\s+(a|b))\b/.test(roundType)) {
      return 'growth';
    }
  }

  const foundedYear = parseInt(normalized.founded_year, 10);
  if (Number.isInteger(foundedYear)) {
    const ageYears = new Date().getUTCFullYear() - foundedYear;
    if (ageYears >= 0 && ageYears < 7 && !roundType) {
      return 'early';
    }
  }

  return null;
}

// ─────────────────────────────────────────────────────────────────────────────
// mapTechStack — flat string array → schema-required [{tool, category, source}]
//
// The skill's signal-use rule says: "Only reference tools that are IN the
// tech_stack array with a source." Source is the load-bearing field.
// Category isn't in the normalized shape; null is fine.
// ─────────────────────────────────────────────────────────────────────────────
function mapTechStack(normalized, providerName) {
  if (!normalized || !Array.isArray(normalized.tech_stack)) return [];
  return normalized.tech_stack
    .map(t => (typeof t === 'string' ? t.trim() : null))
    .filter(t => t && t.length > 0)
    .map(tool => ({
      tool,
      category: null,
      source: providerName || 'enrichment',
    }));
}

// ─────────────────────────────────────────────────────────────────────────────
// synthesizeFundingEvent — turn last_round into a schema-shaped account_event.
//
// The schema requires a real timestamp (date-time format). The skill ages
// events ("events older than 90 days are stale"), so a fabricated date would
// poison hook selection. If the round date is missing or unparseable we
// return null rather than emit a half-event.
// ─────────────────────────────────────────────────────────────────────────────
function synthesizeFundingEvent(normalized, providerName) {
  if (!normalized) return null;
  const round = normalized.last_round;
  if (!round || typeof round !== 'object') return null;

  const dateRaw = round.date;
  if (!dateRaw) return null;
  const parsed = new Date(dateRaw);
  if (Number.isNaN(parsed.getTime())) return null;
  const timestamp = parsed.toISOString();

  const type = round.type ? String(round.type).trim() : null;
  const amount = round.amount;
  const currency = round.currency || 'USD';

  let amountStr = null;
  if (typeof amount === 'number' && amount > 0) {
    const isUsd = !currency || currency === 'USD';
    const prefix = isUsd ? '$' : '';
    let core;
    if (amount >= 1_000_000_000) core = `${(amount / 1_000_000_000).toFixed(1)}B`;
    else if (amount >= 1_000_000) core = `${Math.round(amount / 1_000_000)}M`;
    else if (amount >= 1_000)     core = `${Math.round(amount / 1_000)}K`;
    else                          core = String(amount);
    amountStr = `${prefix}${core}${isUsd ? '' : ` ${currency}`}`;
  }

  let description;
  if (type && amountStr)      description = `${type} raised (${amountStr})`;
  else if (type)              description = `${type} round`;
  else if (amountStr)         description = `Funding round (${amountStr})`;
  else                        return null;  // date alone is too thin

  return {
    type: 'funding',
    description,
    source: providerName || 'enrichment',
    source_url: null,
    timestamp,
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// buildAccountEvents — currently sourced exclusively from enrichment.
//
// In the future we'll layer additional sources (news APIs, manual notes from
// the rep). When we add them, this function is the integration point — every
// source converts to the canonical shape and merges into `events` here.
// ─────────────────────────────────────────────────────────────────────────────
function buildAccountEvents(account) {
  const events = [];
  const enrichment = pickEnrichmentNormalized(account?.research_meta);
  if (enrichment) {
    const fundingEvent = synthesizeFundingEvent(enrichment.normalized, enrichment.provider);
    if (fundingEvent) events.push(fundingEvent);
  }
  events.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  return events.slice(0, 10);
}

// ─────────────────────────────────────────────────────────────────────────────
// buildEngagementHistory — emails + prospecting activities, newest-first.
// ─────────────────────────────────────────────────────────────────────────────
async function buildEngagementHistory(client, prospect, orgId) {
  if (!prospect) return [];
  const events = [];

  if (prospect.email) {
    const emails = await safeQuery(client,
      `SELECT id, subject, direction, sent_at
         FROM emails
        WHERE org_id = $1
          AND (LOWER(to_address) = LOWER($2) OR LOWER(from_address) = LOWER($2))
        ORDER BY sent_at DESC NULLS LAST
        LIMIT 30`,
      [orgId, prospect.email]
    );
    for (const e of emails) {
      events.push({
        type: e.direction === 'sent' ? 'email_sent' : 'email_received',
        timestamp: e.sent_at,
        summary: e.subject || '(no subject)',
        direction: e.direction === 'sent' ? 'outbound' : 'inbound',
      });
    }
  }

  const activities = await safeQuery(client,
    `SELECT activity_type, description, metadata, created_at
       FROM prospecting_activities
      WHERE prospect_id = $1
      ORDER BY created_at DESC
      LIMIT 30`,
    [prospect.id]
  );
  // Non-LinkedIn activity types that flow straight into the engagement feed.
  const typeMap = {
    meeting_booked:               'meeting_booked',
    meeting_held:                 'meeting_held',
    meeting_no_show:              'meeting_no_show',
  };
  // LinkedIn touches are stored as a single bucket activity_type='linkedin_event'
  // with the granular event in metadata->>'event'. Normalise those granular
  // events into the canonical 'linkedin_*' type names that downstream consumers
  // (and the prior version of this map) expect. Without this, the LinkedIn
  // branch of the engagement feed is silently empty — no row ever had
  // activity_type='linkedin_connection_sent' etc.
  const LINKEDIN_EVENT_TYPE_MAP = {
    connection_request_sent: 'linkedin_connection_sent',
    connection_accepted:     'linkedin_connection_accepted',
    message_sent:            'linkedin_message_sent',
    inmail_sent:             'linkedin_message_sent',
    reply_received:          'linkedin_message_replied',
  };
  for (const a of activities) {
    let type = typeMap[a.activity_type];
    if (!type && a.activity_type === 'linkedin_event') {
      const meta = a.metadata || {};
      const ev = typeof meta === 'string' ? (JSON.parse(meta).event) : meta.event;
      type = LINKEDIN_EVENT_TYPE_MAP[ev];
    }
    if (!type) continue;
    events.push({
      type,
      timestamp: a.created_at,
      summary: a.description || null,
      direction: null,
    });
  }

  events.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));
  return events.slice(0, 50);
}

// ─────────────────────────────────────────────────────────────────────────────
// buildSequenceState — current sequence enrollment, if any.
// ─────────────────────────────────────────────────────────────────────────────
async function buildSequenceState(client, prospect) {
  if (!prospect) return null;

  const rows = await safeQuery(client,
    `SELECT se.sequence_id, se.current_step, se.next_step_due,
            se.enrolled_at, s.name AS sequence_name,
            (SELECT COUNT(*) FROM sequence_steps ss WHERE ss.sequence_id = se.sequence_id) AS total_steps
       FROM sequence_enrollments se
       JOIN sequences s ON s.id = se.sequence_id
      WHERE se.prospect_id = $1
        AND se.status = 'active'
      ORDER BY se.enrolled_at DESC
      LIMIT 1`,
    [prospect.id]
  );
  if (rows.length === 0) return null;
  const r = rows[0];

  const channelRows = await safeQuery(client,
    `SELECT DISTINCT ss.channel
       FROM sequence_steps ss
      WHERE ss.sequence_id = $1
        AND ss.step_order < $2`,
    [r.sequence_id, r.current_step]
  );

  return {
    sequence_id: String(r.sequence_id),
    sequence_name: r.sequence_name,
    current_step: r.current_step,
    total_steps: parseInt(r.total_steps, 10) || 0,
    last_touched_at: prospect.last_outreach_at || null,
    next_scheduled_at: r.next_step_due || null,
    channels_used: channelRows.map(c => c.channel).filter(Boolean),
  };
}

// ─────────────────────────────────────────────────────────────────────────────
// buildProspectSkillContext — main entry.
// ─────────────────────────────────────────────────────────────────────────────
// ----------------------------------------------------------------------------
// buildPriorSteps -- prior outbound steps already generated for this prospect,
// oldest-first, so the skill can make each follow-up differ from EVERY earlier
// step (kills the "two steps anchored to the same post" repetition). Sourced
// from skill_runs, which already stores hook_category + output per run.
// ----------------------------------------------------------------------------
async function buildPriorSteps(client, prospect, orgId) {
  if (!prospect) return [];
  const rows = await safeQuery(client,
    `SELECT skill_name, hook_category, output, created_at
       FROM skill_runs
      WHERE prospect_id = $1 AND org_id = $2 AND status = 'ok'
        AND skill_name IN ('outreach-email', 'outreach-linkedin')
      ORDER BY created_at ASC
      LIMIT 20`,
    [prospect.id, orgId]
  );
  return rows.map((r, i) => {
    const out = (r.output && typeof r.output === 'object') ? r.output : null;
    const angle = out ? (out.rationale || (out.hook && out.hook.primary_signal_id) || null) : null;
    return {
      step_order: i + 1,
      channel: r.skill_name === 'outreach-linkedin' ? 'linkedin' : 'email',
      hook_category: r.hook_category || null,
      angle,
    };
  });
}

async function buildProspectSkillContext({ prospectId, orgId, asUserId, explain = false }) {
  let client;
  try {
    client = await pool.connect();

    await client.query(
      `SELECT set_config('app.current_org_id', $1::text, true)`,
      [String(orgId)]
    );

    // ── Prospect ────────────────────────────────────────────────────────
    const prospectRes = await client.query(
      `SELECT * FROM prospects
        WHERE id = $1 AND org_id = $2 AND deleted_at IS NULL`,
      [prospectId, orgId]
    );
    if (prospectRes.rows.length === 0) {
      const e = new Error('Prospect not found');
      e.statusCode = 404;
      throw e;
    }
    const prospect = prospectRes.rows[0];

    // ── Account (optional) ──────────────────────────────────────────────
    let account = null;
    if (prospect.account_id) {
      const accountRes = await client.query(
        `SELECT * FROM accounts WHERE id = $1 AND org_id = $2`,
        [prospect.account_id, orgId]
      );
      account = accountRes.rows[0] || null;
    }

    // ── LinkedIn profile (canonical source for headline/about/exp/edu/activity) ──
    //
    // Joined by slug, parsed from prospect.linkedin_url with the same regex
    // the writer (linkedin-profiles.routes.js) uses.
    const liProfileRows = await safeQuery(client,
      `SELECT headline, about, experience, education, activity
         FROM linkedin_profiles
        WHERE org_id = $1
          AND linkedin_slug = lower(substring($2 from '/in/([^/?#]+)'))
        LIMIT 1`,
      [orgId, prospect.linkedin_url || '']
    );
    const liProfile = liProfileRows[0] || null;
    const liExperience = Array.isArray(liProfile?.experience) ? liProfile.experience : [];
    const liEducation  = Array.isArray(liProfile?.education)  ? liProfile.education  : [];
    const liActivity   = Array.isArray(liProfile?.activity)   ? liProfile.activity   : [];

    // ── Org settings → prospecting_config ───────────────────────────────
    const orgRes = await client.query(
      `SELECT settings FROM organizations WHERE id = $1`,
      [orgId]
    );
    const orgConfig = orgRes.rows[0]?.settings?.prospecting_config || null;

    // ── Campaign override → prospecting_config_override (Slice 1) ───────
    // Loaded via safeQuery so environments where the migration hasn't run
    // yet (column missing → 42703) silently fall back to "no override".
    let campaignConfig = null;
    if (prospect.campaign_id) {
      const ccRes = await safeQuery(client,
        `SELECT prospecting_config_override
           FROM prospecting_campaigns
          WHERE id = $1 AND org_id = $2`,
        [prospect.campaign_id, orgId]
      );
      campaignConfig = ccRes[0]?.prospecting_config_override || null;
    }

    // -- Campaign sender identity --------------------------------------------
    // The rep / signature for a campaign run comes from the campaign's
    // configured sender account (prospecting_sender_accounts), NOT the
    // executing user. This is what makes "an operator runs a campaign on a
    // client's behalf" sign as the client. Org-scoped + is_active so a stale
    // or cross-org sender can never surface. Loaded via its own safeQuery so
    // an unmigrated env (sender_account_ids column absent) just falls back to
    // user-based rep resolution.
    let campaignSender = null;
    if (prospect.campaign_id) {
      const sidRows = await safeQuery(client,
        `SELECT sender_account_ids
           FROM prospecting_campaigns
          WHERE id = $1 AND org_id = $2`,
        [prospect.campaign_id, orgId]
      );
      const senderIds = Array.isArray(sidRows[0]?.sender_account_ids)
        ? sidRows[0].sender_account_ids : [];
      if (senderIds.length > 0) {
        // Deterministic pick: lowest-id active sender. Campaigns that rotate
        // multiple senders should keep signatures consistent; the draft
        // anchors on that one sender's identity.
        const saRows = await safeQuery(client,
          `SELECT id, email, label, display_name, signature, linkedin_signature,
                  client_id, user_id
             FROM prospecting_sender_accounts
            WHERE id = ANY($1::int[]) AND org_id = $2 AND is_active = true
            ORDER BY id ASC
            LIMIT 1`,
          [senderIds, orgId]
        );
        campaignSender = saRows[0] || null;
      }
    }

    // Identity fallback: when no campaign sender is pinned, the prospecting
    // module signs from the executing user's own connected sender account
    // (Settings → My Preferences). This is the SAME row the SequenceStepFirer
    // resolves at send time, so the draft identity matches what actually goes
    // out. Only if the user has no active sender account does rep fall back to
    // the My Outreach Style signature (prospecting_config.rep) inside
    // buildOrgContext.
    let userSender = null;
    if (!campaignSender && asUserId) {
      const usRows = await safeQuery(client,
        `SELECT id, email, label, display_name, signature, linkedin_signature
           FROM prospecting_sender_accounts
          WHERE org_id    = $1
            AND user_id   = $2
            AND client_id IS NULL
            AND is_active = true
          ORDER BY
            (CASE WHEN last_reset_at < CURRENT_DATE THEN 0 ELSE emails_sent_today END) ASC,
            last_sent_at ASC NULLS FIRST
          LIMIT 1`,
        [orgId, asUserId]
      );
      userSender = usRows[0] || null;
    }

    // ── User preferences → prospecting_config (only if asUserId provided) ──
    let userConfig = null;
    let repUser = null;
    if (asUserId) {
      const upRes = await safeQuery(client,
        `SELECT preferences FROM user_preferences
          WHERE user_id = $1 AND org_id = $2`,
        [asUserId, orgId]
      );
      userConfig = upRes[0]?.preferences?.prospecting_config || null;

      const userRes = await client.query(
        `SELECT id, first_name, last_name, email, department
           FROM users WHERE id = $1`,
        [asUserId]
      );
      repUser = userRes.rows[0] || null;
    } else if (prospect.owner_id) {
      const userRes = await client.query(
        `SELECT id, first_name, last_name, email, department
           FROM users WHERE id = $1`,
        [prospect.owner_id]
      );
      repUser = userRes.rows[0] || null;
    }

    // ── Competitors (org-scoped) ────────────────────────────────────────
    const competitors = await safeQuery(client,
      `SELECT name FROM competitors WHERE org_id = $1 ORDER BY name`,
      [orgId]
    );

    // ── ICP signals from prospect.icp_signals JSONB ─────────────────────
    const icpSignals = prospect.icp_signals || {};

    // ── Derive prospect title / company from LinkedIn current role ─────
    //
    // LinkedIn profile is the source of truth when captured. Without a
    // capture (no row in linkedin_profiles), fall back to the prospect-row
    // values that came from CSV import or manual creation. The headline
    // column is intentionally NOT a fallback for title — senior-role
    // headlines are usually positioning copy ("Head of X | Future-Focused
    // CMO | PE Growth Operator") and don't parse cleanly into a role label.
    const currentRole = pickCurrentRole(liExperience);
    const title = currentRole?.title
                  || (prospect.title?.trim() ? prospect.title.trim() : null);
    const company = currentRole?.company
                    || (prospect.company_name?.trim() ? prospect.company_name.trim() : null)
                    || account?.name
                    || null;
    const tenureMonths = computeTenureMonths(currentRole);

    // ── Account enrichment (provider-agnostic) ──────────────────────────
    const accountEnrichment = pickEnrichmentNormalized(account?.research_meta);
    const enrichedNormalized = accountEnrichment?.normalized || null;
    const enrichmentProvider = accountEnrichment?.provider || null;

    // ── Engagement + sequence state ─────────────────────────────────────
    const engagementHistory = await buildEngagementHistory(client, prospect, orgId);
    const priorSteps = await buildPriorSteps(client, prospect, orgId);
    const sequenceState = await buildSequenceState(client, prospect);

    // ── Org context ─────────────────────────────────────────────────────
    // Piece 5: a client-owned sender (client_id set) marks an operator running
    // a campaign AS a client → suppress user-layer custom_* additions.
    const clientRun = !!(campaignSender && campaignSender.client_id);
    const provenance = explain ? {} : null;
    const orgContext = buildOrgContext({
      orgConfig,
      campaignConfig,
      userConfig,
      repUser,
      competitors,
      campaignSender,
      userSender,
      clientRun,
      explain,
      campaignId: prospect.campaign_id || null,
      userId: asUserId || prospect.owner_id || null,
      provenanceOut: provenance,
    });

    // Resolve the org-configurable enforcement surfaces (campaign > user > org
    // > built-in). title_classifier + fit_rules ride on _meta (skills ignore
    // _meta); outreach_caps rides on org_context for OutreachValidator; recency
    // feeds splitLinkedInActivity below.
    const resolvedTitleClassifier = resolveTitleClassifierConfig(orgConfig, userConfig, campaignConfig);
    const resolvedFitRules        = resolveFitRulesConfig(orgConfig, userConfig, campaignConfig);
    const resolvedOutreachCaps    = resolveOutreachCapsConfig(orgConfig, userConfig, campaignConfig);
    const resolvedRecencyDays     = resolveRecencyDays(orgConfig, userConfig, campaignConfig);
    if (resolvedOutreachCaps) orgContext.outreach_caps = resolvedOutreachCaps;

    // ── Researcher note (from prospects.research_meta) ──────────────────
    //
    // The Research Queue lets the researcher type an optional note about
    // the prospect. There are three modes:
    //
    //   1. No note   — researcher_note is null. Skill picks its own hook
    //                  from signals.linkedin_activity and account_events
    //                  per org_context.hook_preferences.preferred_categories.
    //
    //   2. Hint mode — researcher_note is populated but signal_override
    //                  is false. The skill receives the note as additional
    //                  context (under signals.researcher_note) and may use,
    //                  ignore, or partially incorporate it — model's call.
    //
    //   3. Override  — researcher_note populated AND signal_override is true.
    //                  The skill MUST use the note as the hook anchor.
    //                  We enforce this by prepending 'researcher_override'
    //                  to preferred_categories so it wins the priority pass.
    //
    // Mode is derived from research_meta written by approve-research. We
    // also surface the source URL and category alongside the note text so
    // the skill's Pattern 7 (researcher_override) can do the right citation.
    const researchMeta = (prospect.research_meta && typeof prospect.research_meta === 'object')
      ? prospect.research_meta : {};
    const researcherNoteText = (typeof researchMeta.signal_summary === 'string' && researchMeta.signal_summary.trim())
      ? researchMeta.signal_summary.trim() : null;
    const researcherNoteOverride = researchMeta.signal_override === true && !!researcherNoteText;
    const researcherNote = researcherNoteText
      ? {
          text:       researcherNoteText,
          category:   researchMeta.signal_category || 'researcher_override',
          source_url: researchMeta.signal_source_url || null,
          override:   researcherNoteOverride,
        }
      : null;

    // When override is on, prepend 'researcher_override' to the hook
    // priority list so the skill picks it first. We mutate a copy of
    // org_context here rather than buildOrgContext so this stays a
    // per-prospect transformation, not an org-wide config change.
    const finalOrgContext = researcherNoteOverride
      ? {
          ...orgContext,
          hook_preferences: {
            ...(orgContext.hook_preferences || {}),
            preferred_categories: [
              'researcher_override',
              ...((orgContext.hook_preferences?.preferred_categories) || [])
                .filter(c => c !== 'researcher_override'),
            ],
          },
        }
      : orgContext;

    // ── Compose ─────────────────────────────────────────────────────────
    const payload = {
      prospect: {
        name: [prospect.first_name, prospect.last_name].filter(Boolean).join(' '),
        title,
        company,
        linkedin_url: prospect.linkedin_url || null,
        email: prospect.email || null,
        seniority_level: inferSeniority(title),
        function: inferFunction(title),
        tenure_in_role_months: tenureMonths,
        headline: liProfile?.headline || null,
        about: liProfile?.about || null,
        experience: liExperience,
        education: liEducation,
      },
      account: {
        name: company,
        industry: account?.industry || null,
        size: account?.size || null,
        growth_stage: deriveGrowthStage(enrichedNormalized),
        tech_stack: mapTechStack(enrichedNormalized, enrichmentProvider),
        website: account?.domain ? `https://${account.domain}` : null,
        one_line_description: account?.description || null,
      },
      icp: {
        fit_score: prospect.icp_score || 0,
        matched_criteria: Array.isArray(icpSignals.matched_criteria)
          ? icpSignals.matched_criteria : [],
        missed_criteria: Array.isArray(icpSignals.missed_criteria)
          ? icpSignals.missed_criteria : [],
        persona_match: icpSignals.persona_match || null,
      },
      signals: {
        account_events: buildAccountEvents(account),
        linkedin_activity: splitLinkedInActivity(liActivity, resolvedRecencyDays),
        // null when the researcher left the queue note blank. The skill
        // checks for non-null and acts per the rules in
        // reference/hook-patterns.md → Pattern 7.
        researcher_note: researcherNote,
      },
      engagement_history: engagementHistory,
      prior_steps: priorSteps,
      sequence_state: sequenceState,
      reply_payload: null,  // populated only by reply-event-triggered skills
      org_context: finalOrgContext,

      // Out-of-band metadata for the runner. The leading underscore marks this
      // as not part of the skill contract — skills MUST ignore it. Used by the
      // runner to attribute skill_runs records back to the right org/prospect
      // without re-querying.
      _meta: {
        org_id: orgId,
        prospect_id: prospect.id,
        rep_user_id: asUserId || prospect.owner_id || null,
        // Rep provenance — lets the runner / dry-run show where the signature
        // came from and catch a wrong-org sender before send.
        rep_source: campaignSender ? 'campaign_sender' : 'executing_user',
        sender_account_id: campaignSender ? campaignSender.id : null,
        // Resolved enforcement config for the runner (campaign > user > org >
        // built-in). _meta is ignored by skills.
        //   fit_rules        — fully merged rule set (always includes defaults)
        //   title_classifier — org/user keyword overrides; null => built-ins only
        fit_rules: resolvedFitRules,
        title_classifier: resolvedTitleClassifier,
      },
    };

    // Piece 6b: explain mode returns provenance alongside the payload. The
    // normal path returns the bare payload (back-compat for the runner's live
    // path and all existing callers).
    return explain ? { payload, provenance } : payload;
  } finally {
    if (client) client.release();
  }
}


// ─────────────────────────────────────────────────────────────────────────────
// buildDealSkillContext — canonical deal payload for the discovery-call-prep
// skill. Extracted verbatim from the retired routes/skill-context.routes.js
// GET /deals/:dealId handler during the 2026 skills integration. The HTTP
// wrapper is gone; this is now called in-process by SkillRunnerService.
//
// Returns the gowarm-deal.json-shaped payload. Throws an Error with
// statusCode=404 when the deal does not exist.
// ─────────────────────────────────────────────────────────────────────────────
async function buildDealSkillContext({ dealId }) {
  let client;
  try {
    client = await pool.connect();
    // ── Step 1: lookup the deal's org_id (pre-RLS) ──
    const dealCoreRes = await client.query(
      `SELECT id, org_id FROM deals WHERE id = $1`,
      [dealId]
    );

    if (dealCoreRes.rows.length === 0) {
      const e = new Error('Deal not found');
      e.statusCode = 404;
      throw e;
    }
    const orgId = dealCoreRes.rows[0].org_id;

    // ── Step 2: set RLS session variable for this connection ──
    await client.query(
      `SELECT set_config('app.current_org_id', $1::text, true)`,
      [String(orgId)]
    );

    // ── Deal (full details) ────────────────────────────────
    const dealRes = await client.query(
      `SELECT id, name, stage, stage_type, playbook_id, created_at,
              value, account_id, economic_buyer_contact_id,
              stage_changed_at, expected_close_date, health, health_score,
              external_crm_type, competitive_competitors,
              buyer_event_description, legal_engaged_user, security_review_user,
              EXTRACT(DAY FROM (NOW() - COALESCE(stage_changed_at, created_at)))::int AS days_in_stage
         FROM deals WHERE id = $1`,
      [dealId]
    );
    const deal = dealRes.rows[0];

    // ── Primary contact: prefer deal_contacts; fall back to economic buyer ──
    let prospectContact = null;
    const dealContacts = await safeQuery(client,
      `SELECT c.id, c.first_name, c.last_name, c.title, c.email,
              c.linkedin_url, c.role_type, c.engagement_level
         FROM deal_contacts dc
         JOIN contacts c ON c.id = dc.contact_id
        WHERE dc.deal_id = $1
        ORDER BY CASE
                   WHEN c.role_type = 'economic_buyer' THEN 1
                   WHEN c.role_type = 'champion'       THEN 2
                   WHEN c.role_type = 'decision_maker' THEN 3
                   ELSE 4
                 END
        LIMIT 1`,
      [dealId]);

    if (dealContacts.length > 0) {
      prospectContact = dealContacts[0];
    } else if (deal.economic_buyer_contact_id) {
      const ebRows = await safeQuery(client,
        `SELECT id, first_name, last_name, title, email, linkedin_url
           FROM contacts WHERE id = $1`,
        [deal.economic_buyer_contact_id]);
      prospectContact = ebRows[0] || null;
    }

    // ── Account ────────────────────────────────────────────
    const accountRows = await safeQuery(client,
      `SELECT id, name, industry, size, location, description, domain
         FROM accounts WHERE id = $1`,
      [deal.account_id]);
    const account = accountRows[0] || {};

    // ── Economic buyer name ───────────────────────────────
    let economicBuyerName = null;
    if (deal.economic_buyer_contact_id) {
      const ebRows = await safeQuery(client,
        `SELECT first_name, last_name, title FROM contacts WHERE id = $1`,
        [deal.economic_buyer_contact_id]);
      if (ebRows[0]) {
        const eb = ebRows[0];
        economicBuyerName = `${eb.first_name} ${eb.last_name}${eb.title ? ' (' + eb.title + ')' : ''}`;
      }
    }

    // ── Champion name ─────────────────────────────────────
    let championName = null;
    const champRows = await safeQuery(client,
      `SELECT c.first_name, c.last_name, c.title
         FROM deal_contacts dc
         JOIN contacts c ON c.id = dc.contact_id
        WHERE dc.deal_id = $1 AND c.role_type = 'champion'
        LIMIT 1`,
      [dealId]);
    if (champRows[0]) {
      const ch = champRows[0];
      championName = `${ch.first_name} ${ch.last_name}${ch.title ? ' (' + ch.title + ')' : ''}`;
    }

    // ── Interaction history — 3 queries (safer than one UNION) ──
    // Emails
    const emails = await safeQuery(client,
      `SELECT 'email' AS type,
              COALESCE(created_at) AS ts,
              COALESCE(subject, '(no subject)') AS summary,
              NULL::text AS direction
         FROM emails
        WHERE deal_id = $1
        ORDER BY created_at DESC NULLS LAST
        LIMIT 10`,
      [dealId]);

    // Meetings
    const meetings = await safeQuery(client,
      `SELECT 'meeting' AS type,
              COALESCE(created_at) AS ts,
              COALESCE(title, '(meeting)') AS summary,
              NULL::text AS direction
         FROM meetings
        WHERE deal_id = $1
        ORDER BY created_at DESC NULLS LAST
        LIMIT 10`,
      [dealId]);

    // Actions
    const actions = await safeQuery(client,
      `SELECT COALESCE(type, 'note') AS type,
              COALESCE(created_at) AS ts,
              COALESCE(description, title, '(action)') AS summary,
              NULL::text AS direction
         FROM actions
        WHERE deal_id = $1
        ORDER BY created_at DESC NULLS LAST
        LIMIT 10`,
      [dealId]);

    const allInteractions = [...emails, ...meetings, ...actions]
      .filter(r => r.ts)
      .sort((a, b) => new Date(b.ts) - new Date(a.ts))
      .slice(0, 10);

    // ── MEDDPICC composed from deals + deal_contacts ──────
    const meddpicc = {
      metrics: null,
      economic_buyer: economicBuyerName,
      decision_criteria: null,
      decision_process: (deal.legal_engaged_user || deal.security_review_user)
        ? `Legal engaged: ${deal.legal_engaged_user ? 'yes' : 'no'}; Security review: ${deal.security_review_user ? 'yes' : 'no'}`
        : null,
      paper_process: null,
      identified_pain: deal.buyer_event_description || null,
      champion: championName,
      competition: deal.competitive_competitors
        ? JSON.stringify(deal.competitive_competitors)
        : null,
    };

    // ── Compose final canonical payload ────────────────────
    const payload = {
      prospect: prospectContact ? {
        name: [prospectContact.first_name, prospectContact.last_name].filter(Boolean).join(' '),
        title: prospectContact.title || '',
        company: account.name || '',
        linkedin_url: prospectContact.linkedin_url || undefined,
        email: prospectContact.email || undefined,
      } : {
        name: 'Unknown',
        title: '',
        company: account.name || '',
      },
      account: {
        industry: account.industry || '',
        size: account.size || '',
        revenue_band: undefined,
        recent_signals: [],
      },
      deal: {
        stage: deal.stage,
        source: deal.external_crm_type ? `external_${deal.external_crm_type}` : 'unknown',
        playbook_id: deal.playbook_id,
        created_at: deal.created_at,
        amount: deal.value ? Number(deal.value) : undefined,
        days_in_stage: deal.days_in_stage || 0,
      },
      interaction_history: allInteractions.map(r => ({
        type: r.type,
        timestamp: r.ts,
        summary: r.summary,
        direction: r.direction || undefined,
      })),
      meddpicc,
    };

    payload._meta = {
      org_id: orgId,
      deal_id: deal.id,
      rep_user_id: null,
    };

    return payload;
  } finally {
    if (client) client.release();
  }
}

module.exports = {
  buildProspectSkillContext,
  buildDealSkillContext,
  // Exported for unit tests of the resolution cascade. Not used by route code.
  buildOrgContext,
};
