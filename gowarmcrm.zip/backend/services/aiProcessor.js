/**
 * AI Email Processor - Full Context Analysis with Template Support
 * CONSOLIDATED: Replaces claudeService.js - single AI processing engine
 *
 * MULTI-ORG changes:
 *   - processEmail(userId, emailId, orgId)
 *   - analyzeDeal(dealId, userId, orgId)
 *   - saveActions(actions, userId, orgId, email, context)
 *   - getPlaybook(userId, orgId)        — queries user_playbooks WHERE (user_id, org_id)
 *   - getPromptTemplate(userId, orgId, templateType) — queries user_prompts WHERE (user_id, org_id, template_type)
 *
 * AGENTIC FRAMEWORK fixes:
 *   - processEmail now passes contacts_mentioned, urgency, and sentiment to AgentObserver
 *   - callClaude now returns { actions, usage } so callers can track tokens with org/user context
 *   - Token tracking moved to processEmail() and analyzeDeal() where org/user are available
 *
 * analyzeEmailSimple, renderTemplate, formatEmailThread, formatMeetings,
 * formatDealHistory, fetchEmail, getDeal, gatherFullContext,
 * gatherDealContext are all unchanged.
 */

const db = require('../config/database');
const SALES_PLAYBOOK = require('../config/salesPlaybook');
const AI_PROMPTS = require('../config/aiPrompts');

const AIClientResolver = require('./ai/AIClientResolver');

const AgentObserver       = require('./AgentObserver');
const TokenTrackingService = require('./TokenTrackingService');

class AIProcessor {

  /**
   * SIMPLE EMAIL ANALYSIS (used by email queue processor)
   * No org context needed — purely stateless text analysis.
   */
  static async analyzeEmailSimple(emailData) {
    const prompt = `You are an AI assistant that analyzes emails and extracts actionable information for a CRM system.

Analyze the following email:

From: ${emailData.from?.emailAddress?.name || emailData.from_address || 'Unknown'} <${emailData.from?.emailAddress?.address || emailData.from_address || 'unknown@email.com'}>
Subject: ${emailData.subject || 'No Subject'}
Date: ${emailData.receivedDateTime || emailData.sent_at || 'Unknown Date'}

Email Body:
${emailData.body?.content?.substring(0, 4000) || emailData.body?.substring(0, 4000) || emailData.bodyPreview || 'No content'}

Extract the following information and respond ONLY with valid JSON (no markdown, no backticks):

{
  "action_items": [
    {
      "description": "Clear, actionable description",
      "deadline": "ISO 8601 date or null if not mentioned",
      "priority": "high|medium|low",
      "estimated_effort": "Brief estimate like '30 minutes' or '2 hours'"
    }
  ],
  "key_contacts": ["email@example.com or contact names"],
  "contacts_mentioned": [
    {
      "name": "Full Name",
      "email": "email@example.com or null",
      "title": "Job title if mentioned or null",
      "role_type": "decision_maker|champion|influencer|technical|null",
      "confidence": 0.0-1.0
    }
  ],
  "category": "Sales|Support|Meeting Request|Follow-up|Task|Information|Other",
  "sentiment": "positive|neutral|negative|urgent",
  "urgency": "high|medium|low",
  "priority": "high|medium|low",
  "summary": "1-2 sentence summary of the email",
  "requires_response": true or false,
  "suggested_actions": ["Brief action suggestions"],
  "suggested_reply": {
    "subject": "Reply subject or null if no reply needed",
    "body": "Brief suggested reply or null"
  }
}

Important:
- Only include action_items if there are clear, specific tasks mentioned
- Set requires_response to true if the email expects a reply
- Estimate priority based on urgency indicators, deadlines, and sender importance
- contacts_mentioned should include any people referenced in the email who might be CRM contacts
- suggested_reply should only be populated if requires_response is true and urgency is high
- Return valid JSON only, no other text`;

    try {
      const { adapter, model } =
        await AIClientResolver.resolve(null, null, 'email_analysis');

      const { text: responseText } = await adapter.complete({
        model,
        prompt,
        maxTokens: 2000,
        temperature: 0.3,
      });

      const cleanedText = responseText
        .replace(/```json\n?/g, '')
        .replace(/```\n?/g, '')
        .trim();

      const analysis = JSON.parse(cleanedText);
      if (!analysis.action_items || !Array.isArray(analysis.action_items)) {
        analysis.action_items = [];
      }
      // Ensure new fields have defaults
      if (!analysis.contacts_mentioned)  analysis.contacts_mentioned = [];
      if (!analysis.urgency)             analysis.urgency = analysis.priority || 'medium';
      if (!analysis.sentiment)           analysis.sentiment = 'neutral';
      if (!analysis.suggested_reply)     analysis.suggested_reply = null;

      return analysis;

    } catch (error) {
      console.error('Claude analysis error:', error);
      return {
        action_items: [], key_contacts: [], contacts_mentioned: [],
        category: 'Information', sentiment: 'neutral', urgency: 'medium', priority: 'medium',
        summary: emailData.subject || 'Email analysis failed',
        requires_response: false, suggested_actions: [], suggested_reply: null,
        error: error.message
      };
    }
  }

  /**
   * ADVANCED CONTEXT-AWARE EMAIL ANALYSIS
   * @param {number} userId
   * @param {number|string} emailId
   * @param {number} orgId
   */
  static async processEmail(userId, emailId, orgId) {
    try {
      console.log(`🤖 AI Processing email ${emailId}...`);

      const email           = await this.fetchEmail(userId, emailId);
      const context         = await this.gatherFullContext(email, userId);
      const promptTemplate  = await this.getPromptTemplate(userId, orgId, 'email_analysis');
      const playbook        = await this.getPlaybook(userId, orgId);
      const prompt          = this.renderTemplate(promptTemplate, { email, context, playbook });
      const { actions, usage, model, provider, keySource } = await this.callClaude(prompt, orgId, userId, 'email_analysis');
      const saved           = await this.saveActions(actions, userId, orgId, email, context);

      // ── Token tracking at caller level (has org/user context) ──
      if (usage) {
        TokenTrackingService.log({
          orgId,
          userId,
          callType: 'email_analysis',
          model,
          provider,
          keySource,
          usage:    { input_tokens: usage.input_tokens, output_tokens: usage.output_tokens },
          emailId:  parseInt(emailId) || null,
          dealId:   email?.deal_id || null,
        }).catch(() => {});
      }

      // ── Agentic Framework: notify observer with enriched data (non-blocking) ──
      // Extract contacts_mentioned and urgency/sentiment from the AI response
      // The AI actions array may contain these signals; also try analyzeEmailSimple-style extraction
      const observerAnalysis = {
        actions,
        contacts_mentioned: this._extractContactsFromActions(actions, email),
        urgency:            this._inferUrgency(actions, email),
        sentiment:          this._inferSentiment(actions, email),
        suggested_reply:    this._extractSuggestedReply(actions, email),
        from_address:       email?.from_address || null,
      };

      AgentObserver.onEmailReceived(emailId, observerAnalysis, orgId, userId, email?.deal_id || null)
        .catch(err => console.error('AgentObserver email hook error:', err.message));

      return { success: true, actions: saved };

    } catch (error) {
      console.error('AI processing error:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * DEAL HEALTH CHECK
   * @param {number} dealId
   * @param {number} userId
   * @param {number} orgId
   */
  static async analyzeDeal(dealId, userId, orgId) {
    try {
      console.log(`🏥 Running health check on deal ${dealId}...`);

      const deal           = await this.getDeal(dealId);
      const context        = await this.gatherDealContext(dealId, userId);
      const promptTemplate = await this.getPromptTemplate(userId, orgId, 'deal_health_check');
      const playbook       = await this.getPlaybook(userId, orgId);
      const prompt         = this.renderTemplate(promptTemplate, { deal, context, playbook });
      const { actions, usage, model, provider, keySource } = await this.callClaude(prompt, orgId, userId, 'deal_health_check');
      const saved          = await this.saveActions(actions, userId, orgId, { id: `deal-${dealId}` }, context);

      // ── Token tracking at caller level (has org/user context) ──
      if (usage) {
        TokenTrackingService.log({
          orgId,
          userId,
          callType: 'deal_health_check',
          model,
          provider,
          keySource,
          usage:    { input_tokens: usage.input_tokens, output_tokens: usage.output_tokens },
          dealId:   parseInt(dealId) || null,
        }).catch(() => {});
      }

      return { success: true, health_check: true, actions: saved };

    } catch (error) {
      console.error('Deal analysis error:', error);
      return { success: false, error: error.message };
    }
  }

  // ── DB helpers ────────────────────────────────────────────────────────────

  static async fetchEmail(userId, emailId) {
    const result = await db.query(
      'SELECT * FROM emails WHERE id = $1 AND user_id = $2',
      [emailId, userId]
    );
    return result.rows[0];
  }

  static async getDeal(dealId) {
    const result = await db.query('SELECT * FROM deals WHERE id = $1', [dealId]);
    return result.rows[0];
  }

  static async gatherFullContext(email, userId) {
    const context = { emailThread: [], meetings: [], dealHistory: [], contact: null, deal: null, account: null };

    try {
      if (email.contact_id) {
        const r = await db.query('SELECT * FROM contacts WHERE id = $1', [email.contact_id]);
        context.contact = r.rows[0];
      }

      if (email.deal_id) {
        const dealR = await db.query('SELECT * FROM deals WHERE id = $1', [email.deal_id]);
        context.deal = dealR.rows[0];

        const [threadR, meetingsR, historyR] = await Promise.all([
          db.query('SELECT * FROM emails WHERE deal_id = $1 ORDER BY sent_at ASC',                          [email.deal_id]),
          db.query('SELECT * FROM meetings WHERE deal_id = $1 ORDER BY start_time DESC LIMIT 10',           [email.deal_id]),
          db.query('SELECT * FROM deal_activities WHERE deal_id = $1 ORDER BY created_at DESC LIMIT 20',    [email.deal_id]),
        ]);
        context.emailThread  = threadR.rows;
        context.meetings     = meetingsR.rows;
        context.dealHistory  = historyR.rows;
      }

      if (context.contact?.account_id) {
        const accR = await db.query('SELECT * FROM accounts WHERE id = $1', [context.contact.account_id]);
        context.account = accR.rows[0];
      }

    } catch (error) {
      console.error('Context gathering error:', error);
    }

    return context;
  }

  static async gatherDealContext(dealId, userId) {
    return this.gatherFullContext({ deal_id: dealId }, userId);
  }

  /**
   * Get user's playbook for this org, falling back to global default.
   */
  static async getPlaybook(userId, orgId) {
    try {
      const result = await db.query(
        'SELECT playbook_data FROM user_playbooks WHERE user_id = $1 AND org_id = $2',
        [userId, orgId]
      );
      return result.rows.length > 0 ? result.rows[0].playbook_data : SALES_PLAYBOOK;
    } catch (error) {
      return SALES_PLAYBOOK;
    }
  }

  /**
   * Get user's prompt template for this org, falling back to global default.
   */
  static async getPromptTemplate(userId, orgId, templateType) {
    try {
      const result = await db.query(
        'SELECT template_data FROM user_prompts WHERE user_id = $1 AND org_id = $2 AND template_type = $3',
        [userId, orgId, templateType]
      );
      return result.rows.length > 0 ? result.rows[0].template_data : AI_PROMPTS[templateType];
    } catch (error) {
      return AI_PROMPTS[templateType];
    }
  }

  // ── Template rendering (unchanged) ───────────────────────────────────────

  static renderTemplate(template, data) {
    let rendered = template;

    const replacements = {
      'DEAL_NAME_PLACEHOLDER':         data.context?.deal?.name || 'No active deal',
      'DEAL_STAGE_PLACEHOLDER':        data.context?.deal?.stage || 'unknown',
      'DEAL_VALUE_PLACEHOLDER':        data.context?.deal?.value || '0',
      'DEAL_CLOSE_DATE_PLACEHOLDER':   data.context?.deal?.expected_close_date || 'Not set',
      'DEAL_HEALTH_PLACEHOLDER':       data.context?.deal?.health || 'Unknown',
      'CONTACT_NAME_PLACEHOLDER':      `${data.context?.contact?.first_name || ''} ${data.context?.contact?.last_name || ''}`.trim() || 'Unknown contact',
      'CONTACT_TITLE_PLACEHOLDER':     data.context?.contact?.title || 'Unknown',
      'CONTACT_ROLE_PLACEHOLDER':      data.context?.contact?.role_type || 'Unknown',
      'ACCOUNT_NAME_PLACEHOLDER':      data.context?.account?.name || 'Unknown company',
      'ACCOUNT_INDUSTRY_PLACEHOLDER':  data.context?.account?.industry || 'Unknown',
      'EMAIL_THREAD_PLACEHOLDER':      this.formatEmailThread(data.context?.emailThread || []) || 'No previous emails',
      'MEETINGS_PLACEHOLDER':          this.formatMeetings(data.context?.meetings || []) || 'No previous meetings',
      'DEAL_HISTORY_PLACEHOLDER':      this.formatDealHistory(data.context?.dealHistory || []) || 'No deal history',
      'CURRENT_EMAIL_SUBJECT_PLACEHOLDER': data.email?.subject || 'No subject',
      'CURRENT_EMAIL_FROM_PLACEHOLDER':    data.email?.from_address || 'Unknown sender',
      'CURRENT_EMAIL_BODY_PLACEHOLDER':    data.email?.body || data.email?.body_preview || 'No content',
      'PLAYBOOK_GOAL_PLACEHOLDER':     data.playbook?.deal_stages?.[data.context?.deal?.stage]?.goal || 'Move deal forward',
      'PLAYBOOK_NEXT_STEP_PLACEHOLDER': data.playbook?.deal_stages?.[data.context?.deal?.stage]?.next_step || 'Follow up',
      'PLAYBOOK_TIMELINE_PLACEHOLDER': data.playbook?.deal_stages?.[data.context?.deal?.stage]?.timeline || 'ASAP',
      'DAYS_IN_STAGE_PLACEHOLDER':     data.context?.deal?.updated_at
        ? Math.floor((Date.now() - new Date(data.context.deal.updated_at)) / (1000 * 60 * 60 * 24))
        : 0,
    };

    Object.keys(replacements).forEach(key => {
      rendered = rendered.split(key).join(String(replacements[key]));
    });

    return rendered;
  }

  static formatEmailThread(thread) {
    return thread.map((e, i) =>
      `### Email ${i + 1} (${e.direction} on ${new Date(e.sent_at).toLocaleDateString()})\n` +
      `**Subject:** ${e.subject}\n**Body:** ${e.body_preview || e.body || 'No content'}\n`
    ).join('\n---\n');
  }

  static formatMeetings(meetings) {
    return meetings.map((m, i) =>
      `### Meeting ${i + 1}: ${m.title}\n` +
      `**When:** ${new Date(m.start_time).toLocaleDateString()}\n` +
      `**Notes:** ${m.notes || 'No notes'}\n`
    ).join('\n---\n');
  }

  static formatDealHistory(history) {
    return history.map(h => `- ${h.activity_type}: ${h.description}`).join('\n');
  }

  /**
   * Call the AI provider and return both parsed actions AND raw usage for
   * caller-level tracking. Provider/model resolved per org/user.
   * @returns {{ actions: Array, usage: object|null, model: string, provider: string, keySource: string }}
   */
  static async callClaude(prompt, orgId = null, userId = null, callType = 'action_generation') {
    const { adapter, model, provider, keySource } =
      await AIClientResolver.resolve(orgId, userId, callType);

    const { text: response, usage } = await adapter.complete({
      model,
      prompt,
      maxTokens: AI_PROMPTS.system_instructions.max_tokens,
    });

    let cleaned = response.trim()
      .replace(/```json\n?/gi, '')
      .replace(/```\n?/g, '');

    const jsonMatch = cleaned.match(/\[\s*\{[\s\S]*\}\s*\]/);
    if (jsonMatch) {
      cleaned = jsonMatch[0];
    } else {
      const arrayStart = cleaned.indexOf('[');
      const arrayEnd   = cleaned.lastIndexOf(']');
      if (arrayStart !== -1 && arrayEnd !== -1) {
        cleaned = cleaned.substring(arrayStart, arrayEnd + 1);
      }
    }

    cleaned = cleaned.trim();

    try {
      const parsed = JSON.parse(cleaned);
      return { actions: Array.isArray(parsed) ? parsed : [], usage, model, provider, keySource };
    } catch (error) {
      console.error('Failed to parse AI response:', error);
      console.error('Cleaned response:', cleaned);
      console.error('Original response:', response);
      return { actions: [], usage, model, provider, keySource };
    }
  }

  /**
   * Persist generated actions. org_id is now the second column.
   */
  static async saveActions(actions, userId, orgId, email, context) {
    const saved = [];

    for (const action of actions) {
      try {
        const result = await db.query(
          `INSERT INTO actions (
            org_id, user_id, type, title, description, action_type, priority,
            due_date, deal_id, contact_id, account_id,
            suggested_action, context, source, source_id, metadata, created_at
          ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, NOW())
          RETURNING *`,
          [
            orgId,
            userId,
            action.action_type || 'follow_up',
            action.title,
            action.description,
            action.action_type || 'follow_up',
            action.priority || 'medium',
            action.due_date || new Date(Date.now() + 24 * 60 * 60 * 1000),
            context.deal?.id    || null,
            context.contact?.id || null,
            context.account?.id || null,
            action.suggested_action || null,
            action.context          || null,
            'ai_generated',
            email.id,
            JSON.stringify({ confidence: action.confidence, email_trigger: action.email_trigger })
          ]
        );
        saved.push(result.rows[0]);
      } catch (error) {
        console.error('Error saving action:', error);
      }
    }

    return saved;
  }

  // ── Observer data extraction helpers (new) ───────────────────────────────
  // These extract structured data from the AI-generated actions and email
  // to enrich the AgentObserver.onEmailReceived call.

  /**
   * Extract potential new contacts from AI actions and email metadata.
   * Returns array of { name, email, title, role_type, confidence }.
   */
  static _extractContactsFromActions(actions, email) {
    const contacts = [];
    const seenEmails = new Set();

    // Look for contact references in AI-generated action metadata
    for (const action of (actions || [])) {
      // Check key_contacts if present (from enhanced prompts)
      if (action.key_contacts && Array.isArray(action.key_contacts)) {
        for (const kc of action.key_contacts) {
          if (typeof kc === 'string' && kc.includes('@') && !seenEmails.has(kc.toLowerCase())) {
            seenEmails.add(kc.toLowerCase());
            contacts.push({
              name:       kc.split('@')[0].replace(/[._-]/g, ' '),
              email:      kc,
              title:      null,
              role_type:  null,
              confidence: 0.50,
            });
          }
        }
      }

      // Check contacts_mentioned if present
      if (action.contacts_mentioned && Array.isArray(action.contacts_mentioned)) {
        for (const cm of action.contacts_mentioned) {
          if (cm.email && !seenEmails.has(cm.email.toLowerCase())) {
            seenEmails.add(cm.email.toLowerCase());
            contacts.push({
              name:       cm.name || cm.email.split('@')[0],
              email:      cm.email,
              title:      cm.title || null,
              role_type:  cm.role_type || null,
              confidence: cm.confidence || 0.55,
            });
          }
        }
      }
    }

    // Also check CC addresses on the email for potential new contacts
    if (email?.cc_addresses) {
      const ccList = typeof email.cc_addresses === 'string'
        ? email.cc_addresses.split(',').map(s => s.trim()).filter(Boolean)
        : (Array.isArray(email.cc_addresses) ? email.cc_addresses : []);
      for (const cc of ccList) {
        const addr = cc.includes('<') ? cc.match(/<([^>]+)>/)?.[1] : cc;
        if (addr && addr.includes('@') && !seenEmails.has(addr.toLowerCase())) {
          seenEmails.add(addr.toLowerCase());
          contacts.push({
            name:       cc.includes('<') ? cc.split('<')[0].trim() : addr.split('@')[0],
            email:      addr,
            title:      null,
            role_type:  null,
            confidence: 0.40,
          });
        }
      }
    }

    return contacts;
  }

  /**
   * Infer urgency from AI actions and email content.
   */
  static _inferUrgency(actions, email) {
    // Check if any action has high priority
    const hasHighPriority = (actions || []).some(a =>
      a.priority === 'high' || a.urgency === 'high'
    );
    if (hasHighPriority) return 'high';

    // Check email subject for urgency signals
    const subject = (email?.subject || '').toLowerCase();
    if (/urgent|asap|immediate|critical|deadline|time.?sensitive/i.test(subject)) {
      return 'high';
    }

    // Check if multiple actions suggest follow-up urgency
    const followUpActions = (actions || []).filter(a =>
      (a.action_type || '').includes('follow') || a.requires_response
    );
    if (followUpActions.length >= 2) return 'high';

    return 'medium';
  }

  /**
   * Infer sentiment from AI actions and email content.
   */
  static _inferSentiment(actions, email) {
    // Look for sentiment in action metadata
    for (const action of (actions || [])) {
      if (action.sentiment) return action.sentiment;
    }

    // Keyword-based fallback on email body
    const body = ((email?.body || '') + ' ' + (email?.subject || '')).toLowerCase();
    if (/disappointed|frustrated|concerned|issue|problem|cancel|unhappy/i.test(body)) return 'negative';
    if (/excited|great|thank|appreciate|looking forward|pleased/i.test(body)) return 'positive';
    return 'neutral';
  }

  /**
   * Extract suggested reply from AI actions if present.
   */
  static _extractSuggestedReply(actions, email) {
    for (const action of (actions || [])) {
      if (action.suggested_reply) return action.suggested_reply;
      if (action.action_type === 'follow_up' && action.suggested_action) {
        return { subject: `Re: ${email?.subject || 'Follow-up'}`, body: action.suggested_action };
      }
    }
    return null;
  }
}

module.exports = AIProcessor;
