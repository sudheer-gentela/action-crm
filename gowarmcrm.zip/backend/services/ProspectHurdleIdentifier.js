/**
 * ProspectHurdleIdentifier.js
 *
 * Identifies hurdles blocking prospect progression.
 * Hurdle types ordered by priority.
 *
 * PHASE 4 ADDITION:
 *   - Added `identifyAll()` — returns ALL matching hurdles (not just top one).
 *     Used by ProspectDiagnosticsEngine to write all active diagnostic alerts.
 *   - `identify()` unchanged — still returns only the top hurdle. STRAP
 *     continues to call this (one active hurdle per STRAP).
 *
 * Returns from identify():  { hurdleType, title, priority, evidence } | null
 * Returns from identifyAll(): Array<{ hurdleType, title, priority, evidence }>
 */

class ProspectHurdleIdentifier {

  /**
   * Returns the single highest-priority hurdle (STRAP path — unchanged).
   * @param {object} context - from ProspectContextBuilder
   * @returns {{ hurdleType, title, priority, evidence } | null}
   */
  static identify(context, config = {}) {
    const all = this.identifyAll(context, config);
    return all.length > 0 ? all[0] : null;
  }

  /**
   * Returns ALL matching hurdles ordered by priority.
   * Used by ProspectDiagnosticsEngine to write multiple diagnostic alerts.
   * @param {object} context - from ProspectContextBuilder
   * @returns {Array<{ hurdleType, title, priority, evidence }>}
   */
  static identifyAll(context, config = {}) {
    const { prospect, derived, icpBreakdown } = context;

    const checks = [
      this._checkGhosting(prospect, derived),
      this._checkConversionReady(prospect, derived),
      this._checkStaleOutreach(prospect, derived),
      this._checkNoMeeting(prospect, derived),
      this._checkNoResearch(prospect, derived),
      this._checkWrongChannel(prospect, derived, config),
      this._checkMultiThreadNeeded(prospect, derived),
      this._checkLowIcp(prospect, icpBreakdown, config),
    ];

    return checks.filter(Boolean);
  }

  // ── ghosting: 3+ outreach attempts with zero response ─────────────────────

  static _checkGhosting(prospect, derived) {
    if (derived.isGhosting) {
      return {
        hurdleType: 'ghosting',
        title: 'Prospect ghosting',
        priority: 'critical',
        evidence: `${prospect.outreach_count} outreach attempts with zero responses over ${derived.daysSinceLastOutreach || '?'} days.`,
      };
    }
    return null;
  }

  // ── conversion_ready: high engagement but still pre-deal ──────────────────

  static _checkConversionReady(prospect, derived) {
    if (derived.isHotLead && !['converted', 'qualified'].includes(prospect.stage)) {
      return {
        hurdleType: 'conversion_ready',
        title: 'Ready for conversion',
        priority: 'critical',
        evidence: `High engagement signals (${(derived.responseRate * 100).toFixed(0)}% response rate, responded ${derived.daysSinceLastResponse}d ago) but still in "${prospect.stage}" stage.`,
      };
    }
    return null;
  }

  // ── stale_outreach: no outreach in 14+ days ───────────────────────────────

  static _checkStaleOutreach(prospect, derived) {
    if (derived.isStale && !derived.isGhosting) {
      return {
        hurdleType: 'stale_outreach',
        title: 'Outreach gone stale',
        priority: 'high',
        evidence: `No outreach in ${derived.daysSinceLastOutreach} days. Prospect may lose awareness.`,
      };
    }
    return null;
  }

  // ── no_meeting: engaged prospect with no meeting scheduled ────────────────

  static _checkNoMeeting(prospect, derived) {
    if (derived.hasReplied && prospect.response_count >= 1) {
      if (['engaged', 'qualified'].includes(prospect.stage)) {
        return {
          hurdleType: 'no_meeting',
          title: 'Engaged but no meeting',
          priority: 'high',
          evidence: `Prospect has responded ${prospect.response_count} time(s) and is in "${prospect.stage}" stage, but no meeting is scheduled.`,
        };
      }
    }
    return null;
  }

  // ── no_research: prospect in targeting/research stage with no notes ────────

  static _checkNoResearch(prospect, derived) {
    if (['targeting', 'research'].includes(prospect.stage) && !prospect.research_notes) {
      return {
        hurdleType: 'no_research',
        title: 'No research completed',
        priority: 'medium',
        evidence: `Prospect is in "${prospect.stage}" stage but has no research notes. Research is needed before outreach.`,
      };
    }
    return null;
  }

  // ── wrong_channel: low response rate on current channel ───────────────────

  static _checkWrongChannel(prospect, derived, config = {}) {
    const minAttempts  = config.wrong_channel_min_attempts     ?? 3;
    const maxRespRate  = config.wrong_channel_max_response_rate ?? 0.10;
    if (prospect.outreach_count >= minAttempts && derived.responseRate < maxRespRate && prospect.preferred_channel) {
      return {
        hurdleType: 'wrong_channel',
        title: 'Channel not working',
        priority: 'medium',
        evidence: `${prospect.outreach_count} attempts via ${prospect.preferred_channel || 'current channel'} with ${(derived.responseRate * 100).toFixed(0)}% response rate. Consider switching channels.`,
      };
    }
    return null;
  }

  // ── multi_thread_needed: only one prospect at company ─────────────────────

  static _checkMultiThreadNeeded(prospect, derived) {
    if (derived.otherProspectsAtCompany.length === 0 && prospect.outreach_count >= 2) {
      return {
        hurdleType: 'multi_thread_needed',
        title: 'Single entry point',
        priority: 'medium',
        evidence: `Only one prospect at ${prospect.company_name || 'this company'}. Adding more entry points increases conversion probability.`,
      };
    }
    return null;
  }

  // ── low_icp: ICP score below threshold ────────────────────────────────────

  static _checkLowIcp(prospect, icpBreakdown, config = {}) {
    const lowIcpThreshold = config.low_icp_threshold ?? 30;
    if (prospect.icp_score !== null && prospect.icp_score !== undefined && prospect.icp_score < lowIcpThreshold) {
      return {
        hurdleType: 'low_icp',
        title: 'Low ICP fit',
        priority: 'low',
        evidence: `ICP score is ${prospect.icp_score}/100. Consider disqualifying or deprioritizing this prospect.`,
      };
    }
    return null;
  }
}

module.exports = ProspectHurdleIdentifier;
