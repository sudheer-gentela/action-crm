import React, { useState, useEffect } from 'react';
import { hashIdSegment, writeHash } from './hashNav';
import './App.css';
import AccountsView from './AccountsView';
import DealsView from './DealsView';
import ContactsView from './ContactsView';
import EmailView from './EmailView';
import ActionsView from './ActionsView';
import CalendarView from './CalendarView';
import FilesView from './FilesView';
import SettingsView from './SettingsView';
import SuperAdminView from './SuperAdminView';
import ImpersonationBanner from './ImpersonationBanner';
import OrgAdminView from './OrgAdminView';
import ActionContextPanel from './ActionContextPanel';
import AgentInboxView from './AgentInboxView';
import PlaybooksView from './PlaybooksView';
import PlaybookDetail from './PlaybookDetail';
import PlaybookRegister from './PlaybookRegister';
import PlaybookApprovals from './PlaybookApprovals';
import ProspectingView from './ProspectingView';
import ContractsView from './ContractsView';
import HandoverView from './HandoverView';
import SupportView from './SupportView';
import AgencyView from './AgencyView';
import TeamReportingView from './TeamReportingView';
import Sidebar from './Sidebar';

// ─────────────────────────────────────────────────────────────
// Normalise the modules object from /org/context into a simple { key: boolean } map.
// Handles both legacy scalar format (true/false) and new object format ({ allowed, enabled }).
function normaliseModules(raw) {
  if (!raw || typeof raw !== 'object') return {};
  const result = {};
  for (const [key, val] of Object.entries(raw)) {
    if (val === null || val === undefined) {
      result[key] = false;
    } else if (typeof val === 'object') {
      result[key] = !!val.enabled;
    } else {
      result[key] = val === true || val === 'true';
    }
  }
  return result;
}

// ─────────────────────────────────────────────────────────────
// ROLE DEFINITIONS
// ─────────────────────────────────────────────────────────────

// Sub-navigation for the Prospecting module. Rendered by Sidebar.js as an
// inline tree under the pinned Prospecting item. Each child maps to one or
// more ProspectingView hash modes (#/prospecting/<mode>):
//   • modes[0] is the navigation target on click
//   • the FULL modes list drives active-state highlighting, so views without
//     their own menu item (list, account, research) light up their parent
//   • rememberKey (optional) restores the user's last display within the
//     child's modes — Prospect List remembers Board vs Table vs By-account
// The parent item's childBareMode is the mode written as a BARE hash
// (#/prospecting, no second segment) to match ProspectingView's convention
// that pipeline is the default and is represented by no segment.
const PROSPECTING_CHILDREN = [
  { id: 'plist',     label: 'Prospect List',     icon: '▦',  modes: ['pipeline', 'list', 'account'], rememberKey: 'gw:prospecting:plistDisplay' },
  { id: 'campaigns', label: 'Campaigns',         icon: '🚀', modes: ['campaigns', 'research'] },
  { id: 'sequences', label: 'Sequences',         icon: '📨', modes: ['sequences'] },
  { id: 'inbox',     label: 'Prospecting Inbox', icon: '📥', modes: ['inbox'] },
  { id: 'calls',     label: 'Calls',             icon: '📞', modes: ['calls'] },
  { id: 'work',      label: 'Work Queue',        icon: '⚡', modes: ['work'] },
  { id: 'network',   label: 'Network',           icon: '🕸️', modes: ['network'] },
];

// Modules not in the sidebar nav — accessible only via the launcher
const ALL_MODULE_ITEMS = [
  {
    id: 'prospecting', label: 'Prospecting', icon: '🎯',
    children:      PROSPECTING_CHILDREN,
    childBareMode: 'pipeline',
    rememberKey:   'gw:prospecting:lastMode',
  },
  { id: 'contracts',   label: 'Contracts',   icon: '📄' },
  { id: 'handovers',   label: 'Handovers',   icon: '🤝' },
  { id: 'service',     label: 'Service',     icon: '🎧' },
  { id: 'agency',      label: 'Agency',      icon: '🏢' },
];

const NAV_ITEMS_BY_ROLE = {
  member: [
    { id: 'actions',      label: 'Actions',      icon: '⚡' },
    { id: 'deals',        label: 'Deals',        icon: '💼' },
    { id: 'accounts',     label: 'Accounts',     icon: '🏢' },
    { id: 'contacts',     label: 'Contacts',     icon: '👥' },
    { id: 'email',        label: 'Email',        icon: '✉️' },
    { id: 'calendar',     label: 'Calendar',     icon: '📅' },
    { id: 'files',        label: 'Files',        icon: '📁' },
    { id: 'agent',        label: 'Agents',       icon: '🤖' },
    { id: 'playbooks',    label: 'Playbooks',    icon: '📋' },
    { id: 'reporting',    label: 'Reporting',    icon: '📊' },
    { id: 'settings',     label: 'Settings',     icon: '⚙️' },
  ],
  'org-admin': [
    { id: 'org-admin', label: 'Org Admin', icon: '🔑' },
  ],
  'super-admin': [
    { id: 'super-admin', label: 'Platform Admin', icon: '⚡' },
  ],
};

const DEFAULT_TAB_BY_ROLE = {
  member:       'actions',
  'org-admin':  'org-admin',
  'super-admin':'super-admin',
};

// ─────────────────────────────────────────────────────────────
// TAB ↔ URL HASH SYNC
//
// Navigation is plain component state (no router), so before this a
// browser refresh reset currentTab to the role default and dumped the
// user on Actions. We mirror the active tab into the URL hash
// (app.gowarmcrm.com/#/prospecting) and restore it on load:
//   • refresh keeps you on the screen you were on
//   • module URLs are bookmarkable / shareable
//   • zero hosting config — the hash never reaches the server, so no
//     SPA rewrite rules are needed on Vercel
//
// Only tabs the active role can actually reach are restorable; a hash
// pointing at a tab outside the role's nav (or an internal pseudo-tab
// like 'playbook-detail', which depends on in-memory ids) falls back
// to the role default.
// ─────────────────────────────────────────────────────────────

function tabFromHash() {
  const m = (window.location.hash || '').match(/^#\/?([a-z0-9-]+)/i);
  return m ? m[1].toLowerCase() : null;
}

// Tabs restorable for a role: its sidebar nav + (for members) every
// launcher module. Org-module enablement is NOT checked here — it loads
// async, and each module view already renders its own "module is
// disabled" panel when the flag is off.
function persistableTabsForRole(role) {
  const nav = (NAV_ITEMS_BY_ROLE[role] || NAV_ITEMS_BY_ROLE.member).map(i => i.id);
  const modules = role === 'member' ? ALL_MODULE_ITEMS.map(m => m.id) : [];
  return new Set([...nav, ...modules]);
}

// ─────────────────────────────────────────────────────────────
// useAuth
// ─────────────────────────────────────────────────────────────
const useAuth = () => {
  const [user, setUser]       = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token    = localStorage.getItem('token');
    const userData = localStorage.getItem('user');
    if (token && userData) {
      try {
        setUser(JSON.parse(userData));
      } catch (e) {
        // Corrupted 'user' blob would otherwise white-screen the app at boot.
        // Clear the session and fall through to the login screen.
        console.error('Corrupted user data in localStorage — clearing session:', e);
        localStorage.removeItem('token');
        localStorage.removeItem('user');
      }
    }
    setLoading(false);
  }, []);

  const login = async (email, password) => {
    try {
      const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001/api';
      const response = await fetch(`${API_URL}/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, timezone: Intl.DateTimeFormat().resolvedOptions().timeZone }),
      });

      if (!response.ok) {
        let errorData;
        const contentType = response.headers.get('content-type');
        if (contentType && contentType.includes('application/json')) {
          errorData = await response.json();
        } else {
          const text = await response.text();
          errorData = { error: { message: text || 'Login failed' } };
        }
        if (response.status === 429) {
          throw new Error(errorData.error?.message || 'Too many login attempts. Please try again later.');
        }
        throw new Error(errorData.error?.message || 'Login failed');
      }

      const data = await response.json();
      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));
      setUser(data.user);
      console.log('✅ Logged in | super_admin:', data.user.is_super_admin, '| org_role:', data.user.org_role);
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    }
  };

  const register = async (email, password, firstName, lastName) => {
    try {
      const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001/api';
      const response = await fetch(`${API_URL}/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password, firstName, lastName, timezone: Intl.DateTimeFormat().resolvedOptions().timeZone }),
      });

      if (!response.ok) {
        let errorData;
        const contentType = response.headers.get('content-type');
        if (contentType && contentType.includes('application/json')) {
          errorData = await response.json();
        } else {
          const text = await response.text();
          errorData = { error: { message: text || 'Registration failed' } };
        }
        if (response.status === 429) {
          throw new Error(errorData.error?.message || 'Too many registration attempts. Please try again later.');
        }
        throw new Error(errorData.error?.message || 'Registration failed');
      }

      const data = await response.json();
      localStorage.setItem('token', data.token);
      localStorage.setItem('user', JSON.stringify(data.user));
      setUser(data.user);
      console.log('✅ Registered successfully');
    } catch (error) {
      console.error('Register error:', error);
      throw error;
    }
  };

  const logout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    // Clear any stashed super-admin session from an impersonation flow so it
    // never leaks into the next login.
    localStorage.removeItem('sa_token');
    localStorage.removeItem('sa_user');
    sessionStorage.removeItem('activeRole');
    setUser(null);
  };

  return { user, login, register, logout, loading };
};

// ─────────────────────────────────────────────────────────────
// PasswordInput — a password field with a show/hide eye toggle.
// Clicking the eye flips the input between type="password" (masked)
// and type="text" (visible), so the user can verify what they typed.
// Keeps its own visibility state so multiple password fields on one
// screen (e.g. new + confirm on the reset form) toggle independently.
// ─────────────────────────────────────────────────────────────
const EyeIcon = (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"
       strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
    <circle cx="12" cy="12" r="3" />
  </svg>
);
const EyeOffIcon = (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor"
       strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" />
    <line x1="1" y1="1" x2="23" y2="23" />
  </svg>
);

function PasswordInput({
  name, value, onChange, placeholder,
  disabled = false, required = true, minLength, autoFocus = false,
}) {
  const [visible, setVisible] = useState(false);
  return (
    <div style={{ position: 'relative' }}>
      <input
        type={visible ? 'text' : 'password'}
        name={name}
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        required={required}
        disabled={disabled}
        minLength={minLength}
        autoFocus={autoFocus}
        style={{ paddingRight: 46, boxSizing: 'border-box' }}
      />
      <button
        type="button"
        onClick={() => setVisible(v => !v)}
        disabled={disabled}
        tabIndex={-1}
        aria-label={visible ? 'Hide password' : 'Show password'}
        title={visible ? 'Hide password' : 'Show password'}
        style={{
          position: 'absolute',
          top: 0,
          right: 0,
          height: '100%',
          width: 44,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          background: 'transparent',
          border: 'none',
          padding: 0,
          color: visible ? '#1A3A5C' : '#718096',
          cursor: disabled ? 'not-allowed' : 'pointer',
        }}
      >
        {visible ? EyeOffIcon : EyeIcon}
      </button>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// AuthScreen  (login · register · forgot-password · reset-password)
// ─────────────────────────────────────────────────────────────
const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:3001/api';

function AuthScreen({ onLogin, onRegister, initialMode }) {
  // mode: 'login' | 'register' | 'forgot' | 'reset' | 'reset_done'
  const [mode,     setMode]     = useState(initialMode || 'login');
  const [formData, setFormData] = useState({ email: '', password: '', confirmPassword: '', firstName: '', lastName: '' });
  const [error,    setError]    = useState('');
  const [info,     setInfo]     = useState('');
  const [loading,  setLoading]  = useState(false);

  // Read reset token from URL on mount
  const [resetToken, setResetToken] = useState('');
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const t = params.get('token');
    if (t) {
      setResetToken(t);
      setMode('reset');
    }
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const go = (newMode) => {
    setMode(newMode);
    setError('');
    setInfo('');
    setFormData({ email: '', password: '', confirmPassword: '', firstName: '', lastName: '' });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setInfo('');
    setLoading(true);
    try {
      if (mode === 'register') {
        if (!formData.firstName.trim()) throw new Error('First name is required');
        if (!formData.lastName.trim())  throw new Error('Last name is required');
        if (formData.password.length < 8) throw new Error('Password must be at least 8 characters');
        await onRegister(formData.email, formData.password, formData.firstName, formData.lastName);

      } else if (mode === 'login') {
        await onLogin(formData.email, formData.password);

      } else if (mode === 'forgot') {
        const res  = await fetch(`${API_URL}/auth/forgot-password`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ email: formData.email }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error?.message || 'Request failed');
        setInfo(data.message);

      } else if (mode === 'reset') {
        if (formData.password.length < 8) throw new Error('Password must be at least 8 characters');
        if (formData.password !== formData.confirmPassword) throw new Error('Passwords do not match');
        const res  = await fetch(`${API_URL}/auth/reset-password`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ token: resetToken, password: formData.password }),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error?.message || 'Reset failed');
        // Clear token from URL and go to success state
        window.history.replaceState({}, '', window.location.pathname);
        setMode('reset_done');
      }
    } catch (err) {
      setError(err.message || 'An error occurred');
    } finally {
      setLoading(false);
    }
  };

  const logo = (
    <div className="login-logo">
      <svg width="56" height="56" viewBox="0 0 72 72" xmlns="http://www.w3.org/2000/svg">
        <rect width="72" height="72" rx="16" fill="#E8630A"/>
        <path d="M36 10 C28 20 16 28 18 44 C20 56 28 65 36 70 C44 65 52 56 54 44 C56 28 44 20 36 10Z" fill="#F5A623"/>
        <path d="M36 26 C32 32 28 38 30 46 C32 52 34 57 36 60 C38 57 40 52 42 46 C44 38 40 32 36 26Z" fill="#FDE68A"/>
        <path d="M24 46 L28 58 L33 49 L36 56 L39 49 L44 58 L48 46" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" fill="none" opacity="0.95"/>
      </svg>
    </div>
  );

  // ── Reset done ────────────────────────────────────────────────────────────
  if (mode === 'reset_done') {
    return (
      <div className="login-container">
        <div className="login-box">
          {logo}
          <h1 className="login-brand">Go<span className="brand-warm">Warm</span> <span className="brand-crm">CRM</span></h1>
          <p className="login-subtitle">Password Updated</p>
          <div className="success-message" style={{ marginTop: 16 }}>
            ✅ Your password has been reset successfully.
          </div>
          <div className="auth-toggle" style={{ marginTop: 20 }}>
            <button type="button" className="btn-toggle" onClick={() => go('login')}>
              Sign In with your new password →
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ── Forgot password ───────────────────────────────────────────────────────
  if (mode === 'forgot') {
    return (
      <div className="login-container">
        <div className="login-box">
          {logo}
          <h1 className="login-brand">Go<span className="brand-warm">Warm</span> <span className="brand-crm">CRM</span></h1>
          <p className="login-subtitle">Reset your password</p>

          {info ? (
            <>
              <div className="success-message" style={{ marginTop: 16, textAlign: 'left' }}>
                📧 {info}
              </div>
              <div className="auth-toggle" style={{ marginTop: 20 }}>
                <button type="button" className="btn-toggle" onClick={() => go('login')}>
                  ← Back to Sign In
                </button>
              </div>
            </>
          ) : (
            <form onSubmit={handleSubmit} className="login-form" style={{ marginTop: 24 }}>
              <div className="form-group">
                <label>Email address</label>
                <input
                  type="email" name="email" value={formData.email} onChange={handleChange}
                  placeholder="you@company.com" required disabled={loading}
                  autoFocus
                />
              </div>
              {error && <div className="error-message">{error}</div>}
              <button type="submit" className="btn-primary" disabled={loading}>
                {loading ? <><span className="spinner"></span>Sending...</> : 'Send Reset Link'}
              </button>
              <div className="auth-toggle">
                <button type="button" className="btn-toggle" onClick={() => go('login')} disabled={loading}>
                  ← Back to Sign In
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    );
  }

  // ── Reset password (from email link) ─────────────────────────────────────
  if (mode === 'reset') {
    return (
      <div className="login-container">
        <div className="login-box">
          {logo}
          <h1 className="login-brand">Go<span className="brand-warm">Warm</span> <span className="brand-crm">CRM</span></h1>
          <p className="login-subtitle">Choose a new password</p>

          <form onSubmit={handleSubmit} className="login-form" style={{ marginTop: 24 }}>
            <div className="form-group">
              <label>New Password</label>
              <PasswordInput
                name="password" value={formData.password} onChange={handleChange}
                placeholder="At least 8 characters" disabled={loading} minLength={8}
                autoFocus
              />
              <small className="form-hint">Minimum 8 characters</small>
            </div>
            <div className="form-group">
              <label>Confirm New Password</label>
              <PasswordInput
                name="confirmPassword" value={formData.confirmPassword} onChange={handleChange}
                placeholder="Repeat your new password" disabled={loading}
              />
            </div>
            {error && <div className="error-message">{error}</div>}
            <button type="submit" className="btn-primary" disabled={loading}>
              {loading ? <><span className="spinner"></span>Resetting...</> : 'Set New Password'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  // ── Login / Register ──────────────────────────────────────────────────────
  return (
    <div className="login-container">
      <div className="login-box">
        {logo}
        <h1 className="login-brand">Go<span className="brand-warm">Warm</span> <span className="brand-crm">CRM</span></h1>
        <p className="login-subtitle">
          {mode === 'register' ? 'Create Your Account' : 'The Execution Application for your GTM Team'}
        </p>

        <form onSubmit={handleSubmit} className="login-form">
          {mode === 'register' && (
            <div className="form-row">
              <div className="form-group">
                <label>First Name</label>
                <input type="text" name="firstName" value={formData.firstName} onChange={handleChange} placeholder="John" required disabled={loading} />
              </div>
              <div className="form-group">
                <label>Last Name</label>
                <input type="text" name="lastName" value={formData.lastName} onChange={handleChange} placeholder="Doe" required disabled={loading} />
              </div>
            </div>
          )}

          <div className="form-group">
            <label>Email</label>
            <input type="email" name="email" value={formData.email} onChange={handleChange} placeholder="you@company.com" required disabled={loading} />
          </div>

          <div className="form-group">
            <label>Password</label>
            <PasswordInput
              name="password" value={formData.password} onChange={handleChange}
              placeholder={mode === 'register' ? 'At least 8 characters' : '••••••••'}
              disabled={loading} minLength={mode === 'register' ? 8 : undefined}
            />
            {mode === 'register' && <small className="form-hint">Minimum 8 characters</small>}
          </div>

          {error && <div className="error-message">{error}</div>}

          <button type="submit" className="btn-primary" disabled={loading}>
            {loading ? (
              <><span className="spinner"></span>{mode === 'register' ? 'Creating Account...' : 'Signing In...'}</>
            ) : (
              mode === 'register' ? 'Create Account' : 'Sign In'
            )}
          </button>
        </form>

        {mode === 'login' && (
          <div style={{ textAlign: 'right', marginTop: 8 }}>
            <button
              type="button"
              onClick={() => go('forgot')}
              style={{ background: 'none', border: 'none', color: '#E8630A', fontSize: 13,
                       fontWeight: 600, cursor: 'pointer', padding: 0 }}
            >
              Forgot password?
            </button>
          </div>
        )}

        <div className="auth-toggle">
          <button type="button" className="btn-toggle" onClick={() => go(mode === 'register' ? 'login' : 'register')} disabled={loading}>
            {mode === 'register' ? 'Already have an account? Sign In' : 'Need an account? Create One'}
          </button>
        </div>

        {mode === 'login' && (
          <div className="demo-info">
            <p><strong>New to GoWarm CRM?</strong></p>
            <p>Click "Create One" above to get started!</p>
          </div>
        )}
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// Dashboard
// ─────────────────────────────────────────────────────────────
function Dashboard({ user, onLogout }) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [activeContextAction, setActiveContextAction] = useState(null);
  const [pendingDealId, setPendingDealId]               = useState(null);
  const [pendingEmailDealId, setPendingEmailDealId]     = useState(null);
  const [pendingContactId, setPendingContactId]         = useState(null);
  const [pendingMeetingId, setPendingMeetingId]         = useState(null);
  const [pendingAccountId, setPendingAccountId]         = useState(null);
  const [pendingPlaybookFilter, setPendingPlaybookFilter] = useState(null);
  const [pendingPlaybookId, setPendingPlaybookId]         = useState(() =>
    tabFromHash() === 'playbooks' ? hashIdSegment(1) : null
  );
  const [pendingContractId, setPendingContractId]       = useState(null);
  const [pendingHandoverId, setPendingHandoverId]       = useState(null);
  const [pendingActionId, setPendingActionId]           = useState(null); // Phase 4: deep-link from calendar
  const [sidebarOpen, setSidebarOpen]           = useState(false);
  const [isMobile, setIsMobile]                 = useState(window.innerWidth < 768);
  const [orgModules, setOrgModules]             = useState({});  // { contracts: true/false, ... }
  const [pinnedModules, setPinnedModules]       = useState([]);  // array of module IDs pinned to sidebar

  // Fetch org module flags once on mount — accessible to ALL roles via /org/context
  useEffect(() => {
    const token = localStorage.getItem('token');
    const API   = process.env.REACT_APP_API_URL || '';
    fetch(`${API}/org/context`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (data?.modules) setOrgModules(normaliseModules(data.modules));
      })
      .catch(() => {}); // non-fatal — modules stay hidden if fetch fails
  }, []);

  // Fetch user preferences (pinned_modules) once on mount
  useEffect(() => {
    const token = localStorage.getItem('token');
    const API   = process.env.REACT_APP_API_URL || '';
    fetch(`${API}/users/me/preferences`, {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        const pinned = data?.preferences?.pinned_modules;
        if (Array.isArray(pinned)) setPinnedModules(pinned);
      })
      .catch(() => {}); // non-fatal — stays empty
  }, []);

  // ── Phase 4: deep-link from CampaignsView ──────────────────────────────
  // When a user clicks "Team Activity →" on a campaign, CampaignsView fires
  // a window event with the campaign id. We catch it here and switch tabs +
  // pass the id to TeamReportingView, which consumes it and pops the
  // drill-down open. (The reporting view fetches its own scope internally,
  // so App.js no longer needs to do that pre-fetch — the Reporting nav item
  // is always visible; solo users see their own activity inside the view.)
  const [pendingReportingCampaignId, setPendingReportingCampaignId] = useState(null);
  useEffect(() => {
    const handler = (e) => {
      const id = e.detail?.campaignId;
      if (!id) return;
      setPendingReportingCampaignId(id);
      setCurrentTab('reporting');
    };
    window.addEventListener('reportingDrilldown', handler);
    return () => window.removeEventListener('reportingDrilldown', handler);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Cap on how many modules a user can pin to the sidebar (mirror of backend)
  const PINNED_MODULES_CAP = 4;

  // Toggle pin state for a module. Optimistic UI — rolls back on API error.
  const handleTogglePin = async (moduleId) => {
    const isPinned = pinnedModules.includes(moduleId);
    let next;
    if (isPinned) {
      next = pinnedModules.filter(id => id !== moduleId);
    } else {
      if (pinnedModules.length >= PINNED_MODULES_CAP) {
        // At cap — do nothing. Sidebar UI disables the pin icon in this state
        // but this is the server-of-truth guard in case the UI allows it through.
        return;
      }
      next = [...pinnedModules, moduleId];
    }

    // Optimistic update
    const prev = pinnedModules;
    setPinnedModules(next);

    try {
      const token = localStorage.getItem('token');
      const API   = process.env.REACT_APP_API_URL || '';
      const res = await fetch(`${API}/users/me/preferences`, {
        method: 'PATCH',
        headers: {
          'Content-Type':  'application/json',
          Authorization:   `Bearer ${token}`,
        },
        body: JSON.stringify({ pinned_modules: next }),
      });
      if (!res.ok) throw new Error('save failed');
      const data = await res.json();
      if (Array.isArray(data?.preferences?.pinned_modules)) {
        setPinnedModules(data.preferences.pinned_modules);
      }
    } catch (_) {
      // Roll back optimistic update
      setPinnedModules(prev);
    }
  };

  const isSuperAdmin = user?.is_super_admin === true;
  const orgRole      = user?.org_role || user?.role || 'member';
  const isOrgAdmin   = orgRole === 'owner' || orgRole === 'admin';

  const availableRoles = [
    'member',
    ...(isOrgAdmin   ? ['org-admin']   : []),
    ...(isSuperAdmin ? ['super-admin'] : []),
  ];

  const [activeRole, setActiveRole] = useState(() => {
    const saved = sessionStorage.getItem('activeRole');
    return (saved && availableRoles.includes(saved)) ? saved : 'member';
  });

  // Restore the tab from the URL hash on load (survives refresh). Falls
  // back to the role default when the hash is absent or points at a tab
  // this role can't reach.
  const [currentTab, setCurrentTab] = useState(() => {
    const fromHash = tabFromHash();
    // #/playbooks/<id> restores the playbook-detail pseudo-tab (the id
    // itself is restored by pendingPlaybookId's initializer).
    if (fromHash === 'playbooks' && hashIdSegment(1) && activeRole === 'member') {
      return 'playbook-detail';
    }
    if (fromHash && persistableTabsForRole(activeRole).has(fromHash)) return fromHash;
    return DEFAULT_TAB_BY_ROLE[activeRole];
  });

  // Keep the hash's FIRST segment in lockstep with the active tab.
  // Deeper segments (#/prospecting/campaigns/14) are owned by the views
  // themselves (ProspectingView → sub-view, CampaignsView → drawer id),
  // so we only rewrite when the tab segment actually differs — a rewrite
  // resets the deeper segments, which is correct on a tab switch and
  // wrong any other time. replaceState (not location.hash =) so tab
  // switches don't pile up history entries — the browser Back button
  // keeps its normal "leave the app" meaning.
  // Internal pseudo-tabs (e.g. 'playbook-detail') aren't persistable —
  // they depend on in-memory ids — so for those we leave the hash on
  // the last persistable tab, which is also the sane refresh target.
  useEffect(() => {
    // playbook-detail is a pseudo-tab but IS persistable as #/playbooks/<id>.
    if (currentTab === 'playbook-detail') {
      if (pendingPlaybookId) writeHash(['playbooks', pendingPlaybookId]);
      return;
    }
    if (!persistableTabsForRole(activeRole).has(currentTab)) return;
    if (tabFromHash() === currentTab) {
      // Segment already right — keep sub-segments (owned by the views),
      // EXCEPT the playbooks id: no view owns it (it belongs to the
      // playbook-detail pseudo-tab), so returning to the playbooks list
      // must trim it or a refresh would bounce back into the detail.
      if (currentTab === 'playbooks' && hashIdSegment(1)) writeHash(['playbooks']);
      return;
    }
    window.history.replaceState(null, '', `#/${currentTab}`);
  }, [currentTab, pendingPlaybookId, activeRole]);

  // Manual hash edits (or programmatic ones) navigate too.
  useEffect(() => {
    const onHashChange = () => {
      const t = tabFromHash();
      if (t && persistableTabsForRole(activeRole).has(t)) {
        setCurrentTab(prev => (prev === t ? prev : t));
      }
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, [activeRole]);

  const handleRoleSwitch = (role) => {
    if (role === activeRole) return;
    sessionStorage.setItem('activeRole', role);
    setActiveRole(role);
    setCurrentTab(DEFAULT_TAB_BY_ROLE[role]);
    // Notify any mounted components that read activeRole from sessionStorage
    window.dispatchEvent(new CustomEvent('roleSwitch', { detail: { role } }));
    if (isMobile) setSidebarOpen(false);
  };

  // Member nav. Phase 4 originally gated "Reporting" behind a scope check
  // (only managers + admins saw it). After early user feedback, we now show
  // Reporting to everyone — solo reps see their own activity, the view
  // adapts. Scope is still fetched (used in the view's header) but no
  // longer gates the nav item.
  const navItems = NAV_ITEMS_BY_ROLE[activeRole] || NAV_ITEMS_BY_ROLE.member;

  // Only surface module items whose flag is enabled in org settings
  const enabledModuleItems = ALL_MODULE_ITEMS.filter(m => !!orgModules[m.id]);

  // Modules the user has pinned that are also org-enabled. Preserves
  // user-chosen order. Capped at PINNED_MODULES_CAP.
  const pinnedModuleItems = pinnedModules
    .map(id => enabledModuleItems.find(m => m.id === id))
    .filter(Boolean)
    .slice(0, PINNED_MODULES_CAP);

  useEffect(() => {
    const handleResize = () => {
      const mobile = window.innerWidth < 768;
      setIsMobile(mobile);
      if (mobile) setSidebarOpen(false);
    };
    window.addEventListener('resize', handleResize);
    handleResize();
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const toggleSidebar = () => {
    if (isMobile) {
      setSidebarOpen(!sidebarOpen);
    } else {
      setSidebarCollapsed(!sidebarCollapsed);
    }
  };

  const handleNavClick = (tab) => {
    setCurrentTab(tab);
    if (isMobile) setSidebarOpen(false);
  };

  useEffect(() => {
    const handleNavigate = (e) => {
      const detail = e.detail;

      if (typeof detail === 'string') {
        handleNavClick(detail);
        return;
      }

      if (detail?.resume && detail?.dealId) {
        const { tab, dealId } = detail;
        if (tab === 'email') {
          setPendingEmailDealId(dealId);
        } else if (tab === 'deals' || tab === 'files') {
          setPendingDealId(dealId);
        }
      }

      if (detail?.contractId) setPendingContractId(detail.contractId);
      if (detail?.handoverId)  setPendingHandoverId(detail.handoverId);
      if (detail?.contactId)  setPendingContactId(detail.contactId);
      if (detail?.meetingId)  setPendingMeetingId(detail.meetingId);
      if (detail?.accountId)  setPendingAccountId(detail.accountId);
      if (detail?.playbookFilter) setPendingPlaybookFilter(detail.playbookFilter);
      if (detail?.playbookId)     setPendingPlaybookId(detail.playbookId);
      if (detail?.actionId)   setPendingActionId(detail.actionId);

      // Use setTimeout to ensure pending state (e.g. playbookId) is committed
      // before the tab switch triggers a render of the new component
      setTimeout(() => handleNavClick(detail?.tab || detail), 0);
    };
    window.addEventListener('navigate', handleNavigate);
    return () => window.removeEventListener('navigate', handleNavigate);
  }, [isMobile]); // eslint-disable-line react-hooks/exhaustive-deps

  // Listen for open-contract events dispatched from DealContractsPanel
  useEffect(() => {
    const handleOpenContract = (e) => {
      if (!orgModules.contracts) return; // module disabled — ignore silently
      setPendingContractId(e.detail?.contractId || null);
      handleNavClick('contracts');
    };
    window.addEventListener('open-contract', handleOpenContract);
    return () => window.removeEventListener('open-contract', handleOpenContract);
  }, [orgModules]); // eslint-disable-line react-hooks/exhaustive-deps

  // Listen for open-handover events dispatched from DealsView or deal panels
  useEffect(() => {
    const handleOpenHandover = (e) => {
      if (!orgModules.handovers) return;
      setPendingHandoverId(e.detail?.handoverId || null);
      handleNavClick('handovers');
    };
    window.addEventListener('open-handover', handleOpenHandover);
    return () => window.removeEventListener('open-handover', handleOpenHandover);
  }, [orgModules]); // eslint-disable-line react-hooks/exhaustive-deps

  // Listen for module toggle events dispatched from OAModules (OrgAdminView)
  // Updates orgModules state instantly — no refresh needed.
  useEffect(() => {
    const handleModuleToggle = (e) => {
      const { module, enabled } = e.detail || {};
      if (module) setOrgModules(prev => ({ ...prev, [module]: !!enabled }));
    };
    window.addEventListener('moduleToggle', handleModuleToggle);
    return () => window.removeEventListener('moduleToggle', handleModuleToggle);
  }, []);

  useEffect(() => {
    const handleStartAction = (e) => setActiveContextAction(e.detail);
    window.addEventListener('startAction', handleStartAction);
    return () => window.removeEventListener('startAction', handleStartAction);
  }, []);

  useEffect(() => {
    const handleActionContext = (e) => {
      const { action } = e.detail || {};
      const dealId = action?.dealId || action?.deal?.id || action?.deal_id || null;
      if (dealId) setPendingDealId(dealId);
    };
    window.addEventListener('actionContext', handleActionContext);
    return () => window.removeEventListener('actionContext', handleActionContext);
  }, []);

  const allNavItems = Object.values(NAV_ITEMS_BY_ROLE).flat();
  const currentNavItem = allNavItems.find(item => item.id === currentTab);

  return (
    <div className="dashboard">
      <ImpersonationBanner />
      <Sidebar
        user={user}
        navItems={navItems}
        allModuleItems={enabledModuleItems}
        pinnedModuleItems={pinnedModuleItems}
        pinnedModuleIds={pinnedModules}
        pinnedModulesCap={PINNED_MODULES_CAP}
        onTogglePin={handleTogglePin}
        currentTab={currentTab}
        onNavClick={handleNavClick}
        activeRole={activeRole}
        availableRoles={availableRoles}
        onRoleSwitch={handleRoleSwitch}
        onLogout={onLogout}
        collapsed={sidebarCollapsed}
        onToggleCollapse={toggleSidebar}
        isMobile={isMobile}
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      {activeContextAction && (
        <ActionContextPanel
          action={activeContextAction}
          onClose={() => setActiveContextAction(null)}
          onNavigate={(tab) => { handleNavClick(tab); }}
        />
      )}

      <main className={`main-container ${sidebarCollapsed ? 'sidebar-collapsed' : ''}`}>
        {isMobile && (
          <div className="mobile-header">
            <button className="hamburger-btn" onClick={() => setSidebarOpen(true)}>☰</button>
            <div className="mobile-title">
              <span className="mobile-icon">{currentNavItem?.icon}</span>
              <span className="mobile-text">{currentNavItem?.label}</span>
            </div>
          </div>
        )}

        <div className="content-area">
          {currentTab === 'actions'     && <ActionsView openActionId={pendingActionId} onActionOpened={() => setPendingActionId(null)} />}
          {currentTab === 'prospecting' && (
            orgModules.prospecting
              ? <ProspectingView />
              : <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', height:'100%', gap:12, color:'#94a3b8' }}>
                  <div style={{ fontSize:48 }}>🎯</div>
                  <div style={{ fontSize:16, fontWeight:600, color:'#475569' }}>Prospecting module is disabled</div>
                  <div style={{ fontSize:13 }}>An org admin can enable it under Org Admin → Modules.</div>
                </div>
          )}
          {currentTab === 'deals'       && (
            <DealsView
              openDealId={pendingDealId}
              onDealOpened={() => setPendingDealId(null)}
            />
          )}
          {currentTab === 'contracts'   && (
            orgModules.contracts
              ? <ContractsView
                  openContractId={pendingContractId}
                  onContractOpened={() => setPendingContractId(null)}
                />
              : <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', height:'100%', gap:12, color:'#94a3b8' }}>
                  <div style={{ fontSize:48 }}>📄</div>
                  <div style={{ fontSize:16, fontWeight:600, color:'#475569' }}>Contracts module is disabled</div>
                  <div style={{ fontSize:13 }}>An org admin can enable it under Org Admin → Modules.</div>
                </div>
          )}
          {currentTab === 'handovers'   && (
            orgModules.handovers
              ? <HandoverView
                  openHandoverId={pendingHandoverId}
                  onHandoverOpened={() => setPendingHandoverId(null)}
                />
              : <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', height:'100%', gap:12, color:'#94a3b8' }}>
                  <div style={{ fontSize:48 }}>🤝</div>
                  <div style={{ fontSize:16, fontWeight:600, color:'#475569' }}>Handovers module is disabled</div>
                  <div style={{ fontSize:13 }}>An org admin can enable it under Org Admin → Modules.</div>
                </div>
          )}
          {currentTab === 'service'     && (
            orgModules.service
              ? <SupportView />
              : <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', height:'100%', gap:12, color:'#94a3b8' }}>
                  <div style={{ fontSize:48 }}>🎧</div>
                  <div style={{ fontSize:16, fontWeight:600, color:'#475569' }}>Service module is disabled</div>
                  <div style={{ fontSize:13 }}>An org admin can enable it under Org Admin → Service.</div>
                </div>
          )}
          {currentTab === 'agency'     && (
            orgModules.agency
              ? <AgencyView />
              : <div style={{ display:'flex', flexDirection:'column', alignItems:'center', justifyContent:'center', height:'100%', gap:12, color:'#94a3b8' }}>
                  <div style={{ fontSize:48 }}>🏢</div>
                  <div style={{ fontSize:16, fontWeight:600, color:'#475569' }}>Agency module is disabled</div>
                  <div style={{ fontSize:13 }}>An org admin can enable it under Org Admin → Modules.</div>
                </div>
          )}
          {currentTab === 'accounts'    && (
            <AccountsView
              openAccountId={pendingAccountId}
              onAccountOpened={() => setPendingAccountId(null)}
            />
          )}
          {currentTab === 'contacts'    && (
            <ContactsView
              openContactId={pendingContactId}
              onContactOpened={() => setPendingContactId(null)}
            />
          )}
          {currentTab === 'email'       && (
            <EmailView
              dealId={pendingEmailDealId}
              onDealFilterApplied={() => setPendingEmailDealId(null)}
            />
          )}
          {currentTab === 'files'       && <FilesView pendingDealId={pendingDealId} onDealOpened={(dealId) => {
            if (dealId) {
              window.dispatchEvent(new CustomEvent('navigate', {
                detail: { tab: 'deals', resume: true, dealId },
              }));
            } else {
              setPendingDealId(null);
            }
          }} />}
          {currentTab === 'calendar'    && (
            <CalendarView
              openMeetingId={pendingMeetingId}
              onMeetingOpened={() => setPendingMeetingId(null)}
            />
          )}
          {currentTab === 'settings'    && <SettingsView />}
          {currentTab === 'reporting'   && (
            <TeamReportingView
              drilldownCampaignId={pendingReportingCampaignId}
              onDrilldownConsumed={() => setPendingReportingCampaignId(null)}
            />
          )}
          {currentTab === 'agent'       && <AgentInboxView />}
          {currentTab === 'playbooks'   && (
            <PlaybooksView
              initialTypeFilter={pendingPlaybookFilter}
              key={pendingPlaybookFilter || 'default'}
            />
          )}
          {currentTab === 'playbook-detail' && pendingPlaybookId && (
            <PlaybookDetail
              playbookId={pendingPlaybookId}
              onBack={() => handleNavClick('playbooks')}
            />
          )}
          {currentTab === 'playbook-detail' && !pendingPlaybookId && (
            <div style={{ padding: 48, textAlign: 'center', color: '#9ca3af' }}>Loading…</div>
          )}
          {currentTab === 'playbook-register' && (
            <PlaybookRegister
              onSuccess={() => handleNavClick('playbooks')}
              onCancel={() => handleNavClick('playbooks')}
            />
          )}
          {currentTab === 'playbook-approvals' && (
            <PlaybookApprovals
              onBack={() => handleNavClick('playbooks')}
            />
          )}
          {currentTab === 'org-admin'   && activeRole === 'org-admin'   && <OrgAdminView />}
          {currentTab === 'super-admin' && activeRole === 'super-admin' && <SuperAdminView />}
        </div>
      </main>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
// App
// ─────────────────────────────────────────────────────────────
function App() {
  const { user, login, register, logout, loading } = useAuth();

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner">
          <div className="spinner"></div>
          <p>Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="App">
      {!user ? (
        <AuthScreen
          onLogin={login}
          onRegister={register}
          initialMode={new URLSearchParams(window.location.search).get('token') ? 'reset' : 'login'}
        />
      ) : (
        <Dashboard user={user} onLogout={logout} />
      )}
    </div>
  );
}

export default App;
